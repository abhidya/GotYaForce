#!/usr/bin/env python3
"""Public synthetic controls + optional private-snapshot validation.

No complete original instruction fixture, bytes, or reconstructable listing is
embedded here. Archive-backed tests require the two existing local snapshots;
they never fetch files. Private full inventories are not test prerequisites.
"""
import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import struct
import unittest
from unittest.mock import patch

import read_archived_target_action_frame_evidence as a
from test_archived_actor_mode1_evidence import encode as mode1_encode
from test_archived_target_preparation_evidence import encode as target_encode
from test_archived_frame_blocker_evidence import encode as prior_encode, invented_operands as prior_invented

RANGES = ((2147662612, 3712, '9aa80c3f876242ebee4cbf8afd5ede6938e90b767f8da7f4f8d9ab6d4fad1911'),)
MAPPING = (0x800055e0, 0x802b0160, 1, "MAIN_.text1", 1, 2796416, 21)
READS = [(21, 156980, 3712, 2796416)]

ROOT = Path(__file__).resolve().parents[3]
SNAPSHOT_DIR = ROOT / 'research/decomp/GotchaForce.rep.before_force_create/idata/00/~00000000.db'


def encode(row, pc):
    n = row['mnemonic']
    if n in ('lfsx','ori'): return target_encode(row,pc)
    if n in ('fmr','fcmpo','cror'): return mode1_encode(row,pc)
    if n == 'cmpl': return 31 << 26 | row['BF'] << 23 | row['L'] << 21 | row['rA'] << 16 | row['rB'] << 11 | 32 << 1
    if n == 'extsh': return 31 << 26 | row['rS'] << 21 | row['rA'] << 16 | 922 << 1 | row['Rc']
    if n == 'neg': return 31 << 26 | row['rD'] << 21 | row['rA'] << 16 | 104 << 1 | row['OE'] << 10 | row['Rc']
    if n in ('stfsx','lhax','sthx'):
        reg = row[{'stfsx':'fS','lhax':'rD','sthx':'rS'}[n]]
        return 31 << 26 | reg << 21 | row['rA'] << 16 | row['rB'] << 11 | {'stfsx':663,'lhax':343,'sthx':407}[n] << 1
    if n in ('lfs', 'lfd', 'stfs', 'stfd', 'psq_l', 'psq_st', 'fdivs', 'fsubs', 'fadds', 'fmuls'):
        return mode1_encode(row, pc)
    if n in ('lha', 'fmadds'): return target_encode(row, pc)
    if n in ('sth', 'lhz'):
        return (44 if n == 'sth' else 40) << 26 | row.get('rS', row.get('rD')) << 21 | row['rA'] << 16 | (row['displacement'] & 65535)
    if n == 'subf':
        return 31 << 26 | row['rD'] << 21 | row['rA'] << 16 | row['rB'] << 11 | row.get('OE', 0) << 10 | 40 << 1 | row['Rc']
    if n == 'srawi':
        return 31 << 26 | row['rS'] << 21 | row['rA'] << 16 | row['SH'] << 11 | 824 << 1 | row['Rc']
    return prior_encode(row, pc)


def invented_operands():
    return prior_invented()


class FakeDB:
    def __init__(self, raw=b''): self.raw, self.calls = raw, []
    def chain(self, *args):
        self.calls.append(args)
        return self.raw, []


class SyntheticTests(unittest.TestCase):
    def test_frozen_extents_and_independent_readable_provenance(self):
        self.assertEqual(a.RANGES, RANGES); self.assertEqual(a.TEXT_MAPPING, MAPPING)
        self.assertEqual(sum(width for _, width, _ in RANGES), 3712)
        index = (ROOT / 'research/decomp/ghidra-export/_index.tsv').read_text().splitlines()
        symbols = (ROOT / 'research/symbols/GG4E-CSM-20220412.map').read_text()
        for pc, width, _ in RANGES:
            chunk = 'chunk_0003.c'
            line = next(i for i, value in enumerate(index) if value.startswith(f'{pc:08x}\t') and value.endswith('\t' + chunk))
            self.assertTrue(index[line + 1].startswith(f'{pc + width:08x}\t'))
            source = (ROOT / 'research/decomp/ghidra-export' / chunk).read_text()
            body, suffix = source.split(f'// ==== {pc:08x} ', 1)[1].split('// ==== ', 1)
            self.assertTrue(body.strip()); self.assertTrue(suffix.startswith(f'{pc + width:08x} '))
            # This C/index-bounded body has no matching named map extent.
            self.assertTrue(body.strip())

    def test_invented_forms_independent_inverse_and_bit_controls(self):
        mutations = 0
        for row in invented_operands():
            word = encode(row, 0x10000000)
            self.assertEqual(a.decode_selected(word, 0x10000000), row)
            for bit in range(32):
                changed = word ^ (1 << bit); mutations += 1
                try: result = a.decode_selected(changed, 0x10000000)
                except a.c.FormatError: continue
                if result is not None:
                    self.assertNotEqual(result, row)
                    self.assertEqual(encode(result, 0x10000000), changed)
        self.assertEqual(mutations, 992)

    def test_invalid_word_pc_reserved_and_unselected_forms(self):
        for word, pc in ((True, 0), (-1, 0), (1 << 32, 0), (0, True), (0, 1), (0, -4), (0, 1 << 32)):
            with self.assertRaises(a.c.FormatError): a.decode_selected(word, pc)
        for word in ((35 << 26), (35 << 26) | (3 << 21) | (3 << 16),
                     (46 << 26) | (20 << 21) | (21 << 16),
                     (31 << 26) | (151 << 1) | 1, (31 << 26) | (23 << 1) | 1,
                     (16 << 26) | (4 << 21) | 1, 0x4e800420):
            try: result = a.decode_selected(word, 0x10000000)
            except a.c.FormatError: continue
            self.assertIsNone(result)
        self.assertIsNone(a.decode_selected(49 << 26, 0x10000000))  # Updating float load is unselected.

    def test_selection_bounds_types_duplicates_maps_refuse_before_read(self):
        for pc, width, _ in RANGES:
            for bad in (pc - 4, pc + 4, pc + 1, float(pc), True, -1, 1 << 32):
                db = FakeDB()
                with self.assertRaises(a.c.FormatError): a.range_evidence(db, MAPPING, bad, width)
                self.assertFalse(db.calls)
            for bad in (0, width - 4, width + 4, float(width), True, -width):
                db = FakeDB()
                with self.assertRaises(a.c.FormatError): a.range_evidence(db, MAPPING, pc, bad)
                self.assertFalse(db.calls)
            for i, value in enumerate(MAPPING):
                for replacement in (value + 1, float(value)) if type(value) is int else ('wrong',):
                    changed = list(MAPPING); changed[i] = replacement; db = FakeDB()
                    with self.assertRaises(a.c.FormatError): a.range_evidence(db, tuple(changed), pc, width)
                    self.assertFalse(db.calls)
            with patch.object(a, 'RANGES', RANGES * 2):
                db = FakeDB()
                with self.assertRaises(a.c.FormatError): a.range_evidence(db, MAPPING, pc, width)
                self.assertFalse(db.calls)
        for pc in (0x800055fc, 0x80010514, 0x803c4e84, 0x803c73b0, 0x803ca270, 0x804360dc):
            db = FakeDB()
            with self.assertRaises(a.c.FormatError): a.range_evidence(db, MAPPING, pc, 4)
            self.assertFalse(db.calls)

    def test_wrong_width_and_digest_fail_before_decoder(self):
        with patch.object(a, 'decode_selected') as decode:
            for pc, width, _ in RANGES:
                for size in (width - 1, width + 1):
                    with self.assertRaisesRegex(a.c.FormatError, 'byte width'):
                        a.range_evidence(FakeDB(bytes(size)), MAPPING, pc, width)
                with self.assertRaisesRegex(a.c.FormatError, 'digest mismatch'):
                    a.range_evidence(FakeDB(bytes(width)), MAPPING, pc, width)
            decode.assert_not_called()

    def test_documented_stfsx_all_register_fields_and_reserved_bit(self):
        # Independent IBM X-form layout, all 32^3 register combinations.
        for fs in range(32):
            for ra in range(32):
                for rb in range(32):
                    word = 0x7c00052e | fs << 21 | ra << 16 | rb << 11
                    self.assertEqual(a.decode_selected(word,0x10000000),dict(mnemonic='stfsx',fS=fs,rA=ra,rB=rb))
                    with self.assertRaises(a.c.FormatError): a.decode_selected(word|1,0x10000000)

    def test_authentication_precedes_parser_and_selection(self):
        with patch.object(a.c, 'inspect', side_effect=a.c.FormatError('auth stop')) as auth, \
             patch.object(a.c, 'GBF') as db, patch.object(a, 'range_evidence') as code:
            with self.assertRaisesRegex(a.c.FormatError, 'auth stop'): a.inspect(b'bad', 'bad')
            auth.assert_called_once_with(b'bad', 'bad'); db.assert_not_called(); code.assert_not_called()

    def test_mapping_corruptions_precede_selection(self):
        blocks, subs = {}, {}
        for name, key, start, length, root in a.command.MAPPINGS:
            blocks[key] = [name, None, None, 15, start, length, 0]
            subs[key] = [key, 2, length, 0, root, 0]
        cases = []
        for key in (1, 5, 7):
            for field in (4, 5, 6):
                bb, ss = copy.deepcopy((blocks, subs)); bb[key][field] += 1; cases.append((bb, ss))
            for field in range(6):
                bb, ss = copy.deepcopy((blocks, subs)); ss[key][field] += 1; cases.append((bb, ss))
            for table in ('block', 'sub'):
                bb, ss = copy.deepcopy((blocks, subs)); del (bb if table == 'block' else ss)[key]; cases.append((bb, ss))
        for bb, ss in cases:
            with patch.object(a.c, 'inspect', return_value={'image_offset': '80000000'}), patch.object(a.c, 'GBF') as db, \
                 patch.object(a, 'range_evidence') as code:
                db.return_value.tables.return_value = {'Memory Blocks': 'b', 'Sub Memory Blocks': 's'}
                db.return_value.rows.side_effect = lambda key: {'b': bb, 's': ss}[key]
                with self.assertRaises(a.c.FormatError): a.inspect(b'synthetic', 'synthetic')
                code.assert_not_called()
        self.assertEqual(len(cases), 33)

    def test_cli_has_no_general_read_or_dump_options(self):
        for option in ('--address', '--width', '--pointer', '--target', '--dump', '--instructions'):
            with patch('sys.argv', ['reader', 'none', option, '0']), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as exc: a.main()
                self.assertEqual(exc.exception.code, 2)
        with patch('sys.argv', ['reader', '/nonexistent/snapshot.gbf']), contextlib.redirect_stderr(io.StringIO()) as error:
            self.assertEqual(a.main(), 1)
            self.assertIn('not a regular file', json.loads(error.getvalue())['error'])

    def test_reused_context_is_reference_only(self):
        self.assertEqual([(x['address'], x['read_here']) for x in a.REUSED_EVIDENCE],
                         [('80029380', False), ('80053b30', False)])
        for row in a.REUSED_EVIDENCE:
            self.assertTrue((ROOT / 'research/decomp' / row['source']).is_file())
        self.assertEqual(a.INDIRECT_CALLS, {pc: () for pc, _, _ in RANGES})


@unittest.skipUnless(all((SNAPSHOT_DIR / name).is_file() for name in ('db.3.gbf', 'db.4.gbf')),
                     'existing private snapshots optional; never fetched')
class ArchivedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reports, cls.traces, cls.auth_traces, cls.rows, cls.words, cls.bodies = [], [], [], [], [], []
        chain, decode = a.c.GBF.chain, a.decode_selected
        for name in ('db.3.gbf', 'db.4.gbf'):
            raw = (SNAPSHOT_DIR / name).read_bytes(); digest = hashlib.sha256(raw).hexdigest()
            trace, rows, words, bodies = [], {}, {}, {}
            def traced(db, *args):
                trace.append(args); result = chain(db, *args)
                if args in READS: bodies[RANGES[READS.index(args)][0]] = result[0]
                return result
            def decoded(word, pc):
                result = decode(word, pc); rows[pc] = result; words[pc] = word
                return result
            with patch.object(a.c.GBF, 'chain', traced): a.c.inspect(raw, digest)
            cls.auth_traces.append(trace[:]); trace.clear()
            with patch.object(a.c.GBF, 'chain', traced), patch.object(a, 'decode_selected', decoded):
                cls.reports.append(a.inspect(raw, digest))
            cls.traces.append(trace[:]); cls.rows.append(rows); cls.words.append(words); cls.bodies.append(bodies)

    def test_reset_prefix_semantics_and_mutations(self):
        rows=[dict(address=f'{pc:08x}',**row)for pc,row in self.rows[0].items()]
        facts=a.summarize_reset_prefix(rows)
        self.assertEqual(facts['group_reset_order'],[40,32,0,16,8,24])
        self.assertEqual((facts['actor_count'],facts['actor_stride']), (6,0x1e00))
        self.assertEqual((facts['player_reset_base'],facts['player_count'],facts['player_stride']),('803c73b0',12,0x3e4))
        self.assertTrue(facts['player_reset_uses_row_base'])
        self.assertFalse(facts['constant_values_authenticated'])
        self.assertTrue(facts['maximum_stores_use_captured_values'])
        self.assertEqual(facts['active_clear_order'],[0x6fd,0x70c,0x70d,0x7d4])
        self.assertEqual(facts['active_constant_boundary'],'8002bcb0')
        self.assertEqual(facts['next_boundary'],'8002bd98')
        for pc,key,value in [('8002bc04','mnemonic','lha'),('8002bc08','displacement',0x4f4),
            ('8002bc0c','mnemonic','cmp'),('8002bc10','BI',1),('8002bc14','rS',0),
            ('8002bc18','mnemonic','lhz'),('8002bc20','BI',1),('8002bc24','immediate',1),
            ('8002bc28','displacement',0x4f4),('8002bc34','displacement',0x4fc),
            ('8002bc48','rS',0),('8002bc54','BI',1),('8002bc68','displacement',0x4fe),
            ('8002bc74','displacement',0x70c),('8002bc84','displacement',0x70d),
            ('8002bc94','displacement',0x7d4),('8002bca4','rS',3),
            ('8002bb64','displacement',0),('8002bb78','displacement',4),
            ('8002bba0','BI',1),('8002bbc8','displacement',0x7d0),
            ('8002bbe4','target','8002cc78'),('8002bc9c','displacement',-31412),
            ('8002bcc8','displacement',0x3e5),('8002bd30','immediate',0x3e4),
            ('8002bd34','immediate',12),('8002bd40','immediate',32),
            ('8002bd78','immediate',0x7744),('8002bd90','immediate',6),
            ('8002bd98','target','8002cda4')]:
            changed=copy.deepcopy(rows)
            next(r for r in changed if r['address']==pc)[key]=value
            with self.assertRaises(a.c.FormatError):a.summarize_reset_prefix(changed)

    def test_exact_one_read_follow_full_unchanged_authentication(self):
        for trace, auth in zip(self.traces, self.auth_traces):
            self.assertTrue(auth); self.assertTrue(all(row[0] == 263 for row in auth))
            self.assertEqual(trace, auth + READS)

    def test_both_snapshots_complete_and_equal_without_listing_output(self):
        for key in ('mappings', 'ranges', 'selection_basis', 'reused_evidence'):
            self.assertEqual(self.reports[0][key], self.reports[1][key])
        self.assertEqual(self.rows[0], self.rows[1]); self.assertEqual(len(self.rows[0]), 928)
        self.assertEqual([r['snapshot'] for r in self.reports], ['db.3.gbf', 'db.4.gbf'])
        for report in self.reports:
            self.assertEqual(report['file_bytes_table'], dict(version=0, root=-1, count=0))
            self.assertEqual([r['represented_instructions'] for r in report['ranges']], [928])
            self.assertTrue(all(r['unrepresented_instructions'] == 0 for r in report['ranges']))
            self.assertIn('not original-DOL identity', report['caveat'])
            basis = report['selection_basis']
            self.assertEqual((basis['reads'], basis['bytes'], basis['selected_data_cells']), (1, 3712, 0))
            for key in ('pointer_following', 'global_payloads_read', 'original_execution', 'operand_listing_output'):
                self.assertIs(basis[key], False)
            text = json.dumps(report)
            for disallowed in ('instructions', 'mnemonic', 'raw_bytes', 'raw_words', 'payload_hex'):
                self.assertNotIn('"' + disallowed + '"', text)

    def test_every_instruction_independent_inverse_and_29696_bit_controls(self):
        count = 0
        for pc, row in self.rows[0].items():
            word = self.words[0][pc]
            self.assertEqual(encode(row, pc), word)
            for bit in range(32):
                count += 1; changed = word ^ (1 << bit)
                try: result = a.decode_selected(changed, pc)
                except a.c.FormatError: continue
                if result is not None:
                    self.assertNotEqual(result, row, (hex(pc), bit))
                    self.assertEqual(encode(result, pc), changed, (hex(pc), bit))
        self.assertEqual(count, 29696)
        for pc, width, digest in RANGES:
            reconstructed = b''.join(struct.pack('>I', encode(self.rows[0][site], site))
                                     for site in range(pc, pc + width, 4))
            self.assertEqual(hashlib.sha256(reconstructed).hexdigest(), digest)

    def test_every_payload_bit_mutation_refuses_before_decode(self):
        count = 0
        with patch.object(a, 'decode_selected') as decoder:
            for pc, width, _ in RANGES:
                body = self.bodies[0][pc]
                for offset in range(width):
                    for bit in range(8):
                        changed = body[:offset] + bytes([body[offset] ^ (1 << bit)]) + body[offset + 1:]
                        with self.assertRaisesRegex(a.c.FormatError, 'digest mismatch'):
                            a.range_evidence(FakeDB(changed), MAPPING, pc, width)
                        count += 1
            decoder.assert_not_called()
        self.assertEqual(count, 29696)

    def test_spans_exact_widths_and_map_bounds(self):
        for report in self.reports:
            for row, (pc, width, digest) in zip(report['ranges'], RANGES):
                self.assertEqual(sum(span['length'] for span in row['spans']), width)
                self.assertEqual((row['address'], row['end_exclusive'], row['width'], row['sha256']),
                                 (f'{pc:08x}', f'{pc + width:08x}', width, digest))

    def test_semantic_inventory_mutation_fails_closed(self):
        original = a.decode_selected
        for site in self.rows[0]:
            def mutated(word, pc):
                row = original(word, pc)
                if pc == site: row = dict(row, unexpected_operand=0)
                return row
            entry, width, _ = next(row for row in RANGES if row[0] <= site < row[0] + row[1])
            with patch.object(a, 'decode_selected', mutated):
                with self.assertRaises(a.c.FormatError):
                    a.range_evidence(FakeDB(self.bodies[0][entry]), MAPPING, entry, width)

    def test_real_hash_schema_and_each_payload_refusal(self):
        raw = (SNAPSHOT_DIR / 'db.3.gbf').read_bytes(); digest = hashlib.sha256(raw).hexdigest()
        with patch.object(a, 'range_evidence') as selected:
            for changed, claim in ((raw, '0' * 64), (raw[:-1] + bytes([raw[-1] ^ 1]), digest)):
                with self.assertRaises(a.c.FormatError): a.inspect(changed, claim)
            selected.assert_not_called()
        original_tables = a.c.GBF.tables
        for table in ('Program', 'Property Table', 'File Bytes', 'ADDRESS MAP', 'Memory Blocks', 'Sub Memory Blocks'):
            for field in ('version', 'keytype', 'types', 'fields', 'missing'):
                def tampered(db):
                    tables = copy.deepcopy(original_tables(db))
                    if field == 'missing': del tables[table]
                    elif field == 'types': tables[table][field] = [99]
                    elif field == 'fields': tables[table][field] = 'Wrong;'
                    else: tables[table][field] += 1
                    return tables
                with patch.object(a.c.GBF, 'tables', tampered), patch.object(a, 'range_evidence') as selected:
                    with self.assertRaises(a.c.FormatError): a.inspect(raw, digest)
                    selected.assert_not_called()
        original = a.c.GBF.chain
        for selected_call in READS:
            def damaged(db, *args):
                body, spans = original(db, *args)
                if args == selected_call: body = bytes([body[0] ^ 1]) + body[1:]
                return body, spans
            with patch.object(a.c.GBF, 'chain', damaged):
                with self.assertRaisesRegex(a.c.FormatError, 'digest mismatch'): a.inspect(raw, digest)


if __name__ == '__main__':
    unittest.main()
