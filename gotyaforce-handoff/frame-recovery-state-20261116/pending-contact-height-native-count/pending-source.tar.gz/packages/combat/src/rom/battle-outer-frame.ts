import {invokeSourceContactResetOuter,type SourceContactResetSources} from './source-contact-reset.js';
import {isSourceActorNormalLifecycleRuntime,type SourceActorNormalLifecycleRuntime} from './actor-normal-lifecycle.js';
import {executeSourceContactTransform} from './source-contact-transform.js';
import {executeSourcePlayerContact36e24} from './source-player-contact.js';
import {executeSourceDrawCallback47aa4} from './source-draw-callback.js';
import type {SourceObjectAllocationRuntime} from './source-object-allocation.js';
import type {SourceProjectileRootRuntime} from './projectile-root-lifecycle.js';
/** Bounded genuine80029434 prefix, not a successful outer battle frame.
 * Executes8b048→8b010 and29d48→29e98 over the SAME80433934 owner and
 * existing teamRows103/charged/meter owners. The authenticated8b290 leaf reads
 * the SAME unsigned match-global byteD9 freshly for each reached burst row.
 * Nonzero continues later rows; zero calls recorded matched8b480 for fresh byteEB.
 * Its mask admits signed half18 decrement/expiry; positive timers stop before
 * unsupported80029de0 floating arithmetic. First reached
 * normal53b30 remains a hard ordered boundary unless explicit mass ingress
 * supplies the bounded53b30 prefix. That path stops before
 * missing passenger1e4 or missing RNG/ordering ingress. Explicit same-world
 * passenger pointers with allocation-owned signed nonzero83 skip propagation;
 * zero83 accumulates freshly loaded original mass through finite passengers
 * admitted by a captured canonical registry, with per-original repeat refusal.
 * The bounded ordering suffix can return53b30. Optional target ingress executes the ordered6ae60
 * clears. Optional shared10514 ingress supports6b450 early returns before
 * mandatory6b7f4. Its optional genuine target-dispatch owner continues inactive
 * clearing and entry0 bounded returns; skipped lifecycle rows and dispatch
 * returns execute the primary508/504 live SquareDistance path and ordered zero/null
 * distance stores through the next mandatory direction helper or estimator. Skipped lifecycle rows retain canonical508 bounds; active nonnull targets may
 * use the SAME allocation-owned83 byte, caller7d3, signed teams and finite
 * distance guards, then the six-position inner scan and ordered association bits.
 * Its bounded return feeds complete27764 selection/publication and boundedbef4.
 * Paused source flow reachesbef4 directly. Both require explicit current system,
 * player and actor cells; after binding the fresh mode selects genuine wrappers
 * 89a94(40),89a94(32) or singles89898(58),89898(57). Normal returns
 * enter the bounded53a2c ordinary helper prefix or stop at89554 respectively.
 * A supplied genuine ordered owner executes54070; absent it the live loop stops.
 * An empty signed count still runs
 * mandatory5b140 and the bounded5b2b8 clear/countdown paths before87cf0.
 * No success callback, skipped predecessor, source actor hydration, epoch,
 * complete frame or browser activation is manufactured.
 *
 * Owning the scheduler grants exclusivity and failure closure. Its public
 * entry points close on claim; only private single-use exact source-position
 * outer scopes grant scheduler execution, and unwind revokes them.
 * Stable synchronous nonproxy own-data records are host bounds. Destinations
 * are checked at each store; prior writes survive refusal and close the whole
 * retained scheduler graph. Identity checks are host admission, not ROM reads.
 * Evidence: outer-frame-evidence-2026-11-14.md (five complete archived bodies)
 * and actor-ceiling-lifecycle-evidence-2026-11-14.md (complete8b290 leaf),
 * burst-expiry-integration-2026-11-15.md (recorded matched8b480, not a new
 * ProgramDB selection or fresh retail verification).
 */
import {isSourceObjectSchedulerRuntime, claimSourceObjectSchedulerOuterFrame,
  closeSourceObjectSchedulerOuterFrame, invokeSourceObjectSchedulerOuterFrame, type SourceObjectSchedulerRuntime} from './source-object-scheduler.js';
import {isSourceActorAttributeRefreshRuntime, type SourceActorAttributeRefreshRuntime} from './actor-attribute-refresh.js';
import {markIncompleteSourceActorDoubleLifecycle, requireCompleteSourceActorDoubleLifecycle} from './actor-double-prehook.js';
import {addSourceFloat32} from './source-float.js';
import {readSourceSquareDistance} from './source-square-distance.js';
import {readSourceTargetDistance} from './source-target-distance.js';
import {readSourceShortTrig} from './source-short-trig.js';
import {isSourceActorMatrixUpdateRuntime, type SourceActorMatrixUpdateRuntime} from './actor-matrix-update.js';
import type {SourceActorCommandAdmissionRuntime} from './actor-command-admission.js';
import {isSourceActorTargetDispatchRuntime,getSourceActorTargetDispatchForScheduler,type SourceActorTargetDispatchRuntime} from './actor-target-dispatch.js';
import {checkSourcePlayerContactStorage,isSourceActorSlotStatusRuntime,type SourceActorSlotStatusRuntime} from './actor-slot-status.js';
import {isSourceActorOrderedFrameRuntime,invokeSourceActorOrderedFrameFromOuter,checkSourceActorOrderedVoicePosition,checkSourceActorOrderedSamplerInvocation,type SourceActorOrderedFrameRuntime} from './actor-ordered-frame.js';
import type {SourceActorInputSamplerRuntime} from './actor-input-sampler.js';
import {stepSourceByteRng} from './source-byte-rng.js';
import {claimSourceHelperStorage} from './source-storage-claims.js';
import {requireSourceActorActionSlotStatusOwner} from './actor-action-request.js';
import type {SourceBattleOuterGlobalFields, SourceBattleSystemGlobals} from './battle-global-layout.js';

/** Explicit metadata for source pointer arithmetic, not a copied actor table.
 * Source536b0 constructs six contiguous1e00 records;53b30 captures table[0]
 * once, then advances through this immutable identity map. The live pointer
 * table remains separate and may use a different/repeated order. */
export interface SourceBattlePhysicalActorBlock {
  readonly base: symbol;
  readonly identities: readonly symbol[];
}
export interface SourceBattleMassPreparationSources {
  /** Separate DAT_803c6dec[24] and80436264[4] storage, retained by identity. */
  teamPointers?: Record<number,symbol|null>;
  teamCounts?: Record<number,number>;
  physicalBlock?: SourceBattlePhysicalActorBlock;
  /** SAME4ac registry used by the reached canonical status binding. */
  attributes?: SourceActorAttributeRefreshRuntime;
  data?: {float80437250?: number; float80437254?: number; float80437258?: number};
  /** Actual global RNG bytes, not a seed/default or a host random callback. */
  rngState?: {byte804360c6?: number; byte804360c7?: number};
  /** Distinct DAT_803c4e6c six-word list and DAT_80436260 byte. The list is
   * not cleared: role1 scans count+1 and can observe its stale logical tail. */
  orderPointers?: Record<number,symbol|null>;
  orderCount?: {count80436260?: number};
  /** SAME genuine465fc binding owns4a4. Reached only by role1 parent scans. */
  matrices?: SourceActorMatrixUpdateRuntime;
}
export interface SourceBattleTargetPreparationSources {
  /** Exactly the admission runtime already retained by genuine projectile
   * spawn. Supplies the existing action7d2 and pointer508 cells, no copies. */
  admission?: SourceActorCommandAdmissionRuntime;
  /** SAME optional10514 owner retained by the canonical action runtime. */
  slotStatus?: SourceActorSlotStatusRuntime;
  /** Genuine6b7f4 on this exact scheduler/admission graph. */
  targetDispatch?: SourceActorTargetDispatchRuntime;
}
export interface SourceBattleOuterFrameSources {
  /** Genuine2bb14 prefix. Explicit source globals, not generated defaults. */
  targetAction?:{normal?:SourceActorNormalLifecycleRuntime;constants?:{float80436f68?:number;float80436f6c?:number};cells?:Record<string,number>;contactPointers46?:Record<number,symbol|null>;contactPointers44?:Record<number,symbol|null>};
  /** Same ten global halfword destinations used by8008a28c, not copied lists.
   * Reached only at294ec after the fresh mode selects the normal suffix. */
  contactCounters?: Partial<Record<`half804362${'50'|'4e'|'4c'|'4a'|'48'|'46'|'44'|'42'|'40'|'3e'}`,number>>;
  playerContact?:{constants?:{float80436f68?:number}};
  objectUpdates?: {roots36290:Record<number,symbol|null>;roots36280:Record<number,symbol|null>;roots36270?:Record<number,symbol|null>;roots6f54:Record<number,symbol|null>;draw:{constants:object;scratch?:Float32Array}};
  scheduler: SourceObjectSchedulerRuntime;
  /** Genuine54070, reached only at the actual ordered-list call. */
  orderedActors?:SourceActorOrderedFrameRuntime;
  /** Same explicit80433930 owner, reached only after a team/slot match. */
  systemGlobals?: SourceBattleSystemGlobals;
  /** Optional genuine53b30 prefix. Missing ingress retains the old boundary. */
  massPreparation?: SourceBattleMassPreparationSources;
  /** Optional genuine6ae60 continuation, no callback or inferred target list. */
  targetPreparation?: SourceBattleTargetPreparationSources;
  /** Only the special bef4 branch reads this explicit current global byte.
   * Ordinary binding does not inspect or require this optional owner. */
  participantViews?: {byte804360dc?:number};
}
export interface SourceBattleOuterFrameRuntime {
  getSchedulerRuntime(): SourceObjectSchedulerRuntime;
  getMatchGlobals(): SourceBattleOuterGlobalFields;
  /** This bounded prefix always refuses at its first unimplemented callee. */
  runFrame(): never;
}
const runtimes=new WeakSet<object>(), pendingClaims=new WeakMap<object,SourceObjectSchedulerRuntime>(),
  claimedGlobals=new WeakSet<object>();
const failures=new WeakMap<object,(scheduler: SourceObjectSchedulerRuntime)=>void>();
export function isSourceBattleOuterFrameRuntime(value: unknown): value is SourceBattleOuterFrameRuntime {
  return value!==null && typeof value==='object' && runtimes.has(value);
}
export function isPendingSourceBattleOuterFrameClaim(outer: unknown,scheduler: SourceObjectSchedulerRuntime): boolean {
  return isSourceBattleOuterFrameRuntime(outer) && pendingClaims.get(outer)===scheduler;
}
export function requireSourceBattleOuterFrameFailure(outer: SourceBattleOuterFrameRuntime,scheduler: SourceObjectSchedulerRuntime): void {
  const scope=failures.get(outer);
  if(!isSourceBattleOuterFrameRuntime(outer) || !scope) fail('private active outer failure required');
  scope(scheduler);
}
type TargetResetKind='actor'|'player'|'group';
const targetResets=new WeakMap<object,{consume(kind:TargetResetKind,value:symbol|number):SourceContactResetSources;check():void;constants():object}>();
export function consumeSourceBattleTargetResetInvocation(outer:SourceBattleOuterFrameRuntime,kind:TargetResetKind,value:symbol|number):SourceContactResetSources{
 const scope=targetResets.get(outer);if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private exact target/reset invocation required');return scope.consume(kind,value);
}
export function checkSourceBattleTargetResetInvocation(outer:SourceBattleOuterFrameRuntime):void{
 const scope=targetResets.get(outer);if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private target/reset invocation required');scope.check();
}
export function readSourceBattleTargetResetConstants(outer:SourceBattleOuterFrameRuntime):object{
 const scope=targetResets.get(outer);if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private target/reset constants required');scope.check();return scope.constants();
}
export interface SourceBattleOuterContactTransformContext {allocator:SourceObjectAllocationRuntime;root:SourceProjectileRootRuntime;matrix:symbol|null;input:symbol|null;output:symbol}
const contactTransforms=new WeakMap<object,{consume(node:symbol):SourceBattleOuterContactTransformContext;check(node:symbol):void}>();
export function consumeSourceBattleOuterContactTransformInvocation(outer:SourceBattleOuterFrameRuntime,node:symbol):SourceBattleOuterContactTransformContext {
 const scope=contactTransforms.get(outer);if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private active contact transform invocation required');return scope.consume(node);
}
export function checkSourceBattleOuterContactTransformInvocation(outer:SourceBattleOuterFrameRuntime,node:symbol):void {
 const scope=contactTransforms.get(outer);if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private active contact transform invocation required');scope.check(node);
}
export interface SourceBattleOuterDrawContext {allocator:SourceObjectAllocationRuntime;root:SourceProjectileRootRuntime;processor?:object|undefined;constants:object|undefined;scratch?:Float32Array|undefined}
const drawInvocations=new WeakMap<object,{consume(node:symbol):SourceBattleOuterDrawContext;check(node:symbol):void}>();
export function consumeSourceBattleOuterDrawInvocation(outer:SourceBattleOuterFrameRuntime,node:symbol):SourceBattleOuterDrawContext {
 const scope=drawInvocations.get(outer);if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private active outer draw invocation required');return scope.consume(node);
}
export function checkSourceBattleOuterDrawInvocation(outer:SourceBattleOuterFrameRuntime,node:symbol):void {
 const scope=drawInvocations.get(outer);if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private active outer draw invocation required');scope.check(node);
}
export interface SourceBattlePlayerContactContext {helper:SourceActorSlotStatusRuntime;root:SourceProjectileRootRuntime}
const playerContacts=new WeakMap<object,{consume():SourceBattlePlayerContactContext;check(helper?:SourceActorSlotStatusRuntime):void;system():object;constant():unknown}>();
export function consumeSourceBattlePlayerContactInvocation(outer:SourceBattleOuterFrameRuntime):SourceBattlePlayerContactContext {
  const p=playerContacts.get(outer);if(!p)fail('private contact outer required');return p.consume();
}
export function checkSourceBattlePlayerContactInvocation(outer:SourceBattleOuterFrameRuntime,helper?:SourceActorSlotStatusRuntime):void {
  const p=playerContacts.get(outer);if(!p)fail('private contact outer required');p.check(helper);
}
export function readSourceBattlePlayerContactSystem(outer:SourceBattleOuterFrameRuntime):object {
  const p=playerContacts.get(outer);if(!p)fail('private contact outer required');p.check();return p.system();
}
export function readSourceBattlePlayerContactZero(outer:SourceBattleOuterFrameRuntime):unknown {
  const p=playerContacts.get(outer);if(!p)fail('private contact outer required');p.check();return p.constant();
}
interface SchedulerInvocationScope {
  enter(scheduler:SourceObjectSchedulerRuntime,callsite:number,group:number):void;
  check(scheduler:SourceObjectSchedulerRuntime):void;
  parent(scheduler:SourceObjectSchedulerRuntime,id:symbol,actual:object):void;
  reject():void;
}
const schedulerInvocations=new WeakMap<object,SchedulerInvocationScope>();
/** Read-only to callers: the capability itself never leaves its outer closure. */
export function requireSourceBattleOuterFrameSchedulerInvocation(outer:SourceBattleOuterFrameRuntime,
  scheduler:SourceObjectSchedulerRuntime,callsite:number,group:number):void {
  const scope=schedulerInvocations.get(outer);
  if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private active outer scheduler invocation required');
  scope.enter(scheduler,callsite,group);
}
/** Read-only source-position check; no actor/frame capability escapes. */
export function requireSourceBattleOuterFrameCompletedParent(outer:SourceBattleOuterFrameRuntime,
 scheduler:SourceObjectSchedulerRuntime,id:symbol,actual:object):void {
 const scope=schedulerInvocations.get(outer);
 if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private later scheduler completed-parent invocation required');
 scope.parent(scheduler,id,actual);
}
export function checkSourceBattleOuterFrameSchedulerInvocation(outer:SourceBattleOuterFrameRuntime,
  scheduler:SourceObjectSchedulerRuntime):void {
  const scope=schedulerInvocations.get(outer);
  if(!isSourceBattleOuterFrameRuntime(outer)||!scope)fail('private active outer scheduler invocation required');
  scope.check(scheduler);
}
/** A caught cross-layer attempt must not leave the active retained graph usable.
 * An idle unsupported request does not start a source frame or grant authority. */
export function rejectSourceBattleOuterFrameSchedulerReentry(outer:SourceBattleOuterFrameRuntime):void {
  schedulerInvocations.get(outer)?.reject();
}
interface OrderedActorInvocationScope {
  enter(stage:SourceActorOrderedFrameRuntime,id:symbol):object;
  check(stage:SourceActorOrderedFrameRuntime,id:symbol):void;
  consume(stage:SourceActorOrderedFrameRuntime,id:symbol):object;
  matrices(stage:SourceActorOrderedFrameRuntime,id:symbol,owner:SourceActorMatrixUpdateRuntime):void;
  sampler(stage:SourceActorOrderedFrameRuntime,id:symbol,sampler:SourceActorInputSamplerRuntime):void;
  rng(stage:SourceActorOrderedFrameRuntime,id:symbol,command:SourceActorCommandAdmissionRuntime,callsite:number,expected?:object):object;
  reject():void;
}
const orderedActorInvocations=new WeakMap<object,OrderedActorInvocationScope>();
export function enterSourceBattleOrderedActorInvocation(outer:SourceBattleOuterFrameRuntime,stage:SourceActorOrderedFrameRuntime,id:symbol):object {
  const scope=orderedActorInvocations.get(outer);if(!scope)fail('private ordered outer invocation required');return scope.enter(stage,id);
}
export function checkSourceBattleOrderedActorInvocation(outer:SourceBattleOuterFrameRuntime,stage:SourceActorOrderedFrameRuntime,id:symbol):void {
  const scope=orderedActorInvocations.get(outer);if(!scope)fail('private ordered outer invocation required');scope.check(stage,id);
}
export function consumeSourceBattleOrderedActorDistances(outer:SourceBattleOuterFrameRuntime,stage:SourceActorOrderedFrameRuntime,id:symbol):object {
  const scope=orderedActorInvocations.get(outer);if(!scope)fail('private source-produced distances required');return scope.consume(stage,id);
}
export function requireSourceBattleOrderedActorMatrices(outer:SourceBattleOuterFrameRuntime,stage:SourceActorOrderedFrameRuntime,id:symbol,owner:SourceActorMatrixUpdateRuntime):void {
  const scope=orderedActorInvocations.get(outer);if(!scope)fail('private ordered matrix owner required');scope.matrices(stage,id,owner);
}
export function requireSourceBattleOrderedInputOwners(outer:SourceBattleOuterFrameRuntime,stage:SourceActorOrderedFrameRuntime,id:symbol,sampler:SourceActorInputSamplerRuntime):void {
  const scope=orderedActorInvocations.get(outer);if(!scope)fail('private56900 owner join required');scope.sampler(stage,id,sampler);
}
export function requireSourceBattleOrderedVoiceRng(outer:SourceBattleOuterFrameRuntime,stage:SourceActorOrderedFrameRuntime,id:symbol,command:SourceActorCommandAdmissionRuntime,callsite:number,expected?:object):object {
  const scope=orderedActorInvocations.get(outer);if(!scope)fail('private source800055fc owner required');return scope.rng(stage,id,command,callsite,expected);
}
export function rejectSourceBattleOrderedActorReentry(outer:SourceBattleOuterFrameRuntime):void {orderedActorInvocations.get(outer)?.reject();}
function fail(reason: string): never {
  throw Error(`[battle-outer-frame] ${reason}; offline execution aborted, prior writes/effects are not rolled back`);
}
function own(value: unknown,key: string,writable=false): unknown {
  if(value===null || typeof value!=='object') fail(`${key}: own data record required`);
  const p=Object.getOwnPropertyDescriptor(value,key);
  if(!p || !('value' in p)) fail(`${key}: own data property required`);
  if(writable && !p.writable) fail(`${key}: non-writable field`);
  return p.value;
}
function record(value: unknown,where: string): object {
  if(value===null || typeof value!=='object' || value instanceof Promise || ArrayBuffer.isView(value))
    fail(`${where}: synchronous own-data record required`);
  return value;
}
function unsigned(value: unknown,max: number,where: string): number {
  if(typeof value!=='number' || !Number.isInteger(value) || value<0 || value>max) fail(`${where}: raw unsigned source integer required`);
  return value===0 ? 0 : value;
}
const s8=(value: number): number=>value<<24>>24;
const s16=(value: number): number=>value<<16>>16;
// Final host destination check uses the native intrinsic retained at module load.
// For the declared synchronous nonproxy records it cannot invoke application
// callbacks. A stale earlier metadata snapshot cannot authorize creation or a
// setter call after the observable ownership checks have completed.
const primaryStoreDescriptor=Reflect.getOwnPropertyDescriptor;
const primaryStoreDescriptors=Object.getOwnPropertyDescriptors;
export function createSourceBattleOuterFrameRuntime(sources: SourceBattleOuterFrameSources): SourceBattleOuterFrameRuntime {
  const scheduler=own(sources,'scheduler');
  if(!isSourceObjectSchedulerRuntime(scheduler)) fail('genuine source scheduler required');
  const root=scheduler.getRootRuntime(), spawns=root.getSpawnRuntime(), allocator=scheduler.getAllocatorRuntime();
  const globals=record(scheduler.getMatchGlobals(),'canonical80433934');
  if(spawns.getMatchGlobals()!==globals || spawns.getAllocatorRuntime()!==allocator) fail('canonical scheduler graph differs');
  if(globals===sources || claimedGlobals.has(globals)) fail('battle globals alias sources or are already outer-owned');
  let busy=false,poisoned=false,incomplete=false,closing=false;
  let orderedInvocation:{stage:SourceActorOrderedFrameRuntime;id:symbol;actor:object;entered:boolean}|undefined;
  const completedOrderedActors=new Map<symbol,object>();
  let distancesPrepared=false;
  const producedDistances=new Map<symbol,{actor:object;fields:number;consumed:boolean}>();
  let targetResetInvocation:{kind:TargetResetKind;value:symbol|number;entered:boolean;sources:SourceContactResetSources;guard():void;constants():object}|undefined;
  let contactInvocation:{entered:boolean;helper:SourceActorSlotStatusRuntime}|undefined;
  let contactTransformInvocation:{node:symbol;site:0x8008a728|0x8008a888;entered:boolean;checking:boolean;context:SourceBattleOuterContactTransformContext;guard():void}|undefined;
  let drawCallsite:0x800294c8|0x800294fc|0x80029500|undefined;
  let drawInvocation:{callsite:0x800294c8|0x800294fc|0x80029500;node:symbol;entered:boolean;context:SourceBattleOuterDrawContext;updates:object;draw:object;buffer?:ArrayBufferLike|undefined}|undefined;
  let checkingDraw=false;
  const drawOwners=new Map<string,unknown>();
  let schedulerInvocation:{callsite:number;group:number;entered:boolean}|undefined;
  const retained=new Map<string,object>(), massActors=new Map<symbol,object>(),participantActors=new Map<symbol,object>();
  const check=(): void=>{if(poisoned) fail('caught same-runtime reentry');};
  const read=(owner: unknown,key: string): unknown=>{const value=own(owner,key);check();return value;};
  const call=<T>(run: ()=>T): T=>{const result=run();check();return result;};
  const write=(owner: object,key: string,value: number|boolean|symbol|null): void=>{
    own(owner,key,true);check();(owner as Record<string,unknown>)[key]=value;check();
  };
  const byte=(owner: object,key: string): number=>unsigned(read(owner,key),255,key);
  const half=(owner: object,key: string): number=>unsigned(read(owner,key),65535,key);
  const noShadows=(owner: object,keys: readonly string[]): void=>{
    for(const key of keys) {const p=Object.getOwnPropertyDescriptor(owner,key);check();if(p!==undefined) fail(`${key}: competing source cell owner`);}
  };
  const retain=(name: string,value: unknown): object=>{
    const actual=record(value,name), previous=retained.get(name);
    const mass=retained.get('massPreparation');
    if(mass!==undefined) {
      const p=Object.getOwnPropertyDescriptor(mass,'attributes');check();
      if(p && 'value' in p && isSourceActorAttributeRefreshRuntime(p.value) &&
        call(()=>p.value.getKnownParameterDescriptors()).includes(actual)) fail(`${name}: parameter storage alias`);
    }
    if(previous!==undefined && previous!==actual) fail(`${name}: canonical owner changed`);
    if(actual===sources || actual===globals || [...drawOwners.values()].includes(actual) || actual===root.getDrawList() ||
      [...massActors.values()].includes(actual) ||
      call(()=>scheduler.getRetainedStorageOwners()).includes(actual) ||
      [...retained].some(([key,owner])=>key!==name && owner===actual)) fail(`${name}: source storage alias`);
    retained.set(name,actual);return actual;
  };
  const match=(): object=>{
    const current=call(()=>spawns.getMatchGlobals());if(current!==globals) fail('canonical80433934 owner changed');return current;
  };
  const system=(): object=>{
    const actual=retain('systemGlobals',read(sources,'systemGlobals'));
    noShadows(actual,['byte2','2']);return actual;
  };
  const teamTable=(owner: object): object=>{
    const table=retain('teamRows103',read(owner,'teamRows103'));
    if(!Array.isArray(table)) fail('teamRows103: existing row-reference array required');return table;
  };
  const team=(table: object,index: number): object=>{
    // The source captured owner+f4 once. Never retarget a later row to a
    // replacement table; retain the existing row-reference representation.
    if(read(globals,'teamRows103')!==table) fail('teamRows103: canonical owner changed');
    const row=retain(`team row${index}`,read(table,String(index)));
    teamLayout(noShadows,row,index);return row;
  };
  const teamLayout=(shadows: typeof noShadows,row: object,index: number): void=>{
    const base=0xf4+index*0x3c,offsets=[...Array.from({length:10},(_,i)=>i),0xf,0x10,0x30,0x31,0x32,0x33];
    shadows(globals,[...offsets.flatMap(offset=>{const address=base+offset,hex=address.toString(16);
      return [String(address),`byte${hex}`,`byte${hex.toUpperCase()}`];}),
      `field${(base+0xf).toString(16)}`,`word${(base+0x32).toString(16)}`,
      `half${(base+0x30).toString(16)}`,`half${(base+0x32).toString(16)}`]);
    shadows(row,['byteF','bytef','byte0F','byte0f','byte103','half30','half32','word126',
      'byte30','byte31','byte32','byte33',...Array.from({length:10},(_,i)=>String(i)),'15','16','48','49','50','51']);
  };
  // Row-relative timer aliases are admitted only once that row reaches lha+18.
  // Other rows and unrelated raw byte windows stay lazy.
  const timerRows=new Map<number,object>();
  const timerLayout=(shadows: typeof noShadows): void=>{
    for(const [index,row] of timerRows) {
      shadows(row,['24','25','byte18','byte19','short18','field18','timer18','half018','half0018']);
      const address=0xf4+index*0x3c+0x18;
      shadows(globals,[String(address),String(address+1),
        ...[address,address+1].flatMap(offset=>[`byte${offset.toString(16)}`,`byte${offset.toString(16).toUpperCase()}`]),
        ...['half','short','field'].flatMap(prefix=>[`${prefix}${address.toString(16)}`,`${prefix}${address.toString(16).toUpperCase()}`])]);
    }
  };
  const storeCharged=(row: object,value: boolean): void=>{
    if(typeof read(row,'charged')!=='boolean') fail('charged: existing boolean source0/1 owner required');
    own(row,'charged',true);check();
    // A final observable descriptor hook cannot replace this destination with
    // an accessor, missing cell or nonboolean owner and let the store through.
    const live=primaryStoreDescriptor(row,'charged');
    if(!live || !('value' in live)) fail('charged: live own data property required');
    if(!live.writable) fail('charged: live non-writable field');
    if(typeof live.value!=='boolean') fail('charged: live boolean source0/1 owner required');
    (row as {charged:boolean}).charged=value;check();
  };
  const applyPending=(): void=>{
    const request=s8(byte(match(),'byte15d4'));
    if(request!==0) {
      const next=request-1;
      write(match(),'byte66',next&255); //8b010 store precedes both signed exits.
      if(next<2 && next>=0) write(match(),'halfD6',0);
    }
    write(match(),'byte15d4',0); //Unconditional even when request was0.
  };
  const refresh=(row: object): void=>{
    write(row,'byte1',0);write(row,'byte2',0);write(row,'byte3',0);
    for(let i=4;i<=9;i++) write(row,`byte${i}`,255);
    let count=0;
    // Original has three unrolled pairs. Each of the six candidates reloads
    // the global owner/mask; its matched roster index remains a local register.
    for(let slot=0;slot<6;slot++) {
      const owner=match(),bit=1<<slot;
      noShadows(owner,['byte15d9','activeMask15d9','5593',
        ...Array.from({length:6},(_,i)=>String(0xcb+i)),
        ...['CB','CC','CD','CE','CF','D0','cb','cc','cd','ce','cf','d0'].map(key=>`byte${key}`)]);
      if((byte(owner,'activeMask')&bit)===0) continue;
      const rowTeam=s8(byte(row,'byte0'));
      const slots=retain('slotTeam',read(owner,'slotTeam'));
      if(!Array.isArray(slots)) fail('slotTeam: existing slot-reference array required');
      const slotTeam=s8(unsigned(read(slots,String(slot)),255,'slotTeam byte'));
      if(slotTeam!==rowTeam) continue;
      write(row,'byte1',(byte(row,'byte1')+1)&255);
      if((s8(byte(system(),'controllerMask'))&bit)!==0) write(row,'byte2',(byte(row,'byte2')+1)&255);
      const mask=byte(row,'byte3'),destination=4+count;count++;
      write(row,'byte3',mask|bit);write(row,`byte${destination}`,slot);
    }
  };
  const terminalRead=(record: object,key: string): unknown=>{
    const field=primaryStoreDescriptor(record,key);
    if(!field || !('value' in field)) fail(`${key}: terminal own data property required`);
    return field.value;
  };
  const teamGuard=(table: object,row: object,index: number,keys: readonly ('byteD9'|'byteEB')[]): (()=>void)=>{
    const owner=globals,callee=keys.includes('byteEB')?'8008b480':'8008b290';
    const metadata=(shadows: typeof noShadows,records: readonly object[]): void=>{
      for(const record of records) for(const key of keys) {
        if(record!==owner) shadows(record,[key]);
        const suffix=key.slice(4),lower=suffix.toLowerCase();
        shadows(record,[`byte${lower}`,`byte0${lower}`,`byte0${suffix}`,`field${suffix}`,`field${lower}`,`global${suffix}`,`global${lower}`]);
        // Decimal offsets alias the global, not unrelated raw byte windows.
        if(record===owner) shadows(record,[key==='byteD9'?'217':'235']);
      }
      if(keys.includes('byteEB')) {
        for(const [name,record] of retained) if(name.startsWith('team row'))
          teamLayout(shadows,record,Number(name.slice(8)));
        timerLayout(shadows);
      }
    };
    return (): void=>{
      const records=[sources,globals,table,row,...retained.values(),
        ...call(()=>scheduler.getRetainedStorageOwners())];
      metadata(noShadows,[...new Set(records)]);
      // After the LAST observable inventory, native snapshots cannot call
      // application code in the declared synchronous nonproxy host domain.
      const current=[...new Set([...records,...call(()=>scheduler.getRetainedStorageOwners())])];
      const nested=current.flatMap(record=>Object.values(primaryStoreDescriptors(record)).flatMap(field=>
        'value' in field && field.value!==null && typeof field.value==='object'?[field.value as object]:[]));
      const all=[...new Set([...current,...nested])];
      if(terminalRead(sources,'scheduler')!==scheduler || scheduler.getRootRuntime()!==root ||
        root.getSpawnRuntime()!==spawns || scheduler.getAllocatorRuntime()!==allocator ||
        scheduler.getMatchGlobals()!==owner || spawns.getMatchGlobals()!==owner)
        fail(`${callee} canonical scheduler/global owner changed`);
      if(terminalRead(owner,'teamRows103')!==table || terminalRead(table,String(index))!==row)
        fail(`${callee} canonical team owner changed`);
      for(const [name,record] of retained) {
        if(name.startsWith('team row') && terminalRead(table,name.slice(8))!==record)
          fail(`${callee} retained team row owner changed`);
        if(name==='slotTeam' && terminalRead(owner,'slotTeam')!==record ||
          name==='systemGlobals' && terminalRead(sources,'systemGlobals')!==record)
          fail(`${callee} ${name}: canonical owner changed`);
      }
      metadata((record,keys)=>{
        for(const key of keys) if(primaryStoreDescriptor(record,key)!==undefined)
          fail(`${key}: competing source cell owner`);
      },all);
      for(const record of all) requireCompleteSourceActorDoubleLifecycle(record);
      check();
    };
  };
  const teamRefreshLeaf=(table: object,row: object,index: number): number=>{
    // Complete8008b290: lwz r3,-31852(r13); lbz r3,217(r3); blr.
    const owner=match(),guard=teamGuard(table,row,index,['byteD9']);
    guard();const result=byte(owner,'byteD9');guard();
    unsigned(terminalRead(owner,'byteD9'),255,'byteD9');return result;
  };
  const updateBurst=(table: object,row: object,index: number): void=>{
    // Existing recorded matched-source8008b480: lwz r3,-31852(r13);
    // lbz r3,235(r3); blr. No new archive/DOL verification is claimed.
    const owner=match(),guard=teamGuard(table,row,index,['byteD9','byteEB']);
    guard();const mask=byte(owner,'byteEB');guard();
    unsigned(terminalRead(owner,'byteEB'),255,'byteEB');
    const load=(key: string,max: number): number=>{
      guard();const value=read(row,key);guard();
      unsigned(terminalRead(row,key),max,key);return unsigned(value,max,key);
    };
    const store=(key: string,value: number): void=>{
      guard();own(row,key,true);check();guard();
      const field=primaryStoreDescriptor(row,key);
      if(!field || !('value' in field)) fail(`${key}: live own data property required`);
      if(!field.writable) fail(`${key}: live non-writable field`);
      if(key==='half18') unsigned(field.value,65535,key);
      // No observable callback between final metadata/native destination check
      // and the overwrite. This is not a source read of the old destination.
      (row as Record<string,unknown>)[key]=value;guard();
    };
    //80029da0..db4: unsigned returned r3 AND signed source row+3. Zero
    // skips the row+3 load entirely; captured values survive valid mutations.
    if(mask!==0 && (mask&s8(load('byte3',255)))===0) return;
    timerRows.set(index,row);
    const timer=s16(load('half18',65535)),next=s16(timer-1);
    store('half18',next&65535); // sth uses low16, extsh sets the branch result.
    if(next>0) fail('80029de0 reached unsupported positive burst timer floating suffix');
    store('meter',0);store('byte10',0);store('meter',0); //29dd0/dd4/dd8, not deduplicated.
  };
  const updateTeams=(): void=>{
    const table=teamTable(match()); //29d60–64 captures original row base once.
    for(let i=0;i<4;i++) {
      const row=team(table,i);refresh(row);
      if(s8(byte(row,'byte1'))<=0) continue;
      if(s8(byte(row,'byte10'))!==0) {
        storeCharged(row,false);
        if(teamRefreshLeaf(table,row,i)!==0) continue; // Full returned r3,29d94..98.
        updateBurst(table,row,i);continue;
      }
      const meter=half(row,'meter'),threshold=half(row,'threshold30');
      storeCharged(row,meter>=threshold);
    }
  };
  const slotPointer=(index: number): symbol|null=>{
    const table=call(()=>scheduler.getActorSlotTable());
    // Getter retains this very source table; no new roster or alias is made.
    const old=retained.get('mass actorSlots');
    if(old!==undefined && old!==table) fail('mass actorSlots: canonical owner changed');
    if([...retained].some(([role,value])=>role!=='mass actorSlots' && value===table)) fail('mass actorSlots: source storage alias');
    retained.set('mass actorSlots',table);
    const id=read(table,String(index));
    if(id!==null && typeof id!=='symbol') fail('53b30 actor slot: source pointer identity required');
    return id;
  };
  const actual=(id: symbol|null): object=>{
    if(id===null) fail('53b30 null actor at reached dereference');
    if(call(()=>allocator.getInteriorAddress(id))!==null) fail('53b30 actual actor base identity required');
    const value=record(call(()=>allocator.getPointerTarget(id)),'53b30 actual actor');
    const old=massActors.get(id);
    if(old!==undefined && old!==value) fail('53b30 actual actor changed');
    if([...retained.values()].includes(value)) fail('53b30 actual actor aliases mass/global storage');
    // Retain the resolved actual before fallible field admission so a new
    // physical actor with an alias/missing cell cannot escape failure closure.
    massActors.set(id,value);
    noShadows(value,['0','byte0','mass204','sourceArrowMass204','field204','float204','516',
      'field208','float208','520','byte204','byte205','byte206','byte207','byte208','byte209','byte20a','byte20b',
      'byte20A','byte20B','byte88','field88','136','floatB4','fieldB4','floatb4','fieldb4',
      '180','181','182','183','byteb4','byteb5','byteb6','byteb7','byteB4','byteB5','byteB6','byteB7',
      'byte1db','byte1DB','field1db','field1DB','475','lifecycle18','byte18','field18','state18',
      'parameter4ac','pointer4ac','1196','24','517','518','519','521','522','523']);
    call(()=>requireCompleteSourceActorDoubleLifecycle(value));return value;
  };
  const rngOwner=(mass:object,where:string):{state:object;guard:()=>void}=>{
    const supplied=Object.getOwnPropertyDescriptor(mass,'rngState');check();
    if(supplied===undefined)fail(`${where} reached mandatory800055fc RNG predecessor`);
    if(read(sources,'massPreparation')!==mass || retained.get('massPreparation')!==mass)
      fail('RNG canonical mass owner changed');
    const state=retain('mass rngState',read(mass,'rngState')),
      aliases=['c6','c7','bytec6','bytec7','198','199','seed','state'];
    const guard=():void=>{
      noShadows(state,aliases);check();
      if(terminalRead(sources,'massPreparation')!==mass || terminalRead(mass,'rngState')!==state ||
        retained.get('mass rngState')!==state)fail('RNG canonical owner changed');
      for(const key of aliases)if(primaryStoreDescriptor(state,key)!==undefined)fail(`${key}: competing source cell owner`);
      check();
    };
    return {state,guard};
  };
  const randomByte=(mass:object,where:string):number=>{
    const {state,guard}=rngOwner(mass,where);return stepSourceByteRng(state,guard);
  };
  const prepareMass=(): void=>{
    const supplied=Object.getOwnPropertyDescriptor(sources,'massPreparation');check();
    if(supplied===undefined) fail('80029458 reached mandatory80053b30 normal-stage predecessor');
    const mass=retain('massPreparation',read(sources,'massPreparation'));
    const massOwner=(key: string): object=>{
      if(read(sources,'massPreparation')!==mass) fail('massPreparation: canonical owner changed');
      return retain(`mass ${key}`,read(mass,key));
    };
    const pointers=(): object=>massOwner('teamPointers');
    const counts=(): object=>massOwner('teamCounts');
    const storePointer=(index: number,id: symbol|null): void=>{
      // Host bounded24-word storage; source signed indices are never clamped.
      if(index<0 || index>=24) fail('53b30 team pointer index outside explicit24-word owner');
      write(pointers(),String(index),id);
    };
    const storeCount=(index: number,value: number): void=>{
      if(index<0 || index>=4) fail('53b30 team count index outside explicit4-byte owner');
      write(counts(),String(index),value&255);
    };
    const status=spawns.getPrehookRuntime().getStatusRuntime(), stage=root.getStageRuntime(), world=spawns.getWorldRuntime();
    const borg=(id: symbol,actor: object): object=>{
      if(call(()=>status.getActualActor(id))!==actor) fail('53b30 canonical status actual differs');
      const value=record(call(()=>status.getActualBorg(id)),'53b30 same Borg204');
      // Identities are keyed by actual actor, not the symbol description.
      const prior=borgs.get(id);
      if(prior!==undefined && prior!==value) fail('53b30 canonical Borg changed');
      if(value===actor || [...retained.values()].includes(value) ||
        [...borgs].some(([other,owner])=>other!==id && owner===value) || [...massActors.values()].includes(value))
        fail('53b30 Borg aliases another source owner');
      noShadows(value,['mass204','field204','float204','516','byte204','byte205','byte206','byte207',
        'mass208','field208','float208','520','517','518','519',
        'byte208','byte209','byte20a','byte20b','byte20A','byte20B','521','522','523']);
      borgs.set(id,value);return value;
    };
    const borgs=new Map<symbol,object>();
    const f=(owner: object,key: string): number=>{
      const value=read(owner,key);
      if(typeof value!=='number' || !Number.isFinite(value) || !Object.is(value,Math.fround(value)))
        fail(`${key}: finite exact source float32 required`);
      return value;
    };
    const constant=(key: 'float80437250'|'float80437254'|'float80437258',expected: number): number=>{
      const value=f(massOwner('data'),key);
      if(!Object.is(value,expected)) fail(`${key}: differs from authenticated source bits`);return value;
    };
    const life=(id: symbol,actor: object): number=>{
      if(root.getStageRuntime()!==stage || call(()=>stage.getActualActor(id))!==actor) fail('53b30 canonical stage actual differs');
      const binding=record(call(()=>stage.getActorBinding(id)),'53b30 stage binding');
      if([...retained.values()].includes(binding) || binding===actor || [...borgs.values()].includes(binding)) fail('53b30 stage storage alias');
      return byte(binding,'lifecycle18');
    };
    //80053b5c first clear precedes the captured first actor pointer at53b60.
    storePointer(0,null);
    const base=slotPointer(0);
    for(let i=1;i<20;i++) storePointer(i,null);
    storeCount(0,0);storePointer(20,null);storeCount(1,0);
    storePointer(21,null);storeCount(2,0);storePointer(22,null);storePointer(23,null);storeCount(3,0);
    // Immutable metadata is a host admission bound. It neither loads actor
    // scalar fields nor claims that the caller has hydrated a retail arena.
    const block=massOwner('physicalBlock');
    if(!Object.isFrozen(block)) fail('53b30 physical block metadata must be frozen');
    if(read(block,'base')!==base) fail('53b30 physical base differs from captured table[0]');
    const ids=retain('mass physical identities',read(block,'identities'));
    if(!Array.isArray(ids) || !Object.isFrozen(ids) || read(ids,'length')!==6) fail('53b30 six frozen physical identities required');
    // Sparse host representation preserves uninitialized source stack bytes.
    // Only an active physical row reaches the source stb zero at stack+8+i.
    const passengerCounts: (number|undefined)[]=Array(6);
    const physicalTargets=new Set<object>(),physicalIds=new Set<symbol>();
    for(let index=0;index<6;index++) {
      if(read(mass,'physicalBlock')!==block) fail('53b30 physical block owner changed');
      const id=read(ids,String(index));
      if(typeof id!=='symbol' || (index===0 && id!==base) || physicalIds.has(id)) fail('53b30 distinct physical base identities required');
      physicalIds.add(id);const actor=actual(id);
      if(physicalTargets.has(actor)) fail('53b30 physical targets overlap');physicalTargets.add(actor);
      if(s8(byte(actor,'active0'))===0) continue;
      const zero=constant('float80437250',0);
      passengerCounts[index]=0; //80053be8: active physical index, not actor.slot.
      const owner=borg(id,actor);write(owner,'sourceArrowMass204',zero);
      const state=s8(life(id,actor));
      if(state===1 || state===2) {
        const binding=record(call(()=>status.getAttributeBinding(id)),'53b30 canonical4ac binding');
        const parameter=read(binding,'parameter4ac');
        if(parameter!==null && typeof parameter!=='symbol') fail('parameter4ac: source pointer identity required');
        const threshold=constant('float80437254',50000);
        const attributes=read(mass,'attributes');
        if(!isSourceActorAttributeRefreshRuntime(attributes) || call(()=>attributes.getActualActor(id))!==actor ||
          call(()=>attributes.getActorBinding(id))!==binding) fail('53b30 same genuine4ac registry required');
        if(parameter===null) fail('53b30 null4ac at reached parameter98 load');
        const descriptor=record(call(()=>attributes.getParameterDescriptor(parameter)),'53b30 same parameter descriptor');
        if([...retained.values()].includes(descriptor) || [...massActors.values()].includes(descriptor) ||
          [...borgs.values()].includes(descriptor)) fail('53b30 parameter storage alias');
        noShadows(descriptor,['mass98','float98','152','153','154','155','byte98','byte99','byte9a','byte9b','byte9A','byte9B']);
        const baseMass=f(descriptor,'field98');
        if(baseMass<threshold) {
          const scale=f(actor,'modelScale'),product=Math.fround(baseMass*scale);
          if(!Number.isFinite(product)) fail('53b30 scaled mass overflows finite float32');
          write(actor,'mass208',product);
        } else write(actor,'mass208',baseMass);
      } else write(actor,'mass208',zero);
      // Actual second load is UNSIGNED, not reuse of the earlier signed load.
      if(life(id,actor)===1) {
        const team=s8(byte(actor,'team'));
        if(team<0 || team>=4) fail('53b30 team outside explicit4-byte count owner');
        const count=byte(counts(),String(team));
        storeCount(team,count+1); // source stb precedes pointer store/admission.
        storePointer(team*6+s8(count),id);
      }
    }
    // Capture each current passenger once. Nonzero83 remains completely lazy
    // about its slot, Borg mass, contact and further chain.
    const passenger83=(id: symbol,actor: object,callerBorg: object,originalGuard: ()=>void)=>{
      const pointerAliases=['linkedOwner1E4','pointer1e4','pointer1E4','field1e4','field1E4',
        'byte1e4','byte1e5','byte1e6','byte1e7','byte1E4','byte1E5','byte1E6','byte1E7','484','485','486','487'];
      const callerWorld=call(()=>world.getActorBinding(id));
      const pointerMetadata=(shadows: typeof noShadows): void=>{
        for(const candidate of new Set([sources,globals,actor,callerWorld,callerBorg,...retained.values(),
          ...allocator.getSourceOwners(id)])) {
          // Another genuine actor's further-chain pointer is not this cell.
          if(candidate!==actor) shadows(candidate,['linkedOwner1e4']);
          shadows(candidate,pointerAliases.slice(0,-4));
          // Allocation byte buffers legitimately own numeric offset484.
          if(candidate===actor || candidate===callerWorld || candidate===callerBorg)
            shadows(candidate,pointerAliases.slice(-4));
        }
      };
      const terminalShadows=(owner: object,keys: readonly string[]): void=>{
        for(const key of keys) if(primaryStoreDescriptor(owner,key)!==undefined)
          fail(`${key}: competing source cell owner`);
      };
      const supplied=Object.getOwnPropertyDescriptor(actor,'linkedOwner1e4');check();
      if(supplied===undefined) fail('80053b30 mass propagation reached unsupported actual pointer1e4 ownership: explicit linkedOwner1e4 required');
      // Exactly one actual lwz capture, never a collision binding or symbol cast.
      if(!('value' in supplied)) fail('linkedOwner1e4: own data property required');
      pointerMetadata(noShadows);
      const pointer=record(supplied.value,'53b30 captured linkedOwner1e4');
      const targetId=call(()=>allocator.getPointerIdentity(pointer)),targetActor=actual(targetId);
      const owner=record(call(()=>allocator.getActorBinding(targetId)),'53b30 canonical passenger allocation83');
      const targetWorld=call(()=>world.getActorBinding(targetId));
      const byteMetadata=(shadows: typeof noShadows): void=>{
        for(const candidate of new Set([targetActor,targetWorld,...allocator.getSourceOwners(targetId)])) {
          if(candidate!==owner) shadows(candidate,['byte83']);
          shadows(candidate,['eligibility83','groupEligibility83','field83']);
          if(candidate===targetActor || candidate===targetWorld || candidate===owner) shadows(candidate,['131']);
        }
      };
      const finish=(): void=>{
        // Native terminal descriptors cannot invoke the observer that just ran.
        // Pointer and byte values remain captured even if their live cells change.
        if(terminalRead(sources,'scheduler')!==scheduler || scheduler.getAllocatorRuntime()!==allocator ||
          scheduler.getRootRuntime()!==root || root.getSpawnRuntime()!==spawns ||
          spawns.getWorldRuntime()!==world || terminalRead(sources,'massPreparation')!==mass ||
          allocator.getPointerTarget(id)!==actor || allocator.getActualActor(id)!==actor ||
          status.getActualActor(id)!==actor || status.getActualBorg(id)!==callerBorg ||
          world.getActualActor(id)!==actor || world.getActorBinding(id)!==callerWorld ||
          targetActor!==pointer || allocator.getPointerTarget(targetId)!==targetActor ||
          allocator.getActualActor(targetId)!==targetActor || allocator.getActorBinding(targetId)!==owner ||
          world.getActualActor(targetId)!==targetActor || world.getActorBinding(targetId)!==targetWorld)
          fail('53b30 terminal canonical caller/passenger owner changed');
        terminalRead(actor,'linkedOwner1e4');terminalRead(owner,'byte83');
        pointerMetadata(terminalShadows);byteMetadata(terminalShadows);
        requireCompleteSourceActorDoubleLifecycle(actor);requireCompleteSourceActorDoubleLifecycle(targetActor);
        allocator.assertActorComplete(id);allocator.assertActorComplete(targetId);originalGuard();check();
      };
      const guard=(): void=>{
        check();call(()=>allocator.assertActorComplete(id));call(()=>allocator.assertActorComplete(targetId));
        if(targetActor!==pointer || call(()=>allocator.getActualActor(targetId))!==targetActor ||
          call(()=>world.getActualActor(targetId))!==targetActor ||
          call(()=>allocator.getPointerTarget(targetId))!==targetActor ||
          call(()=>allocator.getActorBinding(targetId))!==owner)
          fail('53b30 canonical passenger allocator/world owner differs');
        if(!Object.isSealed(owner) || owner===targetActor || [...retained.values()].includes(owner) ||
          [...massActors.values()].includes(owner) || [...borgs.values()].includes(owner))
          fail('53b30 passenger allocation83 storage alias');
        pointerMetadata(noShadows);byteMetadata(noShadows);finish();
      };
      guard();const captured=byte(owner,'byte83');guard();
      return {captured,targetId,targetActor,owner,callerBorg,guard,finish};
    };
    const accumulatePassenger=(selected: ReturnType<typeof passenger83>,original: {
      id: symbol; actor: object; worldBinding: object; allocation: object;
    }): {contact: number; owner: object}=>{
      const {id:originalId,actor}=original;
      const {targetId,targetActor}=selected;
      let massBorg:object|undefined,slotReached=false,massReached=false,originalMassReached=false,contactReached=false;
      const terminalShadows=(owner: object,keys: readonly string[]): void=>{
        for(const key of keys) if(primaryStoreDescriptor(owner,key)!==undefined)
          fail(`${key}: competing source cell owner`);
      };
      const metadata=(shadows: typeof noShadows): void=>{
        const actuals=world.getRetainedActorOwners(),knownBorgs=[...borgs.values()];
        // Inspect reached roles only: another genuine unvisited Borg may
        // already own204, without being a shadow of this passenger.
        const records=new Set([sources,globals,mass,actor,targetActor,selected.owner,
          world.getActorBinding(targetId),original.worldBinding,original.allocation,
          ...allocator.getSourceOwners(originalId),...retained.values(),...allocator.getSourceOwners(targetId),
          ...(massBorg===undefined?[]:[status.getActorBinding(targetId),status.getWorldBinding(targetId),
            status.getMappingActor(targetId),status.getAttributeBinding(targetId),status.getMovementBinding(targetId)]),
          ...knownBorgs]);
        for(const owner of records) {
          if(slotReached) {
            if(!actuals.includes(owner)) shadows(owner,['slot']);
            shadows(owner,['slot3e4','byte3e4','byte3E4','field3e4','field3E4']);
            if(owner===targetActor) shadows(owner,['996']);
          }
          if(massReached) {
            if(!knownBorgs.includes(owner)) shadows(owner,['sourceArrowMass204']);
            shadows(owner,['mass204','field204','float204','byte204','byte205','byte206','byte207']);
            if(owner===targetActor || owner===massBorg) shadows(owner,['516','517','518','519']);
          }
          if(originalMassReached) {
            if(!actuals.includes(owner)) shadows(owner,['mass208']);
            shadows(owner,['field208','float208','byte208','byte209','byte20a','byte20b','byte20A','byte20B']);
            if(owner===actor || owner===massBorg) shadows(owner,['520','521','522','523']);
          }
          if(contactReached) {
            if(!actuals.includes(owner)) shadows(owner,['supportContact1db']);
            shadows(owner,['byte1db','byte1DB','field1db','field1DB']);
            if(owner===targetActor) shadows(owner,['475']);
          }
        }
      };
      const finish=(): void=>{
        selected.finish();
        for(const [name,owner] of retained) {
          if(name.startsWith('mass ') && name!=='mass actorSlots' && name!=='mass physical identities' &&
            terminalRead(mass,name.slice(5))!==owner)
            fail(`53b30 terminal ${name} owner changed`);
        }
        if(terminalRead(block,'identities')!==ids) fail('53b30 terminal physical identities owner changed');
        if(massBorg!==undefined && (status.getActualActor(targetId)!==targetActor ||
          status.getActualBorg(targetId)!==massBorg || massBorg===targetActor ||
          [...retained.values()].includes(massBorg) || [...massActors.values()].includes(massBorg) ||
          [...borgs].some(([id,owner])=>id!==targetId && owner===massBorg)))
          fail('53b30 terminal canonical passenger Borg owner changed or aliases storage');
        metadata(terminalShadows);
        if(slotReached) terminalRead(targetActor,'slot');
        if(massReached) terminalRead(massBorg!,'sourceArrowMass204');
        if(originalMassReached) terminalRead(actor,'mass208');
        if(contactReached) terminalRead(targetActor,'supportContact1db');
        requireCompleteSourceActorDoubleLifecycle(targetActor);
        requireCompleteSourceActorDoubleLifecycle(selected.callerBorg);
        if(massBorg!==undefined) requireCompleteSourceActorDoubleLifecycle(massBorg);
        check();
      };
      const guard=(): void=>{selected.guard();metadata(noShadows);selected.guard();finish();};
      //53cc8/53d24: raw slot is captured BEFORE either floating load. The
      // signed address and sparse local byte are used only AFTER both loads.
      slotReached=true;guard();const rawSlot=byte(targetActor,'slot');guard();
      massBorg=borg(targetId,targetActor);massReached=true;
      guard();const passengerMass=f(massBorg,'sourceArrowMass204');guard();
      originalMassReached=true;guard();const originalMass=f(actor,'mass208');guard();
      const slot=s8(rawSlot),counter=passengerCounts[slot];
      if(slot<0 || slot>=6 || counter===undefined)
        fail('53b30 reached uninitialized or out-of-domain local passenger count');
      const old=unsigned(counter,255,'local passenger count');
      const sum=addSourceFloat32(passengerMass,originalMass); // overflow before BOTH stores.
      guard();passengerCounts[slot]=(old+1)&255; //53ce4/53d40: unsigned lbzx, low-byte stb.
      own(massBorg,'sourceArrowMass204',true);guard();
      const destination=primaryStoreDescriptor(massBorg,'sourceArrowMass204');
      if(!destination || !('value' in destination)) fail('sourceArrowMass204: live own data property required');
      if(!destination.writable) fail('sourceArrowMass204: live non-writable field');
      (massBorg as {sourceArrowMass204:number}).sourceArrowMass204=sum;guard();
      contactReached=true;guard();const contact=byte(targetActor,'supportContact1db');guard();
      return {contact,owner:massBorg};
    };
    // A private identity-only snapshot bounds host work, not source depth.
    // Later registrations remain lazy: a newly reached nonzero83 still exits.
    const traversalActors=new Set<object>(world.getRetainedActorOwners());
    // Three original unrolled pairs. No active/lifecycle test or pointer
    // snapshot: every one of the six table cells is loaded when reached.
    for(let index=0;index<6;index++) {
      const id=slotPointer(index),actor=actual(id);
      if(id===null) fail('53b30 null actor'); // narrowed after reached dereference.
      const owner=borg(id,actor),total=f(owner,'sourceArrowMass204'),massValue=f(actor,'mass208');
      const accumulated=addSourceFloat32(total,massValue);
      own(owner,'sourceArrowMass204',true);check();
      // A prior passenger skip exposes the next actual table half. Refuse a
      // destination changed by the last observable preflight before invoking
      // any setter or recreating a deleted cell. Source operands stay captured.
      const destination=primaryStoreDescriptor(owner,'sourceArrowMass204');
      if(!destination || !('value' in destination)) fail('sourceArrowMass204: live own data property required');
      if(!destination.writable) fail('sourceArrowMass204: live non-writable field');
      (owner as {sourceArrowMass204:number}).sourceArrowMass204=accumulated;check();
      if(s8(byte(actor,'supportContact1db'))!==0) {
        const original={id,actor,owner,worldBinding:world.getActorBinding(id),
          allocation:allocator.getActorBinding(id)};
        // r8 remains guarded after r9 advances, including a later nonzero83
        // early exit. These native descriptor checks add no source scalar loads.
        const originalGuard=(): void=>{
          if(allocator.getPointerTarget(id)!==actor || allocator.getActualActor(id)!==actor ||
            allocator.getActorBinding(id)!==original.allocation ||
            world.getActualActor(id)!==actor || world.getActorBinding(id)!==original.worldBinding ||
            status.getActualActor(id)!==actor || status.getActualBorg(id)!==owner ||
            owner===actor || [...retained.values()].includes(owner) || [...massActors.values()].includes(owner) ||
            [...borgs].some(([other,borgOwner])=>other!==id && borgOwner===owner))
            fail('53b30 terminal canonical original contribution owner changed or aliases storage');
          for(const record of new Set([actor,owner,original.worldBinding,original.allocation,
            ...allocator.getSourceOwners(id)])) {
            const aliases=['mass204','field204','float204','byte204','byte205','byte206','byte207',
              'field208','float208','byte208','byte209','byte20a','byte20b','byte20A','byte20B'];
            if(record!==actor) aliases.push('mass208');
            if(record!==owner) aliases.push('sourceArrowMass204');
            if(record===actor || record===owner) aliases.push('516','517','518','519','520','521','522','523');
            for(const key of aliases) if(primaryStoreDescriptor(record,key)!==undefined)
              fail(`${key}: competing source cell owner`);
          }
          terminalRead(actor,'mass208');terminalRead(owner,'sourceArrowMass204');
          requireCompleteSourceActorDoubleLifecycle(actor);requireCompleteSourceActorDoubleLifecycle(owner);
          allocator.assertActorComplete(id);check();
        };
        let currentId=id,currentActor=actor,currentBorg=owner;
        // Do not seed with the original: a first self-passenger update is
        // source-visible and is admitted before a subsequent repeat refusal.
        const processed=new Set<object>();
        for(;;) {
          const selected=passenger83(currentId,currentActor,currentBorg,originalGuard);
          if(s8(selected.captured)!==0) break;
          if(!traversalActors.has(selected.targetActor))
            fail('53b30 unsupported host-domain passenger outside captured registry');
          if(processed.has(selected.targetActor))
            fail('53b30 unsupported host-domain repeated zero83 passenger');
          processed.add(selected.targetActor);
          const accumulated=accumulatePassenger(selected,original);
          if(s8(accumulated.contact)===0) break;
          currentId=selected.targetId;currentActor=selected.targetActor;currentBorg=accumulated.owner;
        }
      }
    }
    const countOwner=(): object=>{
      const owner=massOwner('orderCount');noShadows(owner,['count','byte0','0']);return owner;
    };
    const orderCount=(): number=>byte(countOwner(),'count80436260');
    const writeOrderCount=(value: number): void=>write(countOwner(),'count80436260',value&255);
    const orderIndex=(index: number): void=>{
      // Index6 aliases the adjacent actor table in retail memory. This
      // bounded host list does not silently manufacture that alias.
      if(index<0 || index>=6) fail('53b30 order pointer outside explicit6-word owner');
    };
    const orderPointer=(index: number): symbol|null=>{
      orderIndex(index);const id=read(massOwner('orderPointers'),String(index));
      if(id!==null && typeof id!=='symbol') fail('53b30 order pointer identity required');return id;
    };
    const writeOrderPointer=(index: number,id: symbol|null): void=>{
      orderIndex(index);write(massOwner('orderPointers'),String(index),id);
    };
    const worlds=new Map<symbol,object>();
    const worldOwner=(id: symbol,actor: object): object=>{
      if(spawns.getWorldRuntime()!==world || call(()=>world.getActualActor(id))!==actor ||
        call(()=>status.getActualActor(id))!==actor) fail('53b30 canonical world actual differs');
      const owner=record(call(()=>world.getActorBinding(id)),'53b30 same world4a0');
      if(call(()=>status.getWorldBinding(id))!==owner || (worlds.has(id)&&worlds.get(id)!==owner))
        fail('53b30 canonical world binding differs');
      if(owner===actor || [...retained.values()].includes(owner) || [...borgs.values()].includes(owner))
        fail('53b30 world storage alias');
      noShadows(actor,['mode4a0','field4a0','byte4a0','byte4A0','1184']);
      noShadows(owner,['field4a0','byte4a0','byte4A0','1184']);worlds.set(id,owner);return owner;
    };
    const slot=(actor: object): number=>{
      noShadows(actor,['slot3e4','byte3e4','byte3E4','field3e4','field3E4','996']);
      return s8(byte(actor,'slot'));
    };
    const passengerCount=(index: number): number=>{
      if(index<0 || index>=6 || passengerCounts[index]===undefined)
        fail('53b30 reached uninitialized or out-of-domain local passenger count');
      return s8(passengerCounts[index]!);
    };
    const parent=(id: symbol,actor: object,worldBinding: object): symbol|null=>{
      const matrices=read(mass,'matrices');
      if(!isSourceActorMatrixUpdateRuntime(matrices) || call(()=>matrices.getActualActor(id))!==actor ||
        call(()=>matrices.getWorldBinding(id))!==worldBinding || call(()=>matrices.getGlobals())!==globals ||
        call(()=>matrices.getMappingActor(id))!==call(()=>status.getMappingActor(id)))
        fail('53b30 same genuine4a4 matrix owner required');
      const owner=record(call(()=>matrices.getActorBinding(id)),'53b30 matrix4a4 binding');
      if(call(()=>world.getCorrectedTraversalState(id))!==owner) fail('53b30 canonical corrected4a4 owner differs');
      if(owner===actor || [...retained.values()].includes(owner) || [...borgs.values()].includes(owner) ||
        [...worlds.values()].includes(owner)) fail('53b30 matrix storage alias');
      noShadows(actor,['link4a4','pointer4a4','field4a4','byte4a4','byte4a5','byte4a6','byte4a7',
        'byte4A4','byte4A5','byte4A6','byte4A7','1188','1189','1190','1191']);
      noShadows(owner,['pointer4a4','field4a4','byte4a4','byte4a5','byte4a6','byte4a7',
        'byte4A4','byte4A5','byte4A6','byte4A7','1188','1189','1190','1191']);
      const value=read(owner,'link4a4');
      if(value!==null && typeof value!=='symbol') fail('53b30 parent pointer identity required');return value;
    };
    const shift=(end: number,start: number): void=>{
      // The source unrolls groups of8 then the remainder. A bounded6-word
      // list can reach only the remainder; preserve each load/store pair.
      for(let index=end;index>start;index--) writeOrderPointer(index,orderPointer(index-1));
    };
    let selected=(randomByte(mass,'80053d60')>>>2)%6;
    const direction=(randomByte(mass,'80053d80')&8)!==0?1:-1;
    writeOrderCount(0); //53d9c precedes authenticated1.0 load53da4.
    const one=constant('float80437258',1);
    for(let visit=0;visit<6;visit++) {
      const id=slotPointer(selected),actor=actual(id);
      if(id===null) fail('53b30 null ordering actor');
      noShadows(actor,['float664','mass664','1636','1637','1638','1639','byte664','byte665','byte666','byte667']);
      write(actor,'field664',one);
      selected=selected+direction<0?5:(selected+direction)%6;
      if(s8(byte(actor,'active0'))===0) continue;
      if(byte(worldOwner(id,actor),'mode4a0')===1) continue;
      const captured=s8(orderCount());
      if(captured<0) continue;
      for(let index=0;index<=captured;index++) {
        if(index===captured) {
          const raw=orderCount(),destination=s8(raw);
          writeOrderCount(raw+1); //append stb BEFORE stwx.
          writeOrderPointer(destination,id);break;
        }
        const existing=orderPointer(index); //pointer load, then candidate slot, then existing slot.
        const candidateSlot=slot(actor),other=actual(existing),otherSlot=slot(other);
        const candidateCount=passengerCount(candidateSlot),otherCount=passengerCount(otherSlot);
        if(candidateCount<=otherCount) continue; //stable ties in random visit order.
        shift(captured,index);
        const fresh=orderCount();
        writeOrderPointer(index,id);writeOrderCount(fresh+1);break; //insert stwx BEFORE stb.
      }
    }
    //53f44 reloads table0 once, then returns to physical stride. This explicit
    // metadata covers the original block only; a retargeted base is refused.
    if(slotPointer(0)!==base) fail('53b30 final physical base differs from explicit block');
    for(let index=0;index<6;index++) {
      if(read(mass,'physicalBlock')!==block || read(block,'identities')!==ids)
        fail('53b30 physical block owner changed');
      const id=read(ids,String(index));
      if(typeof id!=='symbol') fail('53b30 physical identity required');
      const actor=actual(id);
      if(s8(byte(actor,'active0'))===0) continue;
      const header=worldOwner(id,actor);
      if(byte(header,'mode4a0')!==1) continue;
      const captured=s8(orderCount());
      if(captured<0) continue;
      for(let position=0;position<=captured;position++) {
        //53f80 list pointer load precedes fresh4a4 every comparison. No
        // dereference of either compared pointer and no null-parent default.
        const existing=orderPointer(position),link=parent(id,actor,header);
        if(existing!==link) continue;
        shift(captured,position);
        const fresh=orderCount();
        writeOrderPointer(position,id);writeOrderCount(fresh+1);break;
      }
    }
    //Genuine53b30 return for the fully reached bounded propagation path.

  };
  const prepareTargets=(): void=>{
    const supplied=Object.getOwnPropertyDescriptor(sources,'targetPreparation');check();
    if(supplied===undefined) fail('8002945c reached mandatory8006ae60 normal-stage predecessor');
    const target=retain('targetPreparation',read(sources,'targetPreparation'));
    const stage=root.getStageRuntime(),world=spawns.getWorldRuntime(),status=spawns.getPrehookRuntime().getStatusRuntime();
    const admission=(): SourceActorCommandAdmissionRuntime=>{
      if(read(sources,'targetPreparation')!==target) fail('targetPreparation: canonical owner changed');
      const selected=read(target,'admission'),canonical=spawns.getAdmissionRuntime();
      if(selected!==canonical) fail('6ae60 exact retained command admission required');return canonical;
    };
    const physical=(): readonly symbol[]=>{
      // A new source load of803c4e84 occurs at every pass. The frozen block is
      // pointer-arithmetic metadata from53b30, not a source actor-table copy.
      const base=slotPointer(0),mass=retained.get('massPreparation'),block=retained.get('mass physicalBlock'),
        ids=retained.get('mass physical identities');
      if(!mass || !block || !ids || read(sources,'massPreparation')!==mass ||
        read(mass,'physicalBlock')!==block || read(block,'identities')!==ids)
        fail('6ae60 canonical physical block owner changed');
      if(read(block,'base')!==base) fail('6ae60 physical base differs from explicit block');
      if(!Array.isArray(ids) || !Object.isFrozen(ids) || read(ids,'length')!==6)
        fail('6ae60 six frozen physical identities required');
      return ids as readonly symbol[];
    };
    const actorAt=(ids: readonly symbol[],index: number): {id: symbol;actor: object}=>{
      const id=read(ids,String(index));if(typeof id!=='symbol') fail('6ae60 physical actor identity required');
      return {id,actor:actual(id)};
    };
    const actualByte=(actor: object,key: 'byte58a'|'byte58b'|'byte58c'|'byte58d'|'byte7d3'): void=>{
      const hex=key.slice(4),offset=parseInt(hex,16);
      noShadows(actor,[`byte${hex.toUpperCase()}`,`field${hex}`,`field${hex.toUpperCase()}`,
        `flags${hex}`,`mask${hex}`,String(offset)]);
      write(actor,key,0);
    };
    const commandOwners=new Map<symbol,{binding: object;action: object}>();
    const command=(id: symbol,actor: object,needAction: boolean): object=>{
      const runtime=admission();
      if(call(()=>runtime.getActualActor(id))!==actor || call(()=>world.getActualActor(id))!==actor ||
        call(()=>status.getActualActor(id))!==actor ||
        call(()=>runtime.getWorldBinding(id))!==call(()=>world.getActorBinding(id)) ||
        call(()=>runtime.getWorldBinding(id))!==call(()=>status.getWorldBinding(id)) ||
        call(()=>runtime.getMappingActor(id))!==call(()=>status.getMappingActor(id)))
        fail('6ae60 canonical command actor/world/mapping differs');
      const binding=record(call(()=>runtime.getActorBinding(id)),'6ae60 canonical508 binding');
      const actionRuntime=runtime.getActionRuntime(),action=record(call(()=>runtime.getActionBinding(id)),'6ae60 canonical7d2 binding');
      if(call(()=>actionRuntime.getActorBinding(id))!==action || call(()=>actionRuntime.getActualActor(id))!==actor ||
        call(()=>actionRuntime.getWorldBinding(id))!==call(()=>runtime.getWorldBinding(id)))
        fail('6ae60 canonical action7d2 owner differs');
      const old=commandOwners.get(id);
      if(old && (old.binding!==binding || old.action!==action)) fail('6ae60 canonical command owner changed');
      if(binding===action || [binding,action].some(owner=>owner===actor || [...retained.values()].includes(owner)))
        fail('6ae60 command source storage alias');
      commandOwners.set(id,{binding,action});return needAction?action:binding;
    };
    const primaryDistance=(id: symbol,actor: object,dispatch: SourceActorTargetDispatchRuntime): void=>{
      const binding=command(id,actor,false);
      const basicGuard=(): void=>{
        check();requireCompleteSourceActorDoubleLifecycle(actor);allocator.assertActorComplete(id);check();
        admission().assertActorComplete(id);check();
        if(root.getSpawnRuntime()!==spawns || spawns.getWorldRuntime()!==world ||
          world.getActualActor(id)!==actor || admission().getActorBinding(id)!==binding)
          fail('6ae60 primary canonical actor/command/world changed');
      };
      const load=(owner: object,key: string): unknown=>{const value=read(owner,key);basicGuard();return value;};
      let data: object|undefined;
      let estimatorProcessor: object|undefined,estimatorProcessorSource: object|undefined;
      let nullDirection=false,secondaryReached=false,ccReached=false,aimReached=false,c8Reached=false;
      let operandsGuard=basicGuard;
      let terminalRuntime: SourceActorCommandAdmissionRuntime|undefined;
      let terminalRecords: object[]=[],terminalActors: readonly object[]=[];
      let primaryReached=false,primaryProvider: object|undefined,primaryObject: symbol|undefined;
      let primaryProviderReferences: Map<object,Set<string>>|undefined;
      let terminalAim: object|undefined,terminalPosition: object|undefined,terminalSelected: object|undefined;
      const distanceKeys=['targetDistance758','horizontalDistance75c','targetDistance760','horizontalDistance764'] as const;
      const secondaryAliases=['field760','field764','float760','float764',
        ...Array.from({length:8},(_,index)=>0x760+index).flatMap(offset=>
          [String(offset),'byte'+offset.toString(16),'byte'+offset.toString(16).toUpperCase()])];
      const aimAliases=['field518','field51c','field51C','field520','position518','targetPosition518',
        ...Array.from({length:12},(_,index)=>0x518+index).flatMap(offset=>
          [String(offset),'byte'+offset.toString(16),'byte'+offset.toString(16).toUpperCase()])];
      const positionAliases20=['position20','field20','field24','field28',
        ...Array.from({length:12},(_,index)=>0x20+index).flatMap(offset=>
          [String(offset),'byte'+offset.toString(16),'byte'+offset.toString(16).toUpperCase()])];
      const selectedAliases=['field50c','field50C','field510','field514','position50c','targetPosition50c',
        ...Array.from({length:12},(_,index)=>0x50c+index).flatMap(offset=>
          [String(offset),'byte'+offset.toString(16),'byte'+offset.toString(16).toUpperCase()])];
      const shadowKeys=['field758','field75c','field75C','float758','float75c','float75C',
        ...Array.from({length:8},(_,index)=>0x758+index).flatMap(offset=>
          [String(offset),'byte'+offset.toString(16),'byte'+offset.toString(16).toUpperCase()])];
      const distanceGuard=(): void=>{
        operandsGuard();
        if(estimatorProcessor!==undefined && call(()=>root.getVectorProcessorProfile())!==estimatorProcessor)
          fail('secondary estimator processor profile owner changed');
        const commandRuntime=admission(),actionRuntime=commandRuntime.getActionRuntime();
        terminalRuntime=commandRuntime;
        if(data!==undefined && commandRuntime.getData()!==data) fail('6ae60 primary shared data owner changed');
        const actualActors=world.getRetainedActorOwners();
        if(!actualActors.includes(actor)) fail('6ae60 primary actual actor owner missing');
        const canonical=[sources,globals,root,scheduler,allocator,spawns,world,binding,
          commandRuntime.getGlobal(),commandRuntime.getWorldBinding(id),commandRuntime.getStatusBinding(id),
          commandRuntime.getMappingActor(id),commandRuntime.getAttributeBinding(id),commandRuntime.getChargeBinding(id),
          commandRuntime.getActionBinding(id),commandRuntime.getCueBinding(id),commandRuntime.getDispatchBinding(id),
          commandRuntime.getStartBinding(id),commandRuntime.getStreamBinding(id),...retained.values(),
          ...world.getRetainedMatrixOwners(),...commandRuntime.getKnownStorageOwners(),
          ...actionRuntime.getRetainedStorageOwners(),...status.getRetainedStorageOwners(),
          ...allocator.getRetainedStorageOwners(),root.getDrawList(),...dispatch.getRetainedStorageOwners(),
          ...root.getRetainedStorageOwners(),...scheduler.getRetainedStorageOwners()];
        // Host metadata inventories, not extra source scalar or target reads.
        const records=[...new Set([...canonical,...actualActors,...massActors.values(),...(data?[data]:[])])];
        terminalRecords=records;terminalActors=actualActors;
        const snapshots=records.map(owner=>({owner,fields:Object.getOwnPropertyDescriptors(owner)}));basicGuard();
        const nested=snapshots.flatMap(({fields})=>Object.values(fields).flatMap(p=>
          'value' in p && p.value!==null && typeof p.value==='object' ? [p.value as object]:[]));
        const owners=[...new Set([...records,...nested])];
        if(data!==undefined && (actualActors.includes(data) || [sources,globals,root,scheduler,allocator,spawns,world,binding,
          commandRuntime.getWorldBinding(id),commandRuntime.getStatusBinding(id),commandRuntime.getMappingActor(id),
          commandRuntime.getAttributeBinding(id),commandRuntime.getChargeBinding(id),commandRuntime.getActionBinding(id),
          commandRuntime.getCueBinding(id),commandRuntime.getDispatchBinding(id),commandRuntime.getStartBinding(id),
          commandRuntime.getStreamBinding(id),...retained.values(),...world.getRetainedMatrixOwners()].includes(data)))
          fail('6ae60 primary data aliases canonical source storage');
        for(const owner of owners) {
          const fields=Object.getOwnPropertyDescriptors(owner);basicGuard();
          for(const key of (secondaryReached?distanceKeys:distanceKeys.slice(0,2))) if(!actualActors.includes(owner) && fields[key]!==undefined)
            fail(`${key}: competing primary distance storage`);
          for(const key of shadowKeys) if(fields[key]!==undefined)
            fail(`${key}: competing primary distance storage alias`);
          for(const key of ['float80437658','float80437678','double80437660','double80437668']) if(owner!==data && fields[key]!==undefined)
            fail(`${key}: competing primary shared data storage`);
          if(ccReached) {
            if(!actualActors.includes(owner) && fields.visibilityTarget!==undefined)
              fail('visibilityTarget: competing secondary source storage');
            for(const key of ['pointerCC','pointercc','fieldcc','fieldCC','bytecc','bytecd','bytece','bytecf',
              'byteCC','byteCD','byteCE','byteCF']) if(fields[key]!==undefined)
              fail(`${key}: competing secondary pointer alias`);
            // These offsets name actual+cc only on this actor. Unrelated raw
            // byte windows may legitimately have numeric entries at204..207.
            if(owner===actor) for(const key of ['204','205','206','207']) if(fields[key]!==undefined)
              fail(`${key}: competing secondary pointer alias`);
          }
          if(secondaryReached) {
            for(const key of secondaryAliases) if(fields[key]!==undefined)
              fail(`${key}: competing secondary distance alias`);
            if(!actualActors.includes(owner) && fields.aimOrigin518!==undefined)
              fail('aimOrigin518: competing secondary aim storage');
          }
          if(c8Reached) {
            if(fields.pointerc8!==undefined && ![...commandOwners.values()].some(entry=>entry.binding===owner))
              fail('pointerc8: competing secondary canonical source storage');
            for(const key of ['pointerC8','fieldc8','fieldC8','bytec8','bytec9','byteca','bytecb',
              'byteC8','byteC9','byteCA','byteCB']) if(fields[key]!==undefined)
              fail(`${key}: competing secondary pointerc8 alias`);
            if(owner===actor) for(const key of ['pointerc8','200','201','202','203']) if(fields[key]!==undefined)
              fail(`${key}: competing secondary pointerc8 storage`);
          }
          if(aimReached) for(const key of aimAliases) if(fields[key]!==undefined)
            fail(`${key}: competing secondary aim storage alias`);
          if(nullDirection) {
            if(owner!==data && fields.float80437078!==undefined)
              fail('float80437078: competing null-direction shared data storage');
            if(!actualActors.includes(owner) && fields.heading!==undefined)
              fail('heading: competing null-direction source storage');
            for(const key of ['field72','short72','yaw72','byte72','byte73']) if(fields[key]!==undefined)
              fail(`${key}: competing null-direction source alias`);
          }
        }
        operandsGuard();
      };
      const terminalPrimary=(): void=>{
        if(!primaryReached) return;
        // Native descriptors close the last public metadata-observer window.
        // No c8/cc/null-direction state belongs to this branch.
        const nativeRead=(owner: object,key: string): unknown=>{
          const p=primaryStoreDescriptor(owner,key);
          if(!p || !('value' in p)) fail(`${key}: primary terminal own data property required`);
          return p.value;
        };
        const runtime=terminalRuntime;
        if(!runtime || nativeRead(sources,'targetPreparation')!==target || nativeRead(target,'admission')!==runtime ||
          nativeRead(sources,'scheduler')!==scheduler || spawns.getAdmissionRuntime()!==runtime ||
          runtime.getActualActor(id)!==actor || runtime.getActorBinding(id)!==binding ||
          runtime.getData()!==data || world.getActualActor(id)!==actor || status.getActualActor(id)!==actor)
          fail('primary terminal canonical actor/admission/data owner changed');
        if(terminalPosition===undefined || nativeRead(actor,'pos')!==terminalPosition ||
          world.getPositionOwner(id)!==terminalPosition) fail('primary terminal position20 owner changed');
        if(primaryProvider===undefined || primaryObject===undefined ||
          allocator.getPointerIdentity(primaryProvider)!==primaryObject || allocator.getObject(primaryObject)!==primaryProvider)
          fail('primary terminal captured OBJECT provider changed');
        if(estimatorProcessor!==undefined && (estimatorProcessorSource===undefined ||
          nativeRead(estimatorProcessorSource,'processor')!==estimatorProcessor))
          fail('primary terminal processor profile owner changed');
        const snapshots=terminalRecords.map(owner=>({owner,fields:primaryStoreDescriptors(owner)}));
        const nested=snapshots.flatMap(({fields})=>Object.values(fields).flatMap(p=>
          'value' in p && p.value!==null && typeof p.value==='object'?[p.value as object]:[]));
        for(const owner of new Set([...terminalRecords,...nested])) {
          const fields=primaryStoreDescriptors(owner);
          const ban=(keys: readonly string[]): void=>{
            for(const key of keys) if(fields[key]!==undefined) fail(`${key}: competing primary terminal storage alias`);
          };
          if(!terminalActors.includes(owner)) ban(distanceKeys.slice(0,2));
          ban(shadowKeys);
          if(owner===actor) ban(positionAliases20);
          if(owner!==data) ban(['float80437658','float80437678','double80437660','double80437668']);
          for(const [key,p] of Object.entries(fields)) if('value' in p) {
            if(estimatorProcessor!==undefined && p.value===estimatorProcessor &&
              !(owner===estimatorProcessorSource && key==='processor'))
              fail('primary terminal processor aliases canonical reference');
            if(owner!==terminalPosition && p.value===terminalPosition && !(owner===actor && key==='pos'))
              fail('primary terminal position20 aliases canonical reference');
            if(owner!==primaryProvider && p.value===primaryProvider &&
              !primaryProviderReferences?.get(owner)?.has(key) && !(owner===binding && key==='pointer504'))
              fail('primary terminal captured provider aliases canonical reference');
          }
        }
        check();requireCompleteSourceActorDoubleLifecycle(actor);
        runtime.assertActorComplete(id);allocator.assertActorComplete(id);check();
      };
      const terminalSecondary=(): void=>{
        if(!c8Reached) return;
        // Public metadata observers have finished. Rebuild nested ownership
        // from native descriptors, so a final observer cannot add an alias or
        // replace a canonical link and let the pending store slip through.
        // These are host records, not extra loads of captured source scalars.
        const nativeRead=(owner: object,key: string): unknown=>{
          const field=primaryStoreDescriptor(owner,key);
          if(!field || !('value' in field)) fail(`${key}: terminal own data property required`);
          return field.value;
        };
        const runtime=terminalRuntime;
        if(!runtime || nativeRead(sources,'targetPreparation')!==target || nativeRead(target,'admission')!==runtime ||
          nativeRead(sources,'scheduler')!==scheduler || spawns.getAdmissionRuntime()!==runtime ||
          runtime.getActualActor(id)!==actor || runtime.getActorBinding(id)!==binding ||
          runtime.getData()!==data || world.getActualActor(id)!==actor || status.getActualActor(id)!==actor)
          fail('secondary terminal canonical actor/admission/data owner changed');
        if(estimatorProcessor!==undefined && (estimatorProcessorSource===undefined ||
          nativeRead(estimatorProcessorSource,'processor')!==estimatorProcessor))
          fail('secondary terminal processor profile owner changed');
        if(terminalAim!==undefined && nativeRead(actor,'aimOrigin518')!==terminalAim)
          fail('secondary terminal aimOrigin518 owner changed');
        if(terminalSelected!==undefined && nativeRead(actor,'lockTarget')!==terminalSelected)
          fail('secondary terminal selected position owner changed');
        if(terminalPosition!==undefined && (nativeRead(actor,'pos')!==terminalPosition || world.getPositionOwner(id)!==terminalPosition))
          fail('secondary terminal position20 owner changed');
        const selectedAliasOwners=[actor,binding,terminalSelected,data,runtime.getGlobal(),runtime.getWorldBinding(id),
          runtime.getStatusBinding(id),runtime.getMappingActor(id),runtime.getAttributeBinding(id),runtime.getChargeBinding(id),
          runtime.getActionBinding(id),runtime.getCueBinding(id),runtime.getDispatchBinding(id),runtime.getStartBinding(id),runtime.getStreamBinding(id)];
        const snapshots=terminalRecords.map(owner=>({owner,fields:primaryStoreDescriptors(owner)}));
        const nested=snapshots.flatMap(({fields})=>Object.values(fields).flatMap(p=>
          'value' in p && p.value!==null && typeof p.value==='object'?[p.value as object]:[]));
        for(const owner of new Set([...terminalRecords,...nested])) {
          const fields=primaryStoreDescriptors(owner);
          const ban=(keys: readonly string[]): void=>{
            for(const key of keys) if(fields[key]!==undefined) fail(`${key}: competing secondary terminal storage alias`);
          };
          if(!terminalActors.includes(owner)) ban([...distanceKeys,'visibilityTarget','aimOrigin518','heading']);
          ban([...shadowKeys,...secondaryAliases,...aimAliases,'pointerCC','pointercc','fieldcc','fieldCC',
            'bytecc','bytecd','bytece','bytecf','byteCC','byteCD','byteCE','byteCF',
            'pointerC8','fieldc8','fieldC8','bytec8','bytec9','byteca','bytecb','byteC8','byteC9','byteCA','byteCB',
            'field72','short72','yaw72','byte72','byte73']);
          if(fields.pointerc8!==undefined && ![...commandOwners.values()].some(entry=>entry.binding===owner))
            fail('pointerc8: competing secondary terminal canonical storage');
          if(owner===actor) ban(['200','201','202','203','204','205','206','207']);
          if(owner===actor && terminalPosition!==undefined) ban(positionAliases20);
          if(terminalSelected!==undefined && selectedAliasOwners.includes(owner)) {
            ban(selectedAliases);if(owner!==actor) ban(['lockTarget']);
            if(owner===terminalSelected) ban(['active0','team','byte502','pointer504','pointer508','descriptor4b0',
              'lifecycle18','half80436242','count804361a0']);
          }
          if(owner!==data) ban(['float80437658','float80437678','float80437078','double80437660','double80437668']);
          for(const [key,p] of Object.entries(fields)) if('value' in p) {
            if(estimatorProcessor!==undefined && p.value===estimatorProcessor &&
              !(owner===estimatorProcessorSource && key==='processor'))
              fail('secondary terminal processor aliases canonical reference');
            if(terminalAim!==undefined && owner!==terminalAim && p.value===terminalAim && !(owner===actor&&key==='aimOrigin518'))
              fail('secondary terminal aimOrigin518 aliases canonical reference');
            if(terminalSelected!==undefined && owner!==terminalSelected && p.value===terminalSelected && !(owner===actor&&key==='lockTarget'))
              fail('secondary terminal selected position aliases canonical reference');
            if(terminalPosition!==undefined && owner!==terminalPosition && p.value===terminalPosition && !(owner===actor&&key==='pos'))
              fail('secondary terminal position20 aliases canonical reference');
          }
        }
        check();requireCompleteSourceActorDoubleLifecycle(actor);
        runtime.assertActorComplete(id);allocator.assertActorComplete(id);check();
      };
      const sourceFloat=(value: unknown,key: string): number=>{
        if(typeof value!=='number' || !Number.isFinite(value) || !Object.is(value,Math.fround(value)))
          fail(`${key}: finite exact source float32 required`);return value;
      };
      const constant=(key: 'float80437658'|'float80437678',expected: number,address: string): number=>{
        if(data===undefined) data=record(admission().getData(),'6ae60 primary shared data');
        distanceGuard();
        const field=Object.getOwnPropertyDescriptor(data,key);distanceGuard();
        if(!field || !('value' in field)) fail(`${address} ${key}: own data property required`);
        const value=sourceFloat(field.value,key);
        if(!Object.is(value,expected)) fail(`${address} ${key}: differs from authenticated source bits`);
        return value;
      };
      const store=(key: typeof distanceKeys[number],value: number): void=>{
        distanceGuard();
        const field=Object.getOwnPropertyDescriptor(actor,key);distanceGuard();
        if(!field || !('value' in field)) fail(`${key}: own data property required`);
        if(!field.writable) fail(`${key}: non-writable field`);
        // Host admission may discover a changed descriptor. Do not turn a
        // reached plain store into property creation or an accessor callback.
        const current=Object.getOwnPropertyDescriptors(actor)[key];distanceGuard();
        if(!current || !('value' in current)) fail(`${key}: own data property changed before store`);
        if(!current.writable) fail(`${key}: non-writable field before store`);
        terminalSecondary();terminalPrimary();
        const live=primaryStoreDescriptor(actor,key);
        if(!live || !('value' in live)) fail(`${key}: live own data property required before store`);
        if(!live.writable) fail(`${key}: live non-writable field before store`);
        // No application callback occurs between this final intrinsic and the
        // plain own-data overwrite. The old scalar is never validated or used.
        (actor as Record<string,unknown>)[key]=value;distanceGuard();
        if(key==='targetDistance760'||key==='horizontalDistance764') {
          const prior=producedDistances.get(id);
          if(prior&&prior.actor!==actor)fail('6ae60 source-distance actual owner changed');
          const production=prior??{actor,fields:0,consumed:false};
          production.fields|=key==='targetDistance760'?1:2;producedDistances.set(id,production);
        }
      };
      const preparePosition=(): {position: object;guard: ()=>void}=>{
      noShadows(actor,positionAliases20);
      const position=record(load(actor,'pos'),'6ae60 actual position20');
      terminalPosition=position;
      if(Array.isArray(position)) fail('6ae60 position20 requires ordinary source vector');
      if(call(()=>world.getPositionOwner(id))!==position) fail('6ae60 actual position record changed');
      const positionGuard=(): void=>{
        basicGuard();
        const field=Object.getOwnPropertyDescriptor(actor,'pos');check();
        if(!field || !('value' in field) || field.value!==position || world.getPositionOwner(id)!==position)
          fail('6ae60 actual position record changed');
        const commandRuntime=admission(),actionRuntime=commandRuntime.getActionRuntime();
        const structured=[sources,globals,root,scheduler,allocator,spawns,world,actor,binding,
          commandRuntime.getGlobal(),commandRuntime.getData(),commandRuntime.getWorldBinding(id),
          commandRuntime.getStatusBinding(id),commandRuntime.getMappingActor(id),commandRuntime.getAttributeBinding(id),
          commandRuntime.getChargeBinding(id),commandRuntime.getActionBinding(id),commandRuntime.getCueBinding(id),
          commandRuntime.getDispatchBinding(id),commandRuntime.getStartBinding(id),commandRuntime.getStreamBinding(id),
          ...retained.values(),...massActors.values(),...world.getRetainedMatrixOwners(),
          ...commandRuntime.getKnownStorageOwners(),...actionRuntime.getRetainedStorageOwners(),
          ...status.getRetainedStorageOwners(),...allocator.getRetainedStorageOwners()];
        //Only this actor's inline pos reference is admitted. The vector cannot
        //also be canonical bytes, helper data, another actor or another vector.
        const references=[...structured,root.getDrawList(),...dispatch.getRetainedStorageOwners(),
          ...root.getRetainedStorageOwners(),...scheduler.getRetainedStorageOwners()];check();
        for(const owner of references) {
          if(owner===position) continue;
          const fields=Object.getOwnPropertyDescriptors(owner);check();
          for(const [key,p] of Object.entries(fields)) if('value' in p && p.value===position && !(owner===actor && key==='pos'))
            fail('6ae60 position20 aliases canonical source reference');
        }
        if(structured.includes(position))
          fail('6ae60 position20 aliases canonical source storage');
        basicGuard();
      };
        positionGuard();return {position,guard:positionGuard};
      };
      for(const owner of [actor,binding]) noShadows(owner,['field504','field508',
        ...Array.from({length:8},(_,index)=>0x504+index).flatMap(offset=>
          [String(offset),'byte'+offset.toString(16),'byte'+offset.toString(16).toUpperCase()])]);
      noShadows(actor,['pointer504','pointer508']);
      //af8c compares this captured pointer only. It does not dereference the
      //target, infer eligibility, or recover the OBJECT from that target actor.
      const targetPointer=load(binding,'pointer508');
      if(targetPointer===null) {
        const missing=constant('float80437678',20000,'8006b180');
        store('horizontalDistance75c',missing);store('targetDistance758',missing);
        nullDirection=true;distanceGuard();
        const heading=(): number=>{
          noShadows(actor,['field72','short72','yaw72','114','115','byte72','byte73']);
          const word=load(actor,'heading');distanceGuard();
          return unsigned(word,65535,'heading')<<16>>16;
        };
        const trig=(angle: number,cosine: boolean): number=>{
          const profile=call(()=>admission().getShortTrigProfile());distanceGuard();
          return readSourceShortTrig(angle,cosine,data!,profile,distanceGuard);
        };
        const horizontal=(): number=>{
          const value=read(actor,'horizontalDistance75c');distanceGuard();
          return sourceFloat(value,'horizontalDistance75c');
        };
        let selected: object|undefined;
        const selectedGuard=(): void=>{
          basicGuard();
          if(selected!==undefined) {
            if(call(()=>dispatch.getSelectedPositionOwner(id))!==selected)
              fail('6ae60 selected position canonical owner changed');
            const owners=[sources,globals,data!,...retained.values(),...massActors.values()];
            if(owners.includes(selected)) fail('6ae60 selected position aliases outer source storage');
            for(const owner of owners) {
              const fields: PropertyDescriptorMap=Object.getOwnPropertyDescriptors(owner);basicGuard();
              for(const [key,p] of Object.entries(fields)) if('value' in p && p.value===selected && !(owner===actor && key==='lockTarget'))
                fail('6ae60 selected position aliases outer canonical reference');
            }
          }
          basicGuard();
        };
        const storeSelected=(axis: 'x'|'y'|'z',value: number): void=>{
          const borrowed=call(()=>dispatch.getSelectedPositionOwner(id));
          if(selected!==undefined && borrowed!==selected) fail('6ae60 selected position canonical owner changed');
          selected=borrowed;terminalSelected=selected;operandsGuard=selectedGuard;distanceGuard();
          const field=Object.getOwnPropertyDescriptor(selected,axis);distanceGuard();
          if(!field || !('value' in field)) fail(`selected ${axis}: own data property required`);
          if(!field.writable) fail(`selected ${axis}: non-writable field`);
          const current=Object.getOwnPropertyDescriptors(selected)[axis];distanceGuard();
          if(!current || !('value' in current)) fail(`selected ${axis}: own data property changed before store`);
          if(!current.writable) fail(`selected ${axis}: non-writable field before store`);
          const live=primaryStoreDescriptor(selected,axis);
          if(!live || !('value' in live)) fail(`selected ${axis}: live own data property required before store`);
          if(!live.writable) fail(`selected ${axis}: live non-writable field before store`);
          (selected as Record<string,unknown>)[axis]=value;distanceGuard();
        };
        //45204/45238 share the real captured GQR5/data owner with command
        //admission. Only their authenticated zero-angle domain can return.
        const sine=trig(heading(),false);
        const x=sourceFloat(Math.fround(horizontal()*sine),'primary selected X product');distanceGuard();
        storeSelected('x',x);
        const mapping=call(()=>admission().getMappingActor(id)),descriptor=read(mapping,'descriptor4b0');distanceGuard();
        if(typeof descriptor!=='symbol') fail('primary descriptor4b0: owned source identity required');
        const metadata=call(()=>admission().getDescriptorMetadata(id,descriptor));distanceGuard();
        const rawJoint=read(metadata,'byte10');distanceGuard();
        const joint=unsigned(rawJoint,255,'descriptor byte10')<<24>>24;
        const row=call(()=>world.getWorldMatrix(id,joint));distanceGuard();
        const height=read(row,'7');distanceGuard();
        storeSelected('y',sourceFloat(height,'primary selected world row7'));
        const cosine=trig(heading(),true);
        const z=sourceFloat(Math.fround(horizontal()*cosine),'primary selected Z product');distanceGuard();
        storeSelected('z',z);
        // The source reloads actualcc only after the completed primary path.
        // A nonnull value is compared, not dereferenced or substituted for c8.
        ccReached=true;distanceGuard();
        noShadows(actor,['204','205','206','207']);
        const ccField=Object.getOwnPropertyDescriptor(actor,'visibilityTarget');distanceGuard();
        if(!ccField || !('value' in ccField)) fail('8006b1d0 visibilityTarget: own data property required');
        const secondary=ccField.value;
        if(secondary!==null) record(secondary,'8006b1d0 visibilityTarget');
        secondaryReached=true;distanceGuard();
        let secondaryPositionGuard=(): void=>{};
        let aimed: object|undefined;
        const aimGuard=(): void=>{
          selectedGuard();secondaryPositionGuard();
          if(aimed!==undefined) {
            const commandRuntime=admission();
            for(const owner of [actor,binding,aimed,commandRuntime.getData(),commandRuntime.getWorldBinding(id),
              commandRuntime.getStatusBinding(id),commandRuntime.getMappingActor(id),commandRuntime.getActionBinding(id)])
              noShadows(owner,aimAliases);
            if(call(()=>commandRuntime.getAimPositionOwner(id))!==aimed)
              fail('6ae60 aimOrigin518 canonical owner changed');
            const direct=[sources,globals,data!,...retained.values(),...massActors.values()];
            if(direct.includes(aimed)) fail('6ae60 aimOrigin518 aliases outer source storage');
            const references: object[]=[...direct,...root.getRetainedStorageOwners(),...scheduler.getRetainedStorageOwners(),
              ...dispatch.getRetainedStorageOwners(),...allocator.getRetainedStorageOwners(),
              ...world.getRetainedActorOwners(),...world.getRetainedMatrixOwners(),...commandRuntime.getKnownStorageOwners(),
              ...commandRuntime.getActionRuntime().getRetainedStorageOwners(),...status.getRetainedStorageOwners()];
            for(const owner of references) {
              if(owner===aimed) continue;
              const fields: PropertyDescriptorMap=Object.getOwnPropertyDescriptors(owner);basicGuard();
              for(const [key,p] of Object.entries(fields)) if('value' in p && p.value===aimed && !(owner===actor && key==='aimOrigin518'))
                fail('6ae60 aimOrigin518 aliases canonical reference');
            }
          }
          selectedGuard();
        };
        const storeAim=(axis: 'x'|'y'|'z',value: number): void=>{
          aimReached=true;distanceGuard();
          const borrowed=call(()=>admission().getAimPositionOwner(id));
          if(aimed!==undefined && aimed!==borrowed) fail('aimOrigin518 canonical owner changed');
          aimed=borrowed;terminalAim=aimed;operandsGuard=aimGuard;distanceGuard();
          for(const owner of [actor,binding,aimed,admission().getData(),admission().getWorldBinding(id),
            admission().getStatusBinding(id),admission().getMappingActor(id),admission().getActionBinding(id)])
            noShadows(owner,aimAliases);
          const field=Object.getOwnPropertyDescriptor(aimed,axis);distanceGuard();
          if(!field || !('value' in field)) fail(`aim ${axis}: own data property required`);
          if(!field.writable) fail(`aim ${axis}: non-writable field`);
          const current=Object.getOwnPropertyDescriptors(aimed)[axis];distanceGuard();
          if(!current || !('value' in current)) fail(`aim ${axis}: own data property changed before store`);
          if(!current.writable) fail(`aim ${axis}: non-writable field before store`);
          terminalSecondary();
          const live=primaryStoreDescriptor(aimed,axis);
          if(!live || !('value' in live)) fail(`aim ${axis}: live own data property required before store`);
          if(!live.writable) fail(`aim ${axis}: live non-writable field before store`);
          (aimed as Record<string,unknown>)[axis]=value;distanceGuard();
        };
        if(secondary!==null) {
          //b1dc captures admission+c8 once. Actual+cc only selects this branch;
          //it is never dereferenced or used as the original OBJECT provider.
          c8Reached=true;distanceGuard();
          const provider=load(binding,'pointerc8');distanceGuard();
          const captured=record(provider,'8006b1dc captured secondary pointerc8');
          const object=call(()=>allocator.getPointerIdentity(captured));distanceGuard();
          //The copy dereferences an original OBJECT, not descriptor memory
          //or an external actor registered under another pointer identity.
          call(()=>allocator.getObject(object));distanceGuard();
          const word=(offset: number): number=>{
            const value=call(()=>allocator.readU32(object,offset));distanceGuard();return value;
          };
          const storeWord=(axis: 'x'|'y'|'z',bits: number): void=>{
            //The source uses lwz/stw, not lfs/stfs. The canonical numeric aim
            //owner supports every finite f32 bit pattern, including -0. Reject
            //NaN/Inf only at this reached store, not at either earlier load.
            if((bits&0x7f800000)===0x7f800000)
              fail(`secondary aim ${axis}: unsupported nonfinite integer-copy bits`);
            const view=new DataView(new ArrayBuffer(4));view.setUint32(0,bits,false);
            storeAim(axis,view.getFloat32(0,false));
          };
          const xWord=word(0x64),yWord=word(0x68);
          storeWord('x',xWord);storeWord('y',yWord);
          const zWord=word(0x6c);storeWord('z',zWord);
          //b1e0 forms an inline address, not a position operand load. Defer
          //the numeric-vector admission until the reached bc88 call.
          const {position,guard:positionGuard}=preparePosition();
          secondaryPositionGuard=positionGuard;operandsGuard=aimGuard;distanceGuard();
          const processor=call(()=>root.getVectorProcessorProfile());distanceGuard();
          if(processor===undefined) fail('8006b208 reached authenticated8020bc88 PSVECSquareDistance; explicit processor profile unavailable');
          if(processor===position) fail('6ae60 position20 aliases processor storage');
          const distance=readSourceSquareDistance({a:position,aName:'position20',b:captured,bRepresentation:'record',
            allocator,root,processor,guard:distanceGuard});
          const positiveGuard=(): void=>{
            distanceGuard();
            if(call(()=>root.getVectorProcessorProfile())!==processor) fail('secondary estimator processor profile owner changed');
            distanceGuard();
          };
          const estimate=(square: number,address: '8006b218'|'8006b298'): number=>{
            // The root owns this already captured profile. Retain its declaration
            // for a callback-free terminal link check before either result store.
            estimatorProcessor=processor;positiveGuard();
            if(estimatorProcessorSource===undefined) {
              const links=call(()=>root.getRetainedStorageOwners()).filter(owner=>{
                const field=primaryStoreDescriptor(owner,'processor');
                return field && 'value' in field && field.value===processor;
              });
              if(links.length!==1) fail('secondary estimator canonical processor declaration required');
              estimatorProcessorSource=links[0];
            }
            return readSourceTargetDistance(square,processor,data!,positiveGuard,address);
          };
          const total=distance>constant('float80437658',0,'8006b20c')
            ? estimate(distance,'8006b218'):distance;
          store('targetDistance760',total);
          const zero=constant('float80437658',0,'8006b268');
          const scalar=(axis: 'x'|'z'): number=>{
            const value=read(position,axis);distanceGuard();return sourceFloat(value,axis);
          };
          const ax=scalar('x'),bx=call(()=>allocator.readF32(object,0x64));distanceGuard();
          const az=scalar('z'),bz=call(()=>allocator.readF32(object,0x6c));distanceGuard();
          const dx=addSourceFloat32(ax,-bx),dz=addSourceFloat32(az,-bz);distanceGuard();
          const xx=sourceFloat(Math.fround(dx*dx),'secondary horizontal X square'),
            zz=sourceFloat(Math.fround(dz*dz),'secondary horizontal Z square');distanceGuard();
          const horizontal=addSourceFloat32(xx,zz);distanceGuard();
          const horizontalDistance=horizontal>zero
            ? estimate(horizontal,'8006b298'):horizontal;
          store('horizontalDistance764',horizontalDistance);
          return; //b2e8 rejoins the same b33c second-pass continuation.
        }
        const secondaryMissing=constant('float80437678',20000,'8006b2ec');
        store('horizontalDistance764',secondaryMissing);store('targetDistance760',secondaryMissing);
        const secondaryHorizontal=(): number=>{
          const value=read(actor,'horizontalDistance764');distanceGuard();return sourceFloat(value,'horizontalDistance764');
        };
        const secondarySine=trig(heading(),false);
        const sx=sourceFloat(Math.fround(secondaryHorizontal()*secondarySine),'secondary X product');distanceGuard();
        storeAim('x',sx);
        const secondaryMapping=call(()=>admission().getMappingActor(id)),secondaryDescriptor=read(secondaryMapping,'descriptor4b0');distanceGuard();
        if(typeof secondaryDescriptor!=='symbol') fail('secondary descriptor4b0: owned source identity required');
        const secondaryMetadata=call(()=>admission().getDescriptorMetadata(id,secondaryDescriptor));distanceGuard();
        const secondaryByte=read(secondaryMetadata,'byte10');distanceGuard();
        const secondaryJoint=unsigned(secondaryByte,255,'secondary descriptor byte10')<<24>>24;
        const secondaryRow=call(()=>world.getWorldMatrix(id,secondaryJoint));distanceGuard();
        const secondaryHeight=read(secondaryRow,'7');distanceGuard();
        storeAim('y',sourceFloat(secondaryHeight,'secondary world row7'));
        const secondaryCosine=trig(heading(),true);
        const sz=sourceFloat(Math.fround(secondaryHorizontal()*secondaryCosine),'secondary Z product');distanceGuard();
        storeAim('z',sz);
        //b33c..b348 advance the same second-pass loop; existing third-pass
        //canonical508 admission remains mandatory even for inactive rows.
        return;
      }
      record(targetPointer,'6ae60 primary pointer508');
      // Snapshot host references before the public504/position/GQR observers.
      // This is native metadata only: B remains unadmitted until its first
      // actual paired load. A callback must not bless a newly added alias as
      // an initial allocator/selector reference by preceding the first store.
      distanceGuard();
      const providerOwners=[...terminalRecords,...terminalRecords.flatMap(owner=>
        Object.values(primaryStoreDescriptors(owner)).flatMap(p=>'value' in p && p.value!==null && typeof p.value==='object'?[p.value as object]:[]))];
      const providerSnapshots=[...new Set(providerOwners)].map(owner=>({owner,fields:primaryStoreDescriptors(owner)}));
      //af98 captures504 before forming both vector addresses. Pointer-domain
      //admission for B is deferred until its first actual paired load.
      const provider=load(binding,'pointer504');
      primaryProviderReferences=new Map();
      for(const {owner,fields} of providerSnapshots) for(const [key,p] of Object.entries(fields))
        if('value' in p && p.value===provider) {
          const keys=primaryProviderReferences.get(owner)??new Set<string>();keys.add(key);primaryProviderReferences.set(owner,keys);
        }
      const {position,guard:positionGuard}=preparePosition();
      operandsGuard=positionGuard;positionGuard();
      const processor=call(()=>root.getVectorProcessorProfile());
      if(processor===undefined) fail('8006afac reached authenticated8020bc88 PSVECSquareDistance; explicit processor profile unavailable');
      if(processor===position) fail('6ae60 position20 aliases processor storage');
      const distance=readSourceSquareDistance({a:position,aName:'position20',b:provider,bRepresentation:'record',
        allocator,root,processor,guard:positionGuard});
      primaryProvider=record(provider,'captured primary OBJECT');
      primaryObject=call(()=>allocator.getPointerIdentity(primaryProvider!));
      if(call(()=>allocator.getObject(primaryObject!))!==primaryProvider) fail('primary captured OBJECT bytes required');
      primaryReached=true;
      const positiveGuard=(): void=>{
        distanceGuard();
        if(call(()=>root.getVectorProcessorProfile())!==processor) fail('primary estimator processor profile owner changed');
        distanceGuard();
      };
      const estimate=(square: number,address: '8006afbc'|'8006b03c'): number=>{
        estimatorProcessor=processor;positiveGuard();
        if(estimatorProcessorSource===undefined) {
          const links=call(()=>root.getRetainedStorageOwners()).filter(owner=>{
            const p=primaryStoreDescriptor(owner,'processor');return p && 'value' in p && p.value===processor;
          });
          if(links.length!==1) fail('primary estimator canonical processor declaration required');
          estimatorProcessorSource=links[0];
        }
        return readSourceTargetDistance(square,processor,data!,positiveGuard,address);
      };
      //afbc..b004: model-backed seed, half then three, three binary64
      //q/h/fnmsub/e rounds, product/frsp and stack+14 store/reload.
      const total=distance>constant('float80437658',0,'8006afb0')?estimate(distance,'8006afbc'):distance;
      store('targetDistance758',total);
      const zero=constant('float80437658',0,'8006b00c');
      //These are ordinary scalar lfs loads. No GQR read or vector snapshot.
      const scalar=(owner: object,key: string): number=>{
        const value=read(owner,key);distanceGuard();return sourceFloat(value,key);
      };
      const ax=scalar(position,'x');
      const object=call(()=>allocator.getPointerIdentity(record(provider,'captured primary OBJECT')));distanceGuard();
      const bx=call(()=>allocator.readF32(object,0x64));distanceGuard();
      const az=scalar(position,'z'),bz=call(()=>allocator.readF32(object,0x6c));distanceGuard();
      const dx=addSourceFloat32(ax,-bx),dz=addSourceFloat32(az,-bz);distanceGuard();
      const xx=sourceFloat(Math.fround(dx*dx),'primary horizontal X square'),
        zz=sourceFloat(Math.fround(dz*dz),'primary horizontal Z square');distanceGuard();
      const horizontal=addSourceFloat32(xx,zz);distanceGuard();
      //b03c..b084 repeats that schedule with stack+10, without a GQR load.
      const horizontalDistance=horizontal>zero?estimate(horizontal,'8006b03c'):horizontal;
      store('horizontalDistance75c',horizontalDistance);
      //b094 reloads508, even if an observer changed it after the initial compare.
      const fresh=read(binding,'pointer508');distanceGuard();
      if(fresh!==null) record(fresh,'6ae60 fresh primary pointer508');
      fail('8006b098 reached mandatory8006d228 primary direction helper');
    };
    //8006ae78 captures base once. Signed active!=0, six unrolled physical rows.
    const initial=physical();
    for(let index=0;index<6;index++) {
      const {id,actor}=actorAt(initial,index);
      if(s8(byte(actor,'active0'))===0) continue;
      actualByte(actor,'byte58a');actualByte(actor,'byte58b');actualByte(actor,'byte58c');actualByte(actor,'byte58d');
      const action=command(id,actor,true);
      noShadows(actor,['byte7d2','byte7D2','field7d2','flags7d2','2002']);
      noShadows(action,['byte7D2','field7d2','flags7d2','2002']);
      write(action,'byte7d2',0);
      actualByte(actor,'byte7d3');
    }
    //8006af5c reload. Status is reached only after the signed active test.
    const second=physical();
    for(let index=0;index<6;index++) {
      const {id,actor}=actorAt(second,index);
      if(s8(byte(actor,'active0'))===0) continue;
      if(root.getStageRuntime()!==stage || call(()=>stage.getActualActor(id))!==actor)
        fail('6ae60 canonical stage actor differs');
      const binding=record(call(()=>stage.getActorBinding(id)),'6ae60 same lifecycle18 binding');
      if(binding===actor || [...retained.values()].includes(binding)) fail('6ae60 stage source storage alias');
      if(s8(byte(binding,'lifecycle18'))>=1) {
        const present=Object.getOwnPropertyDescriptor(target,'slotStatus');check();
        if(present===undefined) fail('8006af80 reached mandatory8006b450 target-selection predecessor');
        const helper=read(target,'slotStatus'),action=admission().getActionRuntime(),
          canonical=call(()=>action.getSlotStatusRuntime());
        if(helper!==canonical || canonical===undefined || canonical.getSchedulerRuntime()!==scheduler)
          fail('6b450 exact shared slot-status/scheduler owner required');
        call(()=>action.prepareTarget(id));
        const dispatchPresent=Object.getOwnPropertyDescriptor(target,'targetDispatch');check();
        if(dispatchPresent===undefined) fail('8006af88 reached mandatory8006b7f4 target-dispatch predecessor');
        const dispatch=read(target,'targetDispatch');
        if(!isSourceActorTargetDispatchRuntime(dispatch) || dispatch.getSchedulerRuntime()!==scheduler)
          fail('6b7f4 exact genuine target-dispatch/scheduler owner required');
        call(()=>dispatch.dispatchActor(id));
        primaryDistance(id,actor,dispatch);
      }
    }
    //8006b358 reload. The active BYTE LOAD precedes the unconditional508
    // pointer load, but the active TEST follows it. Inactive rows still need
    // their genuine existing508 binding; no default-null pointer is admitted.
    const third=physical();
    for(let index=0;index<6;index++) {
      const {id,actor}=actorAt(third,index),active=byte(actor,'active0');
      const binding=command(id,actor,false);
      noShadows(actor,['pointer508','field508','byte508','byte509','byte50a','byte50b','byte50A','byte50B',
        '1288','1289','1290','1291']);
      noShadows(binding,['field508','byte508','byte509','byte50a','byte50b','byte50A','byte50B',
        '1288','1289','1290','1291']);
      const pointer=read(binding,'pointer508');
      if(pointer!==null) record(pointer,'6ae60 pointer508');
      if(s8(active)===0 || pointer===null) continue;
      //8006b374 reads the captured target, not a reloaded actor508. This
      // bounded domain accepts a genuine actor bound to this SAME allocator
      // and world; its canonical83 is already allocation-owned, not a new
      // eligibility83 field copied onto the actual actor or an ad hoc target.
      // Final metadata snapshots use the retained native intrinsic. For the
      // declared synchronous nonproxy records these checks cannot invoke the
      // observer that just ran, nor read any captured source scalar again.
      const terminalRead=(record:object,key:string):unknown=>{
        const field=primaryStoreDescriptor(record,key);
        if(!field || !('value' in field))fail(`${key}: terminal own data property required`);
        return field.value;
      };
      const terminalShadows=(record:object,keys:readonly string[]):void=>{
        for(const key of keys)if(primaryStoreDescriptor(record,key)!==undefined)fail(`${key}: competing source cell owner`);
      };
      const selected=(()=>{
        try {
          const runtime=admission();
          const targetId=call(()=>allocator.getPointerIdentity(record(pointer,'6b374 captured target')));
          const targetActor=actual(targetId);
          const owner=record(call(()=>allocator.getActorBinding(targetId)),'6b374 canonical allocation83');
          const finish=():void=>{
            if(terminalRead(sources,'targetPreparation')!==target || terminalRead(target,'admission')!==runtime ||
              spawns.getAdmissionRuntime()!==runtime || runtime.getActualActor(id)!==actor ||
              runtime.getActorBinding(id)!==binding || world.getActualActor(id)!==actor || status.getActualActor(id)!==actor ||
              allocator.getActualActor(targetId)!==targetActor || allocator.getPointerTarget(targetId)!==targetActor ||
              allocator.getActorBinding(targetId)!==owner || world.getActualActor(targetId)!==targetActor)
              fail('6b374 terminal canonical caller/target owner changed');
            terminalShadows(actor,['pointer508','field508','byte508','byte509','byte50a','byte50b','byte50A','byte50B','1288','1289','1290','1291']);
            terminalShadows(binding,['field508','byte508','byte509','byte50a','byte50b','byte50A','byte50B','1288','1289','1290','1291']);
            const worldOwner=world.getActorBinding(targetId);
            for(const candidate of new Set([targetActor,worldOwner,...allocator.getSourceOwners(targetId)])) {
              if(candidate!==owner)terminalShadows(candidate,['byte83']);
              terminalShadows(candidate,['eligibility83','groupEligibility83','field83']);
              if(candidate===targetActor || candidate===worldOwner || candidate===owner)terminalShadows(candidate,['131']);
            }
            check();requireCompleteSourceActorDoubleLifecycle(actor);requireCompleteSourceActorDoubleLifecycle(targetActor);
            runtime.assertActorComplete(id);allocator.assertActorComplete(targetId);check();
          };
          const guard=(): void=>{
            check();requireCompleteSourceActorDoubleLifecycle(actor);
            call(()=>admission().assertActorComplete(id));
            if(command(id,actor,false)!==binding)fail('6b374 captured caller admission changed');
            noShadows(actor,['pointer508','field508','byte508','byte509','byte50a','byte50b','byte50A','byte50B','1288','1289','1290','1291']);
            noShadows(binding,['field508','byte508','byte509','byte50a','byte50b','byte50A','byte50B','1288','1289','1290','1291']);
            requireCompleteSourceActorDoubleLifecycle(targetActor);
            call(()=>allocator.assertActorComplete(targetId));
            if(targetActor!==pointer || call(()=>allocator.getActualActor(targetId))!==targetActor ||
              call(()=>world.getActualActor(targetId))!==targetActor ||
              call(()=>allocator.getPointerTarget(targetId))!==targetActor ||
              call(()=>allocator.getActorBinding(targetId))!==owner)
              fail('6b374 canonical target/allocator/world owner differs');
            if(owner===targetActor || [...retained.values()].includes(owner) || [...massActors.values()].includes(owner))
              fail('6b374 allocation83 storage alias');
            const worldOwner=call(()=>world.getActorBinding(targetId));
            const records=[targetActor,worldOwner,...call(()=>allocator.getSourceOwners(targetId))];
            for(const candidate of new Set(records)) {
              if(candidate!==owner)noShadows(candidate,['byte83']);
              noShadows(candidate,['eligibility83','groupEligibility83','field83']);
              // An unrelated allocated byte buffer legitimately has offset131.
              // Numeric actor aliases apply only to these actor-role records.
              if(candidate===targetActor || candidate===worldOwner || candidate===owner)noShadows(candidate,['131']);
            }
            finish();
          };
          guard();const captured=byte(owner,'byte83');guard();return {captured,targetActor,targetId,owner,runtime,guard,finish};
        } catch(error) {fail(`8006b374 target83 ownership/load refused: ${String(error)}`);}
      })();
      if(s8(selected.captured)!==0) continue;
      let teamsReached=false,distanceReached=false,threshold:object|undefined;
      let attributeRuntime:SourceActorAttributeRefreshRuntime|undefined,attributeMass:object|undefined;
      const associationMetadata=(shadows:(owner:object,keys:readonly string[])=>void,
        peek:(owner:object,key:string)=>unknown):void=>{
        const runtime=selected.runtime;
        const records=[actor,selected.targetActor,binding,selected.owner,globals,sources,
          runtime.getWorldBinding(id),runtime.getStatusBinding(id),runtime.getMappingActor(id),
          runtime.getAttributeBinding(id),runtime.getChargeBinding(id),runtime.getActionBinding(id),
          runtime.getCueBinding(id),runtime.getDispatchBinding(id),runtime.getStartBinding(id),runtime.getStreamBinding(id),
          world.getActorBinding(selected.targetId)];
        const actuals=world.getRetainedActorOwners();
        for(const candidate of new Set(records)) {
          if(!actuals.includes(candidate))shadows(candidate,['byte7d3']);
          shadows(candidate,['byte7D3','field7d3','field7D3','flags7d3','mask7d3']);
          if(candidate===actor)shadows(candidate,['2003']);
          if(teamsReached) {
            if(!actuals.includes(candidate))shadows(candidate,['team']);
            shadows(candidate,['byte88','field88']);
            if(candidate===actor || candidate===selected.targetActor)shadows(candidate,['136']);
          }
          if(distanceReached) {
            if(!actuals.includes(candidate))shadows(candidate,['horizontalDistance75c']);
            shadows(candidate,['field75c','field75C','float75c','float75C']);
            if(candidate===actor)shadows(candidate,['1884','1885','1886','1887','byte75c','byte75d','byte75e','byte75f','byte75C','byte75D','byte75E','byte75F']);
          }
          if(threshold!==undefined) {
            if(candidate!==threshold)shadows(candidate,['field814']);
            shadows(candidate,['float814','threshold814']);
            if(candidate===actor || candidate===threshold)shadows(candidate,['2068','2069','2070','2071','byte814','byte815','byte816','byte817']);
          }
        }
        if(threshold!==undefined && (runtime.getAttributeBinding(id)!==threshold ||
          status.getAttributeBinding(id)!==threshold || !attributeRuntime || !attributeMass ||
          peek(sources,'massPreparation')!==attributeMass || peek(attributeMass,'attributes')!==attributeRuntime ||
          attributeRuntime.getActualActor(id)!==actor || attributeRuntime.getActorBinding(id)!==threshold))
          fail('6b3a8 canonical814 owner changed');
      };
      const associationGuard=():void=>{
        selected.guard();associationMetadata(noShadows,read);selected.guard();
        associationMetadata(terminalShadows,terminalRead);selected.finish();
      };
      const associationLoad=(owner:object,key:string):unknown=>{
        associationGuard();const value=read(owner,key);associationGuard();return value;
      };
      //8006b380..388: bit0 only, not a truthiness test on the whole byte.
      const flags=unsigned(associationLoad(actor,'byte7d3'),255,'byte7d3');
      if((flags&1)!==0)continue;
      //8006b38c..3a0: target team BEFORE caller team; retain captured signed
      // values even if either source cell changes during the following load.
      teamsReached=true;
      const targetTeam=s8(unsigned(associationLoad(selected.targetActor,'team'),255,'target team'));
      const callerTeam=s8(unsigned(associationLoad(actor,'team'),255,'caller team'));
      if(targetTeam===callerTeam)continue;
      //8006b3a4..3b0: finite exact-f32 host domain only. Source skips on GT,
      // not on !(LT||EQ). NaN/unordered and general FPSCR are not implemented.
      distanceReached=true;
      const finite=(value:unknown,key:string):number=>{
        if(typeof value!=='number' || !Number.isFinite(value) || !Object.is(value,Math.fround(value)))
          fail(`${key}: finite exact source float32 required`);return value;
      };
      const distance=finite(associationLoad(actor,'horizontalDistance75c'),'horizontalDistance75c');
      const mass=retained.get('massPreparation');
      if(!mass || read(sources,'massPreparation')!==mass)fail('6b3a8 canonical mass attribute ingress changed');
      const attributes=read(mass,'attributes');
      if(!isSourceActorAttributeRefreshRuntime(attributes) || call(()=>attributes.getActualActor(id))!==actor)
        fail('6b3a8 genuine same-actor attribute owner required');
      attributeRuntime=attributes;attributeMass=mass;
      threshold=record(call(()=>attributes.getActorBinding(id)),'6b3a8 canonical attribute814');
      const limit=finite(associationLoad(threshold,'field814'),'field814');
      if(distance>limit)continue;
      //8006b3bc captures a FRESH physical base for each admitted outer actor.
      // The inner index is a physical position, not actor.slot or a roster
      // entry. Only a mask hit dereferences that candidate's actual record.
      associationGuard();const inner=physical();associationGuard();
      const innerMass=retained.get('massPreparation')!,innerBlock=retained.get('mass physicalBlock')!;
      let candidate:{id:symbol;actor:object}|undefined,maskReached=false;
      const flagOwners=new Set<object>();
      const innerMetadata=(shadows:(owner:object,keys:readonly string[])=>void):void=>{
        if(terminalRead(sources,'massPreparation')!==innerMass || terminalRead(innerMass,'physicalBlock')!==innerBlock ||
          terminalRead(innerBlock,'identities')!==inner || retained.get('mass physical identities')!==inner)
          fail('6b3bc captured inner physical metadata changed');
        const records=[selected.targetActor,selected.owner,world.getActorBinding(selected.targetId),binding];
        if(candidate!==undefined) {
          if(allocator.getPointerTarget(candidate.id)!==candidate.actor ||
            world.getActualActor(candidate.id)!==candidate.actor)
            fail('6b3e8 canonical candidate actor changed');
          records.push(candidate.actor,world.getActorBinding(candidate.id));
        }
        const actuals=world.getRetainedActorOwners();
        for(const owner of new Set(records)) {
          if(maskReached) {
            if(!actuals.includes(owner))shadows(owner,['byte58a']);
            shadows(owner,['byte58A','field58a','field58A','flags58a','mask58a']);
            if(owner===selected.targetActor)shadows(owner,['1418']);
          }
          if(candidate!==undefined) {
            if(!actuals.includes(owner))shadows(owner,['team']);
            shadows(owner,['byte88','field88']);
            if(owner===candidate.actor)shadows(owner,['136']);
          }
          if(flagOwners.size!==0) {
            if(!actuals.includes(owner))shadows(owner,['byte7d3']);
            shadows(owner,['byte7D3','field7d3','field7D3','flags7d3','mask7d3']);
            if(flagOwners.has(owner))shadows(owner,['2003']);
          }
        }
      };
      const innerFinish=():void=>{
        innerMetadata(terminalShadows);
        if(candidate!==undefined) {
          requireCompleteSourceActorDoubleLifecycle(candidate.actor);
        }
        associationMetadata(terminalShadows,terminalRead);selected.finish();
      };
      const innerGuard=():void=>{
        associationGuard();innerMetadata(noShadows);associationGuard();innerFinish();
      };
      const innerLoad=(owner:object,key:string):number=>{
        innerGuard();const value=read(owner,key);innerGuard();return unsigned(value,255,key);
      };
      const storeFlag=(owner:object,value:number):void=>{
        innerGuard();const field=Object.getOwnPropertyDescriptor(owner,'byte7d3');innerGuard();
        if(!field || !('value' in field))fail('byte7d3: own data property required before association store');
        if(!field.writable)fail('byte7d3: non-writable association destination');
        const live=primaryStoreDescriptor(owner,'byte7d3');
        if(!live || !('value' in live))fail('byte7d3: live own data property required before association store');
        if(!live.writable)fail('byte7d3: live non-writable association destination');
        // No observable metadata callback between this final native snapshot
        // and the existing own-data overwrite. Earlier completed stores stay.
        (owner as Record<string,unknown>).byte7d3=value;innerGuard();
      };
      for(let position=0;position<6;position++) {
        candidate=undefined;
        if(position===index)continue; //3cc..3d0 BEFORE the target58a load.
        maskReached=true;
        const mask=s8(innerLoad(selected.targetActor,'byte58a'));
        if((mask&(1<<position))===0)continue;
        candidate=actorAt(inner,position);innerGuard();
        const candidateTeam=s8(innerLoad(candidate.actor,'team'));
        if(candidateTeam!==callerTeam)continue; // captured r8, not a fresh caller team.
        //3f8..418: three distinct fresh read/modify/store pairs. In particular
        // candidate===target must observe the preceding bit1 store before OR2.
        flagOwners.add(actor);const callerFlags=innerLoad(actor,'byte7d3');storeFlag(actor,callerFlags|1);
        flagOwners.add(candidate.actor);const candidateFlags=innerLoad(candidate.actor,'byte7d3');storeFlag(candidate.actor,candidateFlags|1);
        flagOwners.add(selected.targetActor);const targetFlags=innerLoad(selected.targetActor,'byte7d3');storeFlag(selected.targetActor,targetFlags|2);
        break; //3bc reloads again only for the next admitted outer actor.
      }
    }
    //Genuine void return only if every reached canonical508 owner completed.
  };
  /** Complete authenticated80027764. The discarded RNG result still advances
   * the SAME live byte owner. Initial row38 copies are not leader pointers.
   * Source leaders are local registers; each nonnull publication reloads base0.
   * Stable canonical records remain a host bound, not inferred source aliases. */
  const prepareLeaders=(): void=>{
    const mass=retained.get('massPreparation');
    if(!mass) fail('80027770 missing canonical mass/RNG ingress');
    randomByte(mass,'80027770');
    const world=spawns.getWorldRuntime(),actorFields=new Set<string>(),rows=new Map<number,object>();
    const capturedActors=new Map<symbol,object>();
    let capturedTable:object|undefined,blockReached=false;
    const terminalShadows=(owner:object,keys:readonly string[]):void=>{
      for(const key of keys)if(primaryStoreDescriptor(owner,key)!==undefined)fail(`${key}: competing source cell owner`);
    };
    const aliases:Record<string,readonly string[]>={
      pointer330:['word330','field330','leader330',...Array.from({length:4},(_,i)=>0x330+i).flatMap(n=>[String(n),'byte'+n.toString(16)])],
      byte334:['field334','score334','820'],byte335:['field335','leader335','821'],
      team:['byte88','field88','136'],active0:['byte0','0'],
    };
    const metadata=(shadows:typeof noShadows):void=>{
      const actuals=world.getRetainedActorOwners();
      const records=[sources,globals,...retained.values(),...massActors.values(),
        ...scheduler.getRetainedStorageOwners(),...actuals];
      for(const owner of new Set(records))for(const key of actorFields) {
        if(!actuals.includes(owner))shadows(owner,[key]);
        // Numeric actor offsets do not alias independent allocator byte buffers.
        shadows(owner,aliases[key]!.filter(alias=>!/^\d+$/.test(alias)||actuals.includes(owner)));
      }
      for(const [index,row]of rows) {
        const start=0xf4+index*0x3c+0x38;
        shadows(row,['word38','field38','leader38','56','57','58','59','byte38','byte39','byte3a','byte3b','byte3A','byte3B']);
        shadows(globals,[...Array.from({length:4},(_,i)=>start+i).flatMap(n=>[String(n),'byte'+n.toString(16),'byte'+n.toString(16).toUpperCase()]),
          ...['pointer','word','field'].flatMap(prefix=>[prefix+start.toString(16),prefix+start.toString(16).toUpperCase()])]);
      }
    };
    const finish=():void=>{
      check();metadata(terminalShadows);
      if(terminalRead(sources,'scheduler')!==scheduler || scheduler.getRootRuntime()!==root ||
        root.getSpawnRuntime()!==spawns || spawns.getWorldRuntime()!==world || scheduler.getAllocatorRuntime()!==allocator ||
        scheduler.getMatchGlobals()!==globals || spawns.getMatchGlobals()!==globals ||
        terminalRead(sources,'massPreparation')!==mass || retained.get('massPreparation')!==mass)
        fail('27764 terminal canonical graph changed');
      if(blockReached) {
        const block=retained.get('mass physicalBlock'),ids=retained.get('mass physical identities');
        if(!block || !ids || terminalRead(mass,'physicalBlock')!==block || terminalRead(block,'identities')!==ids)
          fail('27764 canonical physical metadata changed');
      }
      if(capturedTable!==undefined && terminalRead(globals,'teamRows103')!==capturedTable)
        fail('27764 canonical team table changed');
      for(const [index,row]of rows)if(terminalRead(capturedTable!,String(index))!==row)
        fail('27764 canonical team row changed');
      for(const [id,actor]of capturedActors) {
        if(allocator.getPointerTarget(id)!==actor || world.getActualActor(id)!==actor)
          fail('27764 canonical actual actor changed');
        requireCompleteSourceActorDoubleLifecycle(actor);
      }
      check();
    };
    const guard=():void=>{check();metadata(noShadows);finish();};
    const store=(owner:object,key:string,value:number|symbol|null):void=>{
      guard();own(owner,key,true);guard();
      const destination=primaryStoreDescriptor(owner,key);
      if(!destination || !('value'in destination))fail(`${key}: live own data property required`);
      if(!destination.writable)fail(`${key}: live non-writable field`);
      (owner as Record<string,unknown>)[key]=value;guard();
    };
    const rowStore=(index:number,value:symbol|null,owner:object=match()):void=>{
      const table=teamTable(owner),row=team(table,index);
      if(capturedTable!==undefined && table!==capturedTable)fail('27764 canonical team table changed');
      capturedTable=table;rows.set(index,row);store(row,'pointer38',value);
    };
    //27778..7b4: pointer copies only. Null/opaque slot2 or1 is not dereferenced.
    const firstOwner=match(),slot2=slotPointer(2);
    if(firstOwner!==globals)fail('27764 initial match owner changed');
    rowStore(0,slot2,firstOwner);
    const slot1=slotPointer(1);rowStore(1,slot1);
    rowStore(2,null);rowStore(3,null);
    const physical=():readonly symbol[]=>{
      guard();const base=slotPointer(0),block=retained.get('mass physicalBlock'),ids=retained.get('mass physical identities');
      if(!block || !ids || read(sources,'massPreparation')!==mass || read(mass,'physicalBlock')!==block ||
        read(block,'identities')!==ids || read(block,'base')!==base)
        fail('27764 physical base differs from canonical block');
      if(!Array.isArray(ids)||!Object.isFrozen(ids)||read(ids,'length')!==6)fail('27764 six frozen physical identities required');
      blockReached=true;guard();return ids as readonly symbol[];
    };
    const at=(ids:readonly symbol[],index:number):{id:symbol;actor:object}=>{
      const id=read(ids,String(index));if(typeof id!=='symbol')fail('27764 physical actor identity required');
      const actor=actual(id);capturedActors.set(id,actor);guard();return{id,actor};
    };
    const load=(actor:object,key:'active0'|'team'|'byte334'):number=>{
      if(key==='byte334')actorFields.add(key);else noShadows(actor,aliases[key]!);
      guard();const value=byte(actor,key);guard();return value;
    };
    const put=(actor:object,key:'pointer330'|'byte335',value:symbol|null|number):void=>{
      actorFields.add(key);store(actor,key,value);
    };
    const initial=physical(),leaders:({id:symbol;actor:object}|undefined)[]=[undefined,undefined],best=[0,0];
    for(let index=0;index<6;index++) {
      const selected=at(initial,index),actor=selected.actor;
      if(s8(load(actor,'active0'))===0)continue;
      put(actor,'byte335',0);put(actor,'pointer330',null);
      const group=s8(load(actor,'team'));if(group!==0&&group!==1)continue;
      const score=load(actor,'byte334');
      if(s8(score)<s8(best[group]!))continue;
      leaders[group]=selected;best[group]=score; // Equality selects the LAST physical candidate.
    }
    for(let group=0;group<2;group++) {
      const leader=leaders[group];if(leader===undefined)continue;
      put(leader.actor,'byte335',1);
      const ids=physical();
      for(let index=0;index<6;index++) {
        const {actor}=at(ids,index);
        if(s8(load(actor,'active0'))===0)continue;
        if(s8(load(actor,'team'))===group)put(actor,'pointer330',leader.id);
      }
    }
    finish(); // Genuine return; the caller next enters8000bef4.
  };
  /** Complete bounded8000bef4; only current canonical inputs, no camera copy. */
  const prepareParticipantViews=():void=>{
    const captured=system(),world=spawns.getWorldRuntime(),action=spawns.getAdmissionRuntime().getActionRuntime();
    if(!claimSourceHelperStorage(captured,runtime))fail('participant system storage already claimed');
    let helper:SourceActorSlotStatusRuntime|undefined,special:object|undefined;
    const viewKeys=['pointer14','pointer18','pointer1c','pointer20','byte0c','byte0d','byte0e','byte0f'];
    const reachedSystem=new Set<string>(),reachedMatch=new Set<string>();
    const systemAliases:Record<string,readonly string[]>={
      controllerMask:['byte2','2'],byte40:['64','special40','field40'],byte29:['41','mode29','field29'],
      pointer14:['20','21','22','23','word14','field14','byte14','byte15','byte16','byte17'],
      pointer18:['24','25','26','27','word18','field18','byte18','byte19','byte1a','byte1b'],
      pointer1c:['28','29','30','31','pointer1C','word1c','word1C','field1c','byte1c','byte1d','byte1e','byte1f'],
      pointer20:['32','33','34','35','word20','field20','byte20','byte21','byte22','byte23'],
      byte0c:['12','byteC','bytec','byte0C','field0c'],byte0d:['13','byteD','byted','byte0D','field0d'],
      byte0e:['14','byteE','bytee','byte0E','field0e'],byte0f:['15','byteF','bytef','byte0F','field0f'],
    };
    for(const key of Object.keys(systemAliases))systemAliases[key]=[...new Set(systemAliases[key]!.flatMap(alias=>
      [alias,alias.replace(/^(byte|pointer|word|field)([0-9a-f]+)$/i,(_match,prefix:string,suffix:string)=>prefix+suffix.toUpperCase())]))];
    const terminalShadows=(owner:object,keys:readonly string[]):void=>{
      for(const key of keys)if(primaryStoreDescriptor(owner,key)!==undefined)fail(`${key}: competing participant storage`);
    };
    const metadata=(shadows:typeof noShadows):void=>{
      for(const key of reachedSystem)shadows(captured,systemAliases[key]??[]);
      for(const key of reachedMatch) {
        const hex=key.slice(4).toLowerCase(),offset=parseInt(hex,16);
        shadows(globals,[String(offset),`field${hex}`,`field${hex.toUpperCase()}`,`byte${hex}`,`byte${hex.toUpperCase()}`].filter(alias=>alias!==key));
      }
      if(special)shadows(special,['byte804360DC','global804360dc','804360dc']);
      for(const actor of participantActors.values())shadows(actor,['field487','view487','1159']);
      // The explicit helper owns all player rows. None may double as an
      // outer source/system/match/actor record, including an unreached row.
      if(helper) {
        const owners=[...helper.getRetainedStorageOwners(),...helper.getDeclaredStorageOwners()];check();
        const outer=[sources,globals,captured,...retained.values(),...massActors.values(),...participantActors.values()];
        if(owners.some(owner=>outer.includes(owner)))fail('participant player storage aliases an outer owner');
      }
    };
    const finish=():void=>{
      check();
      if(terminalRead(sources,'scheduler')!==scheduler||terminalRead(sources,'systemGlobals')!==captured||
        scheduler.getRootRuntime()!==root||scheduler.getAllocatorRuntime()!==allocator||root.getSpawnRuntime()!==spawns||
        spawns.getWorldRuntime()!==world||spawns.getMatchGlobals()!==globals||scheduler.getMatchGlobals()!==globals||
        spawns.getAdmissionRuntime().getActionRuntime()!==action)fail('bef4 canonical participant graph changed');
      if(special&&terminalRead(sources,'participantViews')!==special)fail('bef4 special global owner changed');
      if(helper && (action.getSlotStatusRuntime()!==helper || helper.getSchedulerRuntime()!==scheduler))
        fail('bef4 canonical slot-status owner changed');
      for(const [id,actor]of participantActors) {
        if(allocator.getPointerTarget(id)!==actor||world.getActualActor(id)!==actor)fail('bef4 canonical actual actor changed');
        requireCompleteSourceActorDoubleLifecycle(actor);
      }
      // Run observable owner inventories first, then the final native source
      // link/alias checks. Stable nonproxy records cannot invoke application code.
      metadata(noShadows);check();
      if(helper)requireSourceActorActionSlotStatusOwner(action,helper);
      if(terminalRead(sources,'systemGlobals')!==captured||terminalRead(sources,'scheduler')!==scheduler||
        (special&&terminalRead(sources,'participantViews')!==special))fail('bef4 terminal participant owner changed');
      for(const key of reachedSystem)terminalShadows(captured,systemAliases[key]??[]);
      for(const key of reachedMatch) {
        const hex=key.slice(4).toLowerCase();terminalShadows(globals,[String(parseInt(hex,16)),`field${hex}`,`field${hex.toUpperCase()}`,`byte${hex}`,`byte${hex.toUpperCase()}`].filter(alias=>alias!==key));
      }
      for(const actor of participantActors.values())terminalShadows(actor,['field487','view487','1159']);
      for(const [id,actor]of participantActors) {
        if(allocator.getPointerTarget(id)!==actor||world.getActualActor(id)!==actor)fail('bef4 terminal actor changed');
        requireCompleteSourceActorDoubleLifecycle(actor);
      }
      check();
    };
    const systemByte=(key:'byte40'|'controllerMask'|'byte29'):number=>{
      reachedSystem.add(key);noShadows(captured,systemAliases[key]!);
      const value=byte(captured,key);check();return value;
    };
    const sharedHelper=():SourceActorSlotStatusRuntime=>{
      const selected=call(()=>action.getSlotStatusRuntime());
      if(!isSourceActorSlotStatusRuntime(selected)||selected.getSchedulerRuntime()!==scheduler||
        (helper!==undefined&&helper!==selected))fail('bef4 exact shared slot-status owner required');
      helper=selected;finish();return selected;
    };
    const actualSlot=(slot:number):object=>{
      if(!Number.isInteger(slot)||slot<0||slot>=6)fail('bef4 reached actor slot outside bounded six-word table');
      const table=call(()=>scheduler.getActorSlotTable()),id=read(table,String(slot));
      if(typeof id!=='symbol')fail('bef4 nonnull actor slot pointer required');
      if(call(()=>allocator.getInteriorAddress(id))!==null)fail('bef4 actor slot requires a base identity');
      const actor=record(call(()=>allocator.getPointerTarget(id)),'bef4 actual actor');
      if(call(()=>world.getActualActor(id))!==actor)fail('bef4 same canonical world actor required');
      if([sources,globals,captured,...retained.values()].includes(actor))fail('bef4 actor storage alias');
      const old=participantActors.get(id);if(old&&old!==actor)fail('bef4 actor owner changed');
      participantActors.set(id,actor);requireCompleteSourceActorDoubleLifecycle(actor);check();return actor;
    };
    const store=(owner:object,key:string,value:number|symbol):void=>{
      if(owner===captured)reachedSystem.add(key);
      finish();own(owner,key,true);check();finish();
      const destination=primaryStoreDescriptor(owner,key);
      if(!destination||!('value'in destination))fail(`${key}: live own data property required`);
      if(!destination.writable)fail(`${key}: live non-writable field`);
      (owner as Record<string,unknown>)[key]=value;finish();
    };
    const publish=(pointer:symbol,index:number,firstOwner?:object):void=>{
      const pointerKey=viewKeys[index]!,metadataKey=viewKeys[4+index]!;
      store(firstOwner??system(),pointerKey,pointer);
      const value=call(()=>sharedHelper().readViewMetadata(pointer));
      store(system(),metadataKey,value);
    };
    const markSlot=(slot:number,index:number):void=>store(actualSlot(slot),'byte487',index);
    if(s8(systemByte('byte40'))!==0) {
      special=retain('participantViews',read(sources,'participantViews'));
      const slot=s8(byte(special,'byte804360dc'));
      const pointer=call(()=>sharedHelper().getViewPointer(12));
      publish(pointer,0,captured);for(let i=1;i<4;i++)publish(pointer,i);
      markSlot(slot,0);finish();return;
    }
    let fallback=0;
    for(let slot=0;slot<6;slot++) {
      if((s8(systemByte('controllerMask'))&(1<<slot))===0)continue;
      const actor=actualSlot(slot);noShadows(actor,['0','byte0']);
      if(s8(byte(actor,'active0'))!==0){fallback=slot;break;}
    }
    const mode=s8(systemByte('byte29')),count=mode===2?4:mode===1?2:1;
    for(let i=0;i<count;i++) {
      const owner=match(),key=`byteC${i}`;reachedMatch.add(key);
      let selected=s8(byte(owner,key));
      if(selected===-1)selected=fallback;
      else {
        reachedMatch.add('byte15db');const mask=byte(owner,'byte15db'),shift=selected&63;
        const bit=(shift&32)!==0?0:(1<<shift)>>>0;
        if((mask&bit)===0)selected=fallback;
      }
      const status=call(()=>sharedHelper().readSlot(selected));
      const recordIndex=(selected+((status&0x7fffffff)!==0?6:0))|0;
      const pointer=call(()=>sharedHelper().getViewPointer(recordIndex));
      if(mode===2)publish(pointer,i);
      else if(mode===1){publish(pointer,i);publish(pointer,i+2);}
      else for(let view=0;view<4;view++)publish(pointer,view);
      markSlot(selected,i);
    }
    finish();
  };
  const close=(): void=>{
    if(incomplete) return;
    incomplete=true;closing=true;
    for(const actor of massActors.values()) markIncompleteSourceActorDoubleLifecycle(actor);
    for(const actor of participantActors.values()) markIncompleteSourceActorDoubleLifecycle(actor);
    try {closeSourceObjectSchedulerOuterFrame(scheduler,runtime);} finally {closing=false;}
  };
  const invokeScheduler=(callsite:number,group:number):void=>{
    schedulerInvocation={callsite,group,entered:false};
    try {call(()=>invokeSourceObjectSchedulerOuterFrame(scheduler,runtime,callsite,group));}
    finally {schedulerInvocation=undefined;}
  };
  const rejectScheduler=():void=>{
    if(busy && !closing) {poisoned=true;close();}
  };
  const schedulerGraph=():void=>{
    check();
    if(terminalRead(sources,'scheduler')!==scheduler || scheduler.getRootRuntime()!==root ||
      root.getSpawnRuntime()!==spawns || scheduler.getAllocatorRuntime()!==allocator ||
      scheduler.getMatchGlobals()!==globals || spawns.getMatchGlobals()!==globals ||
      spawns.getAllocatorRuntime()!==allocator)fail('canonical outer scheduler graph changed');
    // Group records/table become retained lazily at the real getGroup. They
    // cannot reuse already reached outer, leader, system, participant or player
    // storage. This identity inventory never loads pause, slot or group cells.
    const helper=spawns.getAdmissionRuntime().getActionRuntime().getSlotStatusRuntime();
    const playerOwners=isSourceActorSlotStatusRuntime(helper)?
      [...helper.getRetainedStorageOwners(),...helper.getDeclaredStorageOwners()]:[];
    const forbidden=[sources,globals,root.getDrawList(),...retained.values(),
      ...massActors.values(),...participantActors.values(),...playerOwners];
    if(allocator.getRetainedGroupStorageOwners().some(owner=>forbidden.includes(owner)))
      fail('scheduler group storage aliases an outer/participant owner');
    check();
  };
  /** Authenticated 53a2c prefix. These are source calls, not scheduler groups. */
  const runOrderedActors=(): void=>{
    const mass=retain('massPreparation',read(sources,'massPreparation'));
    const massOwner=(key:string):object=>{
      if(read(sources,'massPreparation')!==mass)fail('53a2c canonical mass owner changed');
      return retain(`mass ${key}`,read(mass,key));
    };
    const world=spawns.getWorldRuntime(),stage=root.getStageRuntime();
    const worlds=new Map<symbol,object>();
    const physical=():object=>{
      const base=slotPointer(0),block=massOwner('physicalBlock'),ids=retain('mass physical identities',read(block,'identities'));
      if(!Object.isFrozen(block)||read(block,'base')!==base||!Array.isArray(ids)||!Object.isFrozen(ids)||read(ids,'length')!==6)
        fail('53a2c canonical six-actor physical block required');
      return ids;
    };
    const at=(ids:object,index:number):{id:symbol;actor:object}=>{
      const id=read(ids,String(index));if(typeof id!=='symbol')fail('53a2c physical actor identity required');
      return {id,actor:actual(id)};
    };
    const worldOwner=(id:symbol,actor:object):object=>{
      if(spawns.getWorldRuntime()!==world||call(()=>world.getActualActor(id))!==actor)fail('53a2c canonical world actor changed');
      const owner=record(call(()=>world.getActorBinding(id)),'53a2c world binding');
      if(worlds.has(id)&&worlds.get(id)!==owner)fail('53a2c world binding changed');
      if(owner===actor||[...retained.values()].includes(owner)||
        [...worlds].some(([other,value])=>other!==id&&value===owner))fail('53a2c world storage alias');
      worlds.set(id,owner);return owner;
    };
    const life=(id:symbol,actor:object):number=>{
      if(root.getStageRuntime()!==stage||call(()=>stage.getActualActor(id))!==actor)fail('53a2c canonical stage actor changed');
      return byte(record(call(()=>stage.getActorBinding(id)),'53a2c stage binding'),'lifecycle18');
    };
    const partner=(id:symbol,actor:object):unknown=>{
      const matrices=read(mass,'matrices');
      if(!isSourceActorMatrixUpdateRuntime(matrices))fail('53a2c genuine matrix owner required at reached4a4 load');
      if(call(()=>matrices.getActualActor(id))!==actor||call(()=>matrices.getWorldBinding(id))!==call(()=>world.getActorBinding(id)))
        fail('53a2c matrix actor/world differs');
      const value=read(record(call(()=>matrices.getActorBinding(id)),'53a2c matrix binding'),'link4a4');
      if(value!==null&&typeof value!=='symbol')fail('53a2c canonical4a4 pointer identity required');
      return value;
    };
    //5ace8 captures physical base, but reloads team/global per actor. A
    // combination owner is deliberately not requested on an ordinary branch.
    const ids=physical();
    for(let i=0;i<6;i++) {
      const {id,actor}=at(ids,i),index=s8(byte(actor,'team')),row=team(teamTable(match()),index);
      if(s8(byte(row,'byte10'))!==0)continue;
      const header=worldOwner(id,actor),mode=byte(header,'mode4a0');
      if(mode!==0) {
        const lifecycle=life(id,actor);partner(id,actor);
        if(lifecycle!==1)continue;
        fail('8005ace8 reached unsupported combination lifecycle1 branch');
      }
      const charged=read(row,'charged');if(typeof charged!=='boolean')fail('charged: boolean source0/1 owner required');
      if(!charged||s8(byte(actor,'active0'))===0||life(id,actor)!==1)continue;
      const state=s8(byte(header,'mode4a1'));
      if(state===2||state===5||state===7)fail('8005ace8 reached unsupported combination state branch');
    }
    //53a2c captures the table, not the count. A repeated entry is not elided.
    // Capturing a fixed source address does not dereference an unused table.
    // Native metadata snapshots preserve that laziness for a zero count.
    const orderedField=primaryStoreDescriptor(mass,'orderPointers');
    for(let i=0;i<s8(byte(massOwner('orderCount'),'count80436260'));i++) {
      if(!orderedField||!('value' in orderedField))fail('53a2c captured ordered-table owner required');
      const ordered=retain('mass orderPointers',orderedField.value);
      if(read(mass,'orderPointers')!==ordered)fail('53a2c captured ordered-table owner changed');
      if(i>=6)fail('53a2c ordered table exceeds retained six-actor domain');
      const id=read(ordered,String(i));if(id!==null&&typeof id!=='symbol')fail('53a2c ordered actor pointer required');
      const actor=actual(id);
      //54070 begins with mandatory5685c even for a paused actor.
      const supplied=Object.getOwnPropertyDescriptor(sources,'orderedActors');check();
      if(!supplied||!('value' in supplied))fail('80053a58 reached mandatory80054070 transform-history predecessor8005685c');
      const selected=supplied.value;
      if(!isSourceActorOrderedFrameRuntime(selected))fail('53a2c genuine54070 runtime required');
      if(selected.getWorldRuntime()!==world||selected.getStageRuntime()!==stage||
        selected.getStatusRuntime()!==spawns.getPrehookRuntime().getStatusRuntime()||selected.getMatchGlobals()!==globals)
        fail('53a2c canonical ordered actor graph differs');
      orderedInvocation={stage:selected,id:id as symbol,actor,entered:false};
      try {call(()=>invokeSourceActorOrderedFrameFromOuter(runtime,selected,id as symbol));completedOrderedActors.set(id as symbol,actor);}
      finally {orderedInvocation=undefined;}
    }
    //5b140 is still mandatory when the live signed ordered count is zero.
    const following=physical();
    for(let i=0;i<6;i++) {
      const {id,actor}=at(following,i);
      if(s8(byte(actor,'active0'))===0)continue;
      if(byte(worldOwner(id,actor),'mode4a0')!==2)continue;
      const lifecycle=s8(life(id,actor));partner(id,actor);
      if(lifecycle===1||lifecycle===2)fail('8005b140 reached unsupported partner-copy branch');
      if(lifecycle===3 && (half(actor,'borgNumber')>>>8)===5)
        fail('8005b140 reached unsupported lifecycle3 partner translations');
    }
    const status=spawns.getPrehookRuntime().getStatusRuntime();
    const storeByte=(owner:object,key:string,value:number,verify:()=>void):void=>{
      verify();own(owner,key,true);check();verify();
      const field=primaryStoreDescriptor(owner,key);
      if(!field||!('value' in field)||!field.writable)fail(`${key}: live writable own data property required`);
      unsigned(field.value,255,key);
      (owner as Record<string,unknown>)[key]=value;check();
    };
    const statusOwner=(id:symbol,actor:object):object=>{
      if(call(()=>status.getActualActor(id))!==actor)fail('53a2c status actual differs');
      return record(call(()=>status.getActorBinding(id)),'53a2c status binding');
    };
    const fieldGuard=(id:symbol,actor:object,key:'byte6fc'|'burstArmFrames',owner:object):void=>{
      if(call(()=>status.getActualActor(id))!==actor||
        (key==='byte6fc'?call(()=>status.getActorBinding(id)):call(()=>status.getActualBorg(id)))!==owner)
        fail('53a2c canonical timer owner changed');
      const records=[actor,record(call(()=>status.getWorldBinding(id)),'53a2c world'),
        record(call(()=>status.getMappingActor(id)),'53a2c mapping'),
        record(call(()=>status.getMovementBinding(id)),'53a2c movement'),
        record(call(()=>status.getAttributeBinding(id)),'53a2c attributes'),
        record(call(()=>status.getActorBinding(id)),'53a2c timers'),
        record(call(()=>status.getActualBorg(id)),'53a2c Borg')];
      const aliases=key==='byte6fc'?['byte6FC','field6fc','field6FC','1788']:
        ['byte6fb','byte6FB','field6fb','field6FB','1787'];
      for(const value of records)noShadows(value,value===owner?aliases:[key,...aliases]);
      // An observable final metadata read cannot install a competing cell on
      // an earlier inspected owner before the corresponding source store.
      for(const value of records)for(const alias of value===owner?aliases:[key,...aliases])
        if(primaryStoreDescriptor(value,alias)!==undefined)fail(`${alias}: competing source cell owner`);
    };
    //5b2b8 first pass has NO active guard. A later unsupported8c4 load
    // cannot erase the preceding source6fc clear.
    const clearing=physical();
    for(let i=0;i<6;i++) {
      const {id,actor}=at(clearing,i),index=s8(byte(actor,'team')),row=team(teamTable(match()),index);
      if(s8(byte(row,'byte10'))!==0)continue;
      const owner=statusOwner(id,actor);fieldGuard(id,actor,'byte6fc',owner);
      const raw=byte(owner,'byte6fc');fieldGuard(id,actor,'byte6fc',owner);
      if(s8(raw)===0)continue;
      storeByte(owner,'byte6fc',0,()=>fieldGuard(id,actor,'byte6fc',owner));
      fail('8005b2b8 reached unsupported canonical actor8c4 load after6fc clear');
    }
    //One captured team-row base; both the initial gate and each loop test
    //reload signed counts. Rejected candidates need no later actor fields.
    const rows=teamTable(match());
    for(let index=0;index<4;index++) {
      if(s8(byte(massOwner('teamCounts'),String(index)))<=0)continue;
      const row=team(rows,index);
      if(s8(byte(row,'byte10'))!==0)continue;
      const charged=read(row,'charged');if(typeof charged!=='boolean')fail('charged: boolean source0/1 owner required');
      if(!charged)continue;
      let accepted=0;
      for(let candidate=0;candidate<s8(byte(massOwner('teamCounts'),String(index)));candidate++) {
        const id=read(massOwner('teamPointers'),String(index*6+candidate));
        if(typeof id!=='symbol')fail('5b2b8 candidate requires canonical actor pointer');
        const actor=actual(id);
        if(call(()=>status.getActualActor(id))!==actor)fail('5b2b8 candidate status actor differs');
        const borg=record(call(()=>status.getActualBorg(id)),'5b2b8 candidate Borg6fb');
        fieldGuard(id,actor,'burstArmFrames',borg);
        const arm=byte(borg,'burstArmFrames');fieldGuard(id,actor,'burstArmFrames',borg);
        if(s8(arm)===0)continue;
        if(s8(byte(actor,'active0'))===0)continue;
        if(life(id,actor)!==1)continue;
        if(s8(byte(worldOwner(id,actor),'mode4a0'))!==0)continue;
        if(s8(byte(worldOwner(id,actor),'mode4a1'))!==0)continue;
        if(byte(match(),'byteEB')!==0) {
          const current=match(),visibility=byte(actor,'visibilityBit'),mask=byte(current,'byteEB');
          if((s8(visibility)&mask)===0)continue;
        }
        // Count each accepted source pointer, including repetitions. The
        // scratch entries are not consumed before the unsupported callee.
        accepted++;
      }
      const selector=s8(byte(team(teamTable(match()),index),'byte1'));
      if(accepted>=(selector===1?1:2))fail('8005b2b8 reached mandatory8005b678 combination');
    }
    const countdown=physical();
    for(let i=0;i<6;i++) {
      const {id,actor}=at(countdown,i);
      if(call(()=>status.getActualActor(id))!==actor)fail('53a2c countdown actual differs');
      const owner=record(call(()=>status.getActualBorg(id)),'53a2c canonical Borg6fb');
      fieldGuard(id,actor,'burstArmFrames',owner);
      const raw=byte(owner,'burstArmFrames');fieldGuard(id,actor,'burstArmFrames',owner);
      if(s8(raw)!==0)storeByte(owner,'burstArmFrames',(raw-1)&255,()=>fieldGuard(id,actor,'burstArmFrames',owner));
    }
  };
  const runStageDispatch=():void=>{
    const stage=call(()=>root.getStageRuntime());
    const owner=retain('stage8043625c',call(()=>stage.getTerrainGlobals()));
    const guard=(key:'byte0'|'byte8'):void=>{
      if(call(()=>root.getStageRuntime())!==stage||call(()=>stage.getTerrainGlobals())!==owner)fail('87cf0 canonical stage owner changed');
      retain('stage8043625c',owner);
      const aliases=key==='byte0'?['field0','0','stageByte0','stageState0']:['field8','8','stageByte8'];
      noShadows(owner,aliases);
      for(const alias of aliases)if(primaryStoreDescriptor(owner,alias)!==undefined)fail(`${alias}: competing stage source cell`);
    };
    guard('byte0');
    // Missing explicitly supplied state is still the former honest boundary.
    const cell=Object.getOwnPropertyDescriptor(owner,'byte0');check();
    if(!cell||!('value'in cell))fail('8002948c reached mandatory80087cf0 byte0: own data property required');
    const selector=s8(unsigned(cell.value,255,'87cf0 byte0'));guard('byte0');
    if(selector===1)return; //8043391c→80087f20, authenticated BLR
    if(selector!==0)fail('87cf0 reached unselected signed stage dispatch');
    const write=(key:'byte0'|'byte8',value:number):void=>{
      guard(key);own(owner,key,true);check();guard(key);
      const p=primaryStoreDescriptor(owner,key);if(!p||!('value'in p)||!p.writable)fail(`${key}: live writable stage cell required`);
      (owner as Record<string,unknown>)[key]=value;check();
    };
    //87d2c reloads owner, increments its actual state, reloads owner again,
    //then writes8 before scene setup. This is not successful initialization.
    guard('byte0');const previous=byte(owner,'byte0');guard('byte0');write('byte0',(previous+1)&255);
    write('byte8',1);
    fail('87d2c reached unsupported scene setup after source byte0/byte8 stores');
  };
  const drawCheck=(node:symbol):void=>{
    const active=drawInvocation;
    if(!busy||closing||incomplete||poisoned||!active||active.callsite!==drawCallsite||active.node!==node||!active.entered){rejectScheduler();fail('private exact active outer draw invocation required');}
    if(checkingDraw)return;
    checkingDraw=true;
    try{
      schedulerGraph();
      if(root.getVectorProcessorProfile()!==active.context.processor)fail('draw processor owner changed');
      check();
      const exact=(o:object,k:string,v:unknown):void=>{const d=primaryStoreDescriptor(o,k);if(!d||!('value'in d)||d.value!==v)fail('draw context owner changed: '+k);};
      drawStorageCheck(active.updates);exact(active.updates,'draw',active.draw);
      for(const key of ['roots36290','roots36280','roots36270','roots6f54']){const d=primaryStoreDescriptor(active.updates,key);if(d&&'value'in d&&d.value!==undefined&&[active.draw,active.context.constants,active.context.scratch,active.context.processor].includes(d.value))fail('draw helper aliases root table');}
      const cd=primaryStoreDescriptor(active.draw,'constants');if((cd&&!('value'in cd))||cd?.value!==active.context.constants)fail('draw constants owner changed');
      const sd=primaryStoreDescriptor(active.draw,'scratch');
      if((sd && !('value'in sd))||sd?.value!==active.context.scratch)fail('draw scratch owner changed');
      if(active.context.scratch instanceof Float32Array && active.context.scratch.buffer!==active.buffer)fail('draw scratch backing changed');
      check();
    }finally{checkingDraw=false;}
  };
  // Reached root tables retain their identities across all three source calls.
  // Native checks follow metadata observers; scalar heads are never reread.
  const drawStorageCheck=(updates:object):void=>{
    const exact=(o:object,k:string,v:unknown):void=>{const d=primaryStoreDescriptor(o,k);if(!d||!('value'in d)||d.value!==v)fail('draw source owner changed: '+k);};
    exact(sources,'objectUpdates',updates);
    for(const name of ['roots36290','roots36280','roots36270','roots6f54']){
      const rows=retained.get('objectUpdates.'+name);if(!rows)continue;
      exact(updates,name,rows);
      for(const alias of [name.slice(5),'0x804'+name.slice(5),'804'+name.slice(5)])if(primaryStoreDescriptor(updates,alias))fail('competing draw root owner');
    }
  };
  const runObjectUpdates=(callsite:0x800294c8|0x800294fc|0x80029500):void=>{
    if(drawCallsite!==undefined)fail('nested outer draw traversal');
    drawCallsite=callsite;
    try{
    const supplied=Object.getOwnPropertyDescriptor(sources,'objectUpdates');check();
    if(!supplied||!('value'in supplied)||supplied.value===undefined)fail(callsite===0x800294c8?'800294c8 reached mandatory80089554':callsite.toString(16)+' reached mandatory draw traversal');
    const updates=retain('objectUpdates',supplied.value);drawStorageCheck(updates);
    const checked=<T>(f:()=>T):T=>{const value=call(f);drawStorageCheck(updates);return value;};
    const link=(v:unknown):symbol|null=>{if(v!==null&&typeof v!=='symbol')fail('89554 explicit object pointer required');return v;};
    const walk=(first:symbol|null):void=>{
      let node=first;const visited=new Set<symbol>();
      while(node!==null){
        if(visited.has(node))fail('89554 cyclic source list unsupported');visited.add(node);
        const callback=checked(()=>allocator.readU32(node!,0x100));
        if(callback!==0){
          if(callback!==0x80047aa4)fail('89554 reached unsupported callback100 '+callback.toString(16));
          const draw=record(read(updates,'draw'),'draw context');
          const cd=Object.getOwnPropertyDescriptor(draw,'constants');check();
          if(cd&&!('value'in cd))fail('draw constants own data required');
          const constants=cd?.value as object|undefined;
          const sd=Object.getOwnPropertyDescriptor(draw,'scratch');check();
          if(sd&&!('value'in sd))fail('draw scratch own data required');
          const scratch=sd?.value as Float32Array|undefined;
          const processor=call(()=>root.getVectorProcessorProfile());
          const tableOwners=['roots36290','roots36280','roots36270','roots6f54'].map(k=>primaryStoreDescriptor(updates,k)).filter(d=>d&&'value'in d).map(d=>d!.value);
          const owners=[sources,globals,updates,...tableOwners,root.getDrawList(),...retained.values(),...call(()=>root.getRetainedStorageOwners()),...call(()=>allocator.getRetainedStorageOwners())];
          if(draw===constants||draw===processor||(constants!==undefined&&constants===processor)||owners.includes(draw)||(constants!==undefined&&owners.includes(constants))||
             (scratch!==undefined&&(owners.includes(scratch)||scratch===processor||(ArrayBuffer.isView(scratch)&&owners.some(o=>ArrayBuffer.isView(o)&&o.buffer===scratch.buffer)))))fail('draw helper storage aliases retained owner');
          for(const [key,value]of [['draw',draw],['constants',constants],['scratch',scratch]]as const){if(drawOwners.has(key)&&drawOwners.get(key)!==value)fail('draw retained owner changed: '+key);drawOwners.set(key,value);}
          for(const o of [draw,constants,scratch,...(scratch instanceof Float32Array?[scratch.buffer]:[])])if(o!==null&&typeof o==='object'&&!claimSourceHelperStorage(o,runtime))fail('draw helper storage already claimed');
          drawInvocation={callsite,node,entered:false,updates,draw,buffer:scratch instanceof Float32Array?scratch.buffer:undefined,context:Object.freeze({allocator,root,processor,constants,scratch})};
          try{call(()=>executeSourceDrawCallback47aa4(runtime,node!));}finally{drawInvocation=undefined;}
        }
        node=link(checked(()=>allocator.readPointer(node!,0x108)));
      }
    };
    // Each later root family is loaded only after the preceding callbacks return.
    if(callsite===0x800294c8)walk(link(read(call(()=>root.getDrawList()),'tail')));
    const family=(name:string,count:number,start=0):void=>{
      if(name==='roots36270'&&!primaryStoreDescriptor(updates,name))fail('80029500 reached required80089658: explicit roots36270 required');
      const rows=retain('objectUpdates.'+name,read(updates,name));drawStorageCheck(updates);
      if(name==='roots36290')noShadows(rows,['0']);
      for(let i=start;i<count;i++)walk(link(checked(()=>read(rows,String(i)))));
    };
    if(callsite===0x800294c8){family('roots36290',2,1);family('roots36280',2);family('roots6f54',6);}
    else if(callsite===0x800294fc)family('roots36280',2);
    else family('roots36270',2);
    }finally{drawCallsite=undefined;}
  };
  /** Bounded2bb14 caller and2cf80 prefix on canonical owners. Authenticated
   * -10000 permits the remaining indexed stores. No collision helper is
   * fabricated: distinct owner pairs stop after source-ordered scratch copies. */
  const runTargetActionPrefix=():never=>{
    const supplied=Object.getOwnPropertyDescriptor(sources,'targetAction');check();
    if(!supplied)fail('800294f4 reached required8002bb14; target/action frame helper unsupported');
    const input=retain('targetAction',read(sources,'targetAction'));
    const cells=retain('targetAction cells',read(input,'cells'));
    const edges:{o:object;k:string;value:unknown}[]=[{o:sources,k:'targetAction',value:input},{o:input,k:'cells',value:cells}];
    const resetSources:SourceContactResetSources={scheduler};
    const actors=new Map<symbol,object>(),ownerChecks:(()=>void)[]=[];
    const guard=():void=>{
      schedulerGraph();check();
      for(const e of edges){const d=primaryStoreDescriptor(e.o,e.k);if(!d||!('value'in d)||d.value!==e.value)fail('2bb14 retained owner changed');}
      for(const [id,a]of actors)if(allocator.getPointerTarget(id)!==a)fail('2bb14 actual owner changed');
      for(const validate of ownerChecks)validate();
      check();
    };
    const edge=(o:object,k:string,value:unknown):void=>{const old=edges.find(e=>e.o===o&&e.k===k);if(old&&old.value!==value)fail('2bb14 retained owner changed');if(!old)edges.push({o,k,value});guard();};
    const get=(o:object,k:string):unknown=>{const v=read(o,k);guard();return v;};
    const aliases=(o:object,k:string,address:number,width:number,terminal=false):void=>{
      const names=new Set<string>();
      for(const [prefix,size]of [['byte',1],['half',2],['short',2],['word',4],['float',4],['field',4]]as const)
        for(let start=address-size+1;start<address+width;start++){if(start<0)continue;const h=start.toString(16);names.add(prefix+h);names.add(prefix+h.toUpperCase());}
      for(let i=0;i<width;i++)names.add(String(address+i));
      for(const n of names)if(n!==k){const p=terminal?primaryStoreDescriptor(o,n):Object.getOwnPropertyDescriptor(o,n);if(!terminal)guard();if(p)fail(k+': competing2bb14 cell');}
    };
    const load=(o:object,k:string,address:number,width:number):number=>{aliases(o,k,address,width);const v=unsigned(get(o,k),width===1?255:width===2?65535:0xffffffff,k);aliases(o,k,address,width,true);return v;};
    const put=(o:object,k:string,address:number,width:number,v:number,extra=()=>{},terminal=()=>{}):void=>{
      aliases(o,k,address,width);extra();const d=Object.getOwnPropertyDescriptor(o,k);guard();if(!d||!('value'in d)||!d.writable)fail(k+': writable2bb14 destination required');
      extra();guard();const last=primaryStoreDescriptor(o,k);if(!last||!('value'in last)||!last.writable)fail(k+':2bb14 destination changed');aliases(o,k,address,width,true);terminal();
      (o as Record<string,number>)[k]=v;guard();
    };
    const globalStore=(address:number,width:1|2|4,v:number):void=>put(cells,(width===1?'byte':width===2?'half':'word')+address.toString(16),address,width,v);
    const globalFloatStore=(address:number,v:number,terminal=()=>{}):void=>put(cells,'float'+address.toString(16),address,4,v,()=>{},terminal);
    const owner=match(),rows=teamTable(owner);edge(owner,'teamRows103',rows);
    const matchWord=(i:number):number=>{
      const row=team(rows,i);edge(rows,String(i),row);const address=0x118+0x3c*i;
      aliases(owner,'__no_flat_match_word',address,4);const v=load(row,'word24',0x24,4);aliases(owner,'__no_flat_match_word',address,4,true);return v;
    };
    globalStore(0x803b068c,4,matchWord(0));
    const base=slotPointer(0); // Captured once at8002bb64, not each actor.
    const mass=retain('massPreparation',read(sources,'massPreparation'));edge(sources,'massPreparation',mass);
    const block=retain('mass physicalBlock',read(mass,'physicalBlock'));edge(mass,'physicalBlock',block);
    const ids=retain('mass physical identities',read(block,'identities'));edge(block,'identities',ids);
    if(!Object.isFrozen(block)||get(block,'base')!==base||!Array.isArray(ids)||!Object.isFrozen(ids)||get(ids,'length')!==6)fail('2bb14 six frozen physical identities required');
    const identities=ids as readonly unknown[];
    if(identities.some(id=>typeof id!=='symbol')||new Set(identities).size!==6||identities[0]!==base)fail('2bb14 distinct physical base identities required');
    globalStore(0x80436154,2,0);
    for(let i=1;i<4;i++){globalStore(0x803b068c+i*4,4,matchWord(i));globalStore(0x80436154+i*2,2,0);}
    globalStore(0x80436128,1,0);
    const constants=():object=>{const c=retain('targetAction constants',get(input,'constants'));edge(input,'constants',c);resetSources.constants=c;return c;};
    const zero=():number=>{const c=constants(),v=get(c,'float80436f68');if(!Object.is(v,0))fail('authenticated float80436f68 +0 required');return 0;};
    const reset=(kind:TargetResetKind,value:symbol|number):void=>{
      // Bind only the reached real callee's owners. No public helper or caller
      // supplied success callback grants this exact source-position scope.
      if(kind==='player'){const p=spawns.getAdmissionRuntime().getActionRuntime().getSlotStatusRuntime();guard();if(!isSourceActorSlotStatusRuntime(p))fail('2bb14 canonical players required');resetSources.players=p;}
      targetResetInvocation={kind,value,entered:false,sources:resetSources,guard,constants};
      try{invokeSourceContactResetOuter(runtime,kind,value);}finally{targetResetInvocation=undefined;}
      guard();
    };
    const initialContact=():void=>{
      const counters=retain('contactCounters',get(sources,'contactCounters'));edge(sources,'contactCounters',counters);
      const count=(address:number):number=>{
        const key='half'+address.toString(16);
        for(const o of new Set([sources,globals,...retained.values(),...scheduler.getRetainedStorageOwners()]))
          if(o!==counters)aliases(o,'__no_count',address,2,true);
        const value=load(counters,key,address,2);
        const terminalOwners=new Set([sources,globals,...retained.values(),...scheduler.getRetainedStorageOwners()]);guard();
        for(const o of terminalOwners)if(o!==counters)aliases(o,'__no_count',address,2,true);
        aliases(counters,key,address,2,true);return value;
      };
      const byteOwners=new Map<symbol,object>();
      ownerChecks.push(()=>{for(const [id,o]of byteOwners)if(allocator.getObject(id)!==o)fail('2cf80 byte owner changed');});
      const bytes=(id:symbol|null):object=>{
        if(id===null)fail('2cf80 null pointer at reached dereference');
        let o:object;try{o=allocator.getObject(id);}catch{check();fail('2cf80 requires registered object-byte owner; external actor owner unsupported');}
        guard();if(edges.some(e=>e.value===o)||o===cells)fail('2cf80 byte/global storage alias');
        const old=byteOwners.get(id);if(old&&old!==o)fail('2cf80 byte owner changed');byteOwners.set(id,o);return o;
      };
      const byteAliases=(o:object,offset:number,width:number,_terminal=false):void=>{
        // Nonproxy own-byte admission: native metadata inspection cannot invoke
        // host observers. Actual source reads remain observable and guarded.
        for(let i=0;i<width;i++)aliases(o,String(offset+i),offset+i,1,true);
      };
      const raw=(id:symbol|null,offset:number,width:1|4):number=>{
        const o=bytes(id);byteAliases(o,offset,width);
        const value=width===1?allocator.readU8(id!,offset):allocator.readU32(id!,offset);guard();byteAliases(o,offset,width,true);return value;
      };
      const pointer20=(id:symbol|null):symbol|null=>{
        const o=bytes(id);byteAliases(o,0x20,4);const value=allocator.readPointer(id!,0x20);guard();byteAliases(o,0x20,4,true);return value;
      };
      const contact=(name:'contactPointers46'|'contactPointers44',index:number):symbol|null=>{
        const table=retain('targetAction '+name,get(input,name));edge(input,name,table);
        const id=get(table,String(index));if(id!==null&&typeof id!=='symbol')fail('2cf80 explicit contact pointer required');return id;
      };
      const asFloat=(bits:number):number=>{const d=new DataView(new ArrayBuffer(4));d.setUint32(0,bits,false);const v=d.getFloat32(0,false);if(!Number.isFinite(v))fail('2cf80 finite source float required');return v;};
      let processor:object|undefined,processorDeclaration:object|undefined;
      const terminalScalar=():void=>{
        if(!processor||!processorDeclaration)fail('2cf80 scalar context required');
        const p=primaryStoreDescriptor(processorDeclaration,'processor');if(!p||!('value'in p)||p.value!==processor)fail('2cf80 processor changed');
        const d=primaryStoreDescriptor(processor,'fpscrControl');
        if(!d||!('value'in d)||typeof d.value!=='number'||!Number.isInteger(d.value)||d.value<0||d.value>0xffffffff||(d.value&255)!==0)fail('2cf80 FPSCR RN00/NI0 and disabled exceptions required');
      };
      const subtract=(a:number,b:number):number=>{
        const current=root.getVectorProcessorProfile();guard();if(!current)fail('2cf80 explicit scalar processor required');
        if(processor&&processor!==current)fail('2cf80 processor changed');processor=current;
        const declarations=root.getRetainedStorageOwners().filter(o=>{const d=primaryStoreDescriptor(o,'processor');return d&&'value'in d&&d.value===processor;});guard();
        if(declarations.length!==1)fail('2cf80 canonical scalar declaration required');
        if(processorDeclaration&&processorDeclaration!==declarations[0])fail('2cf80 scalar declaration changed');processorDeclaration=declarations[0];
        get(processor,'fpscrControl');guard();terminalScalar();return addSourceFloat32(a,-b);
      };
      const copyWord=(address:number,value:number):void=>{
        const key='word'+address.toString(16);aliases(cells,key,address,4,true);
        const d=Object.getOwnPropertyDescriptor(cells,key);guard();if(!d||!('value'in d)||!d.writable)fail(key+': writable2bb14 destination required');
        const last=primaryStoreDescriptor(cells,key);if(!last||!('value'in last)||!last.writable)fail(key+':2bb14 destination changed');
        aliases(cells,key,address,4,true);(cells as Record<string,number>)[key]=value;guard();
      };
      let visits=0;
      for(let outer=0;outer<count(0x80436246);outer++){
        const hit=contact('contactPointers46',outer),owner=pointer20(hit);
        if((raw(owner,0x83,1)<<24>>24)===0){
          const high=asFloat(raw(hit,0x68,4)),low=asFloat(raw(hit,0x88,4));
          const slot=raw(owner,0x3e4,1);const height=subtract(high,low);
          globalFloatStore(0x803b0708+(slot<<24>>24)*4,height,terminalScalar);
        }
        for(let inner=0;inner<count(0x80436244);inner++){
          if(++visits>65536)fail('2cf80 finite comparison budget exceeded');
          const other=contact('contactPointers44',inner),freshOwner=pointer20(hit),otherOwner=pointer20(other);
          if(freshOwner===otherOwner||owner===otherOwner)continue;
          for(const [source,destination]of [[hit,0x803b04d0],[other,0x803b0368]]as const)
            for(let pair=0;pair<45;pair++){
              const first=raw(source,0x58+8*pair,4),second=raw(source,0x5c+8*pair,4);
              copyWord(destination+8*pair,first);copyWord(destination+8*pair+4,second);
            }
          fail('8002d080 reached required8003a05c after both source contact copies; collision helper unsupported');
        }
      }
      guard();
    };
    for(let i=0;i<6;i++){
      const id=identities[i] as symbol,a=actual(id);guard();if([...actors.values()].includes(a))fail('2bb14 physical actor storage overlap');actors.set(id,a);
      if((load(a,'active0',0,1)<<24>>24)===0)continue;
      const timer=load(a,'byte7d1',0x7d1,1)<<24>>24;
      if(timer>0)put(a,'byte7d1',0x7d1,1,timer-1);else{put(a,'byte7d1',0x7d1,1,0);put(a,'byte7d0',0x7d0,1,255);}
      const slot=load(a,'slot',0x3e4,1)<<24>>24;globalStore(0x8043614c+slot,1,0);
      const normal=get(input,'normal');if(!isSourceActorNormalLifecycleRuntime(normal))fail('2bb14 genuine normal lifecycle required');edge(input,'normal',normal);
      const status=spawns.getPrehookRuntime().getStatusRuntime(),world=spawns.getWorldRuntime();
      const statusOwner=normal.getStatusBinding(id),borg=status.getActualBorg(id);
      const verifyActor=():void=>{
        if(normal.getActualActor(id)!==a||status.getActualActor(id)!==a||normal.getStatusBinding(id)!==statusOwner||status.getActorBinding(id)!==statusOwner||status.getActualBorg(id)!==borg||normal.getWorldBinding(id)!==world.getActorBinding(id)||normal.getMappingActor(id)!==world.getMappingActor(id))fail('2bb14 canonical lifecycle owners differ');
        normal.assertActorComplete(id);check();
      };
      ownerChecks.push(verifyActor);const actorGuard=guard;
      actorGuard();resetSources.normal=normal;reset('actor',id);
      globalStore(0x803b069c+i*2,2,load(a,'half1c6',0x1c6,2));
      if(load(a,'byte436',0x436,1)!==0)globalStore(0x80436128,1,1);
      for(const [current,maximum,countdown]of [[0x4f4,0x4fc,0x4f8],[0x4f6,0x4fe,0x4fa]]as const){
        const value=load(a,'half'+current.toString(16),current,2),old=load(a,'half'+maximum.toString(16),maximum,2);
        if(value>=old)put(a,'half'+maximum.toString(16),maximum,2,value);
        const n=load(a,'half'+countdown.toString(16),countdown,2);
        if((n<<16>>16)!==0)put(a,'half'+countdown.toString(16),countdown,2,(n-1)&65535);else put(a,'half'+current.toString(16),current,2,0);
      }
      const split=(o:object,k:string,offset:number):void=>{
        const cross=():void=>{actorGuard();for(const other of [a,statusOwner,borg])if(other!==o){aliases(other,'__no_split_'+k,offset,1,true);if(primaryStoreDescriptor(other,k))fail(k+': competing2bb14 split owner');}};
        put(o,k,offset,1,0,cross);
      };
      split(statusOwner,'byte6fd',0x6fd);split(borg,'slowAuraLevel',0x70c);split(borg,'hasteAuraLevel',0x70d);
      const first=zero();split(statusOwner,'byte7d4',0x7d4);
      const c=constants(),d=Object.getOwnPropertyDescriptor(c,'float80436f6c');guard();
      if(!d||!('value'in d))fail('8002bcb0 requires explicit authenticated float80436f6c');
      const second=get(c,'float80436f6c');if(!Object.is(second,-10000))fail('float80436f6c authenticated -10000 required');
      put(a,'byte599',0x599,1,0);
      const index=():number=>load(a,'slot',0x3e4,1)<<24>>24;
      globalStore(0x80436144+index(),1,0);
      globalStore(0x803b06a8+index()*4,4,0);
      globalStore(0x8043613c+index(),1,0);
      globalStore(0x80436134+index(),1,0);
      globalFloatStore(0x803b0644+index()*4,first);
      globalStore(0x8043612c+index(),1,0);
      globalStore(0x803b0638+index()*2,2,0);
      globalFloatStore(0x803b0708+index()*4,second as number);
    }
    for(const group of [40,32,0,16,8,24])reset('group',group);
    for(let i=0;i<12;i++)reset('player',i);
    initialContact();
    fail('8002bd9c reached required8002d35c; next target/action contact pass unsupported');
  };
  const resetContactCounts=():void=>{
    const supplied=Object.getOwnPropertyDescriptor(sources,'contactCounters');check();
    if(!supplied||!('value'in supplied)||supplied.value===undefined)
      fail('800294ec reached required8008a28c: explicit contactCounters required');
    const owner=retain('contactCounters',supplied.value);
    if(!claimSourceHelperStorage(owner,runtime))fail('contact counter storage already claimed');
    // Complete48-byte8a28c: ten descending halfword stores of literal zero.
    // Previous counter values and pointed-to contact lists are never loaded.
    for(const suffix of ['50','4e','4c','4a','48','46','44','42','40','3e']){
      const address='804362'+suffix,key='half'+address;
      const start=Number.parseInt(address,16),aliases:string[]=[];
      // Both bytes, misaligned halfwords, and wider overlapping cells can
      // shadow this store. Adjacent nonoverlapping canonical halves may coexist.
      for(const [prefix,width]of [['byte',1],['half',2],['word',4],['field',4]]as const)
        for(let offset=1-width;offset<2;offset++){
          const hex=(start+offset).toString(16);aliases.push(prefix+hex,prefix+hex.toUpperCase());
        }
      for(let offset=-3;offset<2;offset++){
        const n=start+offset,hex=n.toString(16);aliases.push(hex,hex.toUpperCase(),'0x'+hex,'0x'+hex.toUpperCase(),String(n));
      }
      // Already-consumed candidate half42 must not silently gain a second
      // representation. Sharing its writer needs a future explicit private join.
      const candidateOwners=():readonly object[]=>{
        const dispatch=getSourceActorTargetDispatchForScheduler(scheduler);
        return dispatch?call(()=>dispatch.getRetainedStorageOwners()):[];
      };
      const records=[sources,globals,...retained.values(),...call(()=>scheduler.getRetainedStorageOwners()),...candidateOwners()];
      for(const record of new Set(records))noShadows(record,[...new Set(aliases)].filter(k=>record!==owner||k!==key));
      const destination=Object.getOwnPropertyDescriptor(owner,key);check();
      if(!destination||!('value'in destination)||!destination.writable)fail(key+': writable own counter destination required');
      schedulerGraph();check();
      // Terminal native checks follow the last observable descriptor hook.
      const terminalRecords=[...new Set([...records,...call(()=>scheduler.getRetainedStorageOwners()),...candidateOwners()])];
      const link=primaryStoreDescriptor(sources,'contactCounters');
      if(!link||!('value'in link)||link.value!==owner)fail('contact counter owner changed');
      const live=primaryStoreDescriptor(owner,key);
      if(!live||!('value'in live)||!live.writable)fail(key+': counter destination changed');
      for(const record of terminalRecords)
        for(const alias of new Set(aliases))if((record!==owner||alias!==key)&&primaryStoreDescriptor(record,alias))fail(alias+': competing counter cell owner');
      check();(owner as Record<string,number>)[key]=0;check();
    }
  };
  const runContactCallbacks=():void=>{
    // Actual89aec, not89a94: group48, six live active actor gates49..54,
    // then55. No pause-mask/snapshot/cleanup suffix belongs to this traversal.
    const groups=new Map<number,object>();let slots:object|undefined,visits=0;
    const guard=():void=>{
      schedulerGraph();check();
      for(const [index,owner]of groups)if(call(()=>allocator.getGroup(index))!==owner)fail('89aec group owner changed');
      if(slots&&call(()=>scheduler.getActorSlotTable())!==slots)fail('89aec actor-slot owner changed');
      check();
    };
    const checked=<T>(f:()=>T):T=>{const value=call(f);guard();return value;};
    const pointer=(value:unknown):symbol|null=>{if(value!==null&&typeof value!=='symbol')fail('89aec explicit source pointer required');return value;};
    const contactPrefix=(hit:symbol):void=>{
      const bytes=checked(()=>allocator.getObject(hit));
      const owner=pointer(checked(()=>allocator.readPointer(hit,0x20)));
      if(owner===null)fail('8008a680 null contact owner at1d8 load');
      // Existing projectile HITs point to real object bytes. External actor
      // records need a separate canonical field-owner join, never byte shadows.
      try{allocator.getObject(owner);}catch{fail('8008a680 requires registered object-byte contact owner; external actor owner unsupported');}
      guard();
      const load8=(id:symbol,offset:number):number=>checked(()=>allocator.readU8(id,offset));
      const load16=(id:symbol,offset:number):number=>checked(()=>allocator.readS16(id,offset));
      const load32=(offset:number):number=>checked(()=>allocator.readU32(hit,offset));
      const store=(offset:number,value:number,width:1|2|4):void=>{
        for(let i=0;i<width;i++){
          const d=Object.getOwnPropertyDescriptor(bytes,String(offset+i));guard();
          if(!d||!('value'in d)||!d.writable)fail('8a65c writable scalar bytes required');
        }
        guard();if(allocator.getObject(hit)!==bytes)fail('8a65c hit byte owner changed');
        for(let i=0;i<width;i++){
          const d=primaryStoreDescriptor(bytes,String(offset+i));
          if(!d||!('value'in d)||!d.writable)fail('8a65c scalar destination changed');
        }
        check();for(let i=0;i<width;i++)bytes[offset+i]=(value>>>(8*(width-1-i)))&255;check();
      };
      if(s8(load8(owner,0x1d8))!==0)fail('8008a69c reached required80088e50 contact release');
      if(s8(load8(owner,0))===0)fail('8008a69c reached required80088e50 contact release');
      if(s8(load8(owner,0x83))===0&&load16(hit,0x4a)!==-1){
        const group=s8(load8(owner,0x1cec)),action=s8(load8(owner,0x1ced)),saved=load16(hit,0x4c);
        if(saved!==group*0x1000+action)fail('8008a6e0 reached required80088e50 contact release');
      }
      store(0x13,0,1);
      const state=load8(hit,0x10);
      const descriptor=pointer(checked(()=>allocator.readPointer(hit,0x28))); // Captured even on the>=3 return.
      if(state>=3)return;
      if(state===2){
        if(s8(load8(owner,0x281))===0)store(0x10,1,1);
        fail('8008aa0c reached required8008aa40 contact matrix validity');
      }
      if(state===1){
        const x=load32(0x30),y=load32(0x34);store(0x3c,x,4);store(0x40,y,4);
        const z=load32(0x38);store(0x44,z,4);
      }
      const matrix=pointer(checked(()=>allocator.readPointer(hit,0x60)));
      contactTransformInvocation={node:hit,site:state===0?0x8008a728:0x8008a888,entered:false,checking:false,context:Object.freeze({allocator,root,matrix,input:descriptor,output:hit}),guard};
      try{checked(()=>executeSourceContactTransform(runtime,hit));}finally{contactTransformInvocation=undefined;}
      if(state===0){
        const x=load32(0x30),y=load32(0x34);store(0x3c,x,4);store(0x40,y,4);
        const z=load32(0x38);store(0x44,z,4);
        const timer=load16(hit,0x48);
        if(timer<=0)fail('8008a788 reached contact initialization dispatch');
        if(s8(load8(owner,0x83))===0)fail('8008a75c reached owner1cdc conversion');
        store(0x48,timer-1,2);return; // Actual positive countdown branch returns.
      }
      fail('8008a88c reached contact timer continuation');
    };
    const walk=(index:number,site:0x80089b30|0x80089b84|0x80089bd0):void=>{
      let owner:object;
      try{owner=call(()=>allocator.getGroup(index));}catch(error){fail('800294f0 reached required80089aec group'+index+': '+String(error));}
      groups.set(index,owner);guard();
      let node=pointer(checked(()=>read(owner,'head')));const seen=new Set<symbol>();
      while(node!==null){
        if(++visits>4096||seen.has(node))fail('89aec cyclic/over-budget source list unsupported');seen.add(node);
        const current=node;
        if(checked(()=>allocator.readS8(current,0))!==0){
          const callback=checked(()=>allocator.readU32(current,0xc));
          // Active bctrl is unconditional. Even callback0 is not a no-op.
          // This is not the ordinary7dcec scheduler or its snapshot suffix.
          if(callback!==0x8008a65c)fail(site.toString(16)+' reached required contact callback0c '+callback.toString(16)+'; callee unsupported');
          contactPrefix(current);guard();
        }
        node=pointer(checked(()=>allocator.readPointer(current,8)));
      }
    };
    walk(48,0x80089b30);
    slots=call(()=>scheduler.getActorSlotTable());guard();
    for(let index=0;index<6;index++){
      const id=pointer(checked(()=>read(slots!,String(index))));
      if(id===null)fail('89aec null actor slot at active0 load');
      const actor=checked(()=>allocator.getPointerTarget(id));
      noShadows(actor,['0','byte0','half0','word0','field0']);guard();
      const active=checked(()=>byte(actor,'active0'));
      for(const alias of ['0','byte0','half0','word0','field0'])if(primaryStoreDescriptor(actor,alias))fail(alias+': competing89aec active cell');
      if(s8(active)!==0)walk(49+index,0x80089b84);
    }
    walk(55,0x80089bd0);
  };
  const runtime: SourceBattleOuterFrameRuntime={
    getSchedulerRuntime() {return scheduler;},getMatchGlobals() {return globals;},
    runFrame(): never {
      if(busy) {poisoned=true;close();fail('same-runtime reentry unsupported');}
      if(incomplete) fail('permanently incomplete outer frame');
      busy=true;poisoned=false;
      try {
        if(read(sources,'scheduler')!==scheduler || scheduler.getRootRuntime()!==root ||
          root.getSpawnRuntime()!==spawns || scheduler.getAllocatorRuntime()!==allocator) fail('canonical scheduler graph changed');
        noShadows(globals,['5588','102','214','215','byteD6','byteD7','byted6','byted7','half214']);
        distancesPrepared=false;producedDistances.clear();completedOrderedActors.clear();
        applyPending();updateTeams();
        if(s8(byte(match(),'byte66'))===0) {
          prepareMass();
          prepareTargets();distancesPrepared=true;
          prepareLeaders();
        }
        prepareParticipantViews();
        // Fresh source mode, not the mode observed before mass/participant work.
        if(s8(byte(match(),'byte66'))===0) {
          invokeScheduler(0x8002947c,40);invokeScheduler(0x80029484,32);
          runOrderedActors();runStageDispatch();
          invokeScheduler(0x80029494,0);invokeScheduler(0x8002949c,16);
          invokeScheduler(0x800294a4,8);invokeScheduler(0x800294ac,24);
          invokeScheduler(0x800294b4,56);
        }
        invokeScheduler(0x800294bc,58);invokeScheduler(0x800294c4,57);
        runObjectUpdates(0x800294c8);
        const counterOwner=match();
        noShadows(counterOwner,['wordb0','fieldb0','176','byteb0','byteb1','byteb2','byteb3']);
        const ingress=Object.getOwnPropertyDescriptor(counterOwner,'wordB0');check();
        if(!ingress||!('value'in ingress))fail('800294cc reached outer counter continuation after80089554: explicit wordB0 required');
        const counter=unsigned(read(counterOwner,'wordB0'),0xffffffff,'wordB0');
        const counterField=Object.getOwnPropertyDescriptor(counterOwner,'wordB0');check();
        if(!counterField||!('value'in counterField)||!counterField.writable)fail('wordB0 writable own destination required');
        schedulerGraph();check();
        const finalCounter=primaryStoreDescriptor(counterOwner,'wordB0');
        if(!finalCounter||!('value'in finalCounter)||!finalCounter.writable)fail('wordB0 destination changed');
        for(const key of ['wordb0','fieldb0','176','byteb0','byteb1','byteb2','byteb3'])if(primaryStoreDescriptor(counterOwner,key))fail('wordB0: competing source cell owner');
        (counterOwner as {wordB0:number}).wordB0=(counter+1)>>>0;check();
        if(s8(byte(match(),'byte66'))===0){
          resetContactCounts();
          runContactCallbacks();
          runTargetActionPrefix();
        }
        const helper=call(()=>spawns.getAdmissionRuntime().getActionRuntime().getSlotStatusRuntime());
        if(!isSourceActorSlotStatusRuntime(helper))fail('36e24 canonical slot-status owner required');
        contactInvocation={entered:false,helper};
        try{executeSourcePlayerContact36e24(runtime);}finally{contactInvocation=undefined;}
        runObjectUpdates(0x800294fc);runObjectUpdates(0x80029500);
        fail('80029504 reached outer post-draw continuation');
      } catch(error) {
        close();throw error;
      } finally {targetResetInvocation=undefined;contactInvocation=undefined;contactTransformInvocation=undefined;drawInvocation=undefined;orderedInvocation=undefined;schedulerInvocation=undefined;busy=false;}
    },
  };
  targetResets.set(runtime,{
    consume(kind,value){const c=targetResetInvocation;if(!c||c.entered||c.kind!==kind||c.value!==value){rejectScheduler();fail('private exact single-use2bb14 reset invocation required');}c.entered=true;this.check();return c.sources;},
    check(){const c=targetResetInvocation;if(!busy||closing||incomplete||poisoned||!c?.entered){rejectScheduler();fail('private active2bb14 reset invocation required');}c.guard();check();},
    constants(){this.check();return targetResetInvocation!.constants();},
  });
  const contactCheck=(helper?:SourceActorSlotStatusRuntime):void=>{
    const c=contactInvocation;
    if(!busy||closing||incomplete||poisoned||!c?.entered||(helper!==undefined&&helper!==c.helper)){
      rejectScheduler();fail('private exact active294f8 contact invocation required');
    }
    schedulerGraph();check();
    if(spawns.getAdmissionRuntime().getActionRuntime().getSlotStatusRuntime()!==c.helper||c.helper.getSchedulerRuntime()!==scheduler)
      fail('canonical contact helper changed');
    checkSourcePlayerContactStorage(c.helper);
    const systemOwner=retained.get('systemGlobals');
    if(systemOwner){const link=primaryStoreDescriptor(sources,'systemGlobals');
      if(!link||!('value'in link)||link.value!==systemOwner)fail('contact system owner changed');}
    const contactOwner=retained.get('playerContact'),constants=retained.get('contactConstants');
    if(contactOwner){const link=primaryStoreDescriptor(sources,'playerContact');
      if(!link||!('value'in link)||link.value!==contactOwner)fail('contact source owner changed');
      if(constants){const cell=primaryStoreDescriptor(contactOwner,'constants');
        if(!cell||!('value'in cell)||cell.value!==constants)fail('contact constants owner changed');}}

  };
  playerContacts.set(runtime,{
    consume(){const c=contactInvocation;if(!c||c.entered){rejectScheduler();fail('private single-use294f8 contact invocation required');}c.entered=true;contactCheck();return{helper:c.helper,root};},
    check:contactCheck,
    system(){contactCheck();return system();},
    constant(){contactCheck();const owner=retain('playerContact',read(sources,'playerContact'));
      const constants=retain('contactConstants',read(owner,'constants'));const value=read(constants,'float80436f68');contactCheck();return value;},
  });
  const contactTransformCheck=(node:symbol):void=>{
    const active=contactTransformInvocation;
    if(!busy||closing||incomplete||poisoned||!active||!active.entered||active.node!==node||(active.site!==0x8008a728&&active.site!==0x8008a888)){
      rejectScheduler();fail('private exact active contact transform invocation required');
    }
    if(active.checking)return;active.checking=true;
    try{active.guard();check();}finally{active.checking=false;}
  };
  contactTransforms.set(runtime,{consume(node){const active=contactTransformInvocation;
    if(!active||active.entered||active.node!==node){rejectScheduler();fail('private exact single-use contact transform invocation required');}
    active.entered=true;contactTransformCheck(node);return active.context;
  },check:contactTransformCheck});
  drawInvocations.set(runtime,{consume(node){const active=drawInvocation;if(!active||active.entered||active.node!==node){rejectScheduler();fail('private exact single-use draw invocation required');}active.entered=true;drawCheck(node);return active.context;},check:drawCheck});
  failures.set(runtime,selected=>{if(!busy || !closing || !incomplete || selected!==scheduler) fail('private exact active outer failure required');});
  schedulerInvocations.set(runtime,{
    parent(selected,id,actor){
      const invocation=schedulerInvocation;
      if(!busy||closing||incomplete||poisoned||selected!==scheduler||!invocation?.entered||
        ![0x80029494,0x8002949c,0x800294a4,0x800294ac,0x800294b4,0x800294bc,0x800294c4].includes(invocation.callsite)||
        completedOrderedActors.get(id)!==actor||massActors.get(id)!==actor){rejectScheduler();fail('private completed54070 parent in later scheduler required');}
      schedulerGraph();check();
    },
    enter(selected,callsite,group) {
      const active=schedulerInvocation;
      if(!busy || closing || incomplete || poisoned || selected!==scheduler || !active || active.entered ||
        active.callsite!==callsite || active.group!==group) {
        rejectScheduler();fail('private exact single-use active outer scheduler invocation required');
      }
      active.entered=true;
    },
    check(selected) {
      if(!busy || closing || incomplete || poisoned || selected!==scheduler || !schedulerInvocation?.entered) {
        rejectScheduler();fail('private exact active outer scheduler invocation required');
      }
      schedulerGraph();
    },
    reject:rejectScheduler,
  });
  const orderedCheck=(selected:SourceActorOrderedFrameRuntime,id:symbol):void=>{
    const active=orderedInvocation;
    if(!busy||closing||incomplete||poisoned||!active||active.stage!==selected||active.id!==id||!active.entered)
      fail('private exact active ordered actor invocation required');
    if(read(sources,'orderedActors')!==selected||actual(id)!==active.actor)fail('ordered actor invocation owner changed');
    check();
  };
  orderedActorInvocations.set(runtime,{
    enter(selected,id){
      const active=orderedInvocation;
      if(!busy||closing||incomplete||poisoned||!active||active.stage!==selected||active.id!==id||active.entered)
        fail('private exact single-use54070 invocation required');
      active.entered=true;orderedCheck(selected,id);return active.actor;
    },
    check:orderedCheck,
    consume(selected,id){
      orderedCheck(selected,id);const produced=producedDistances.get(id);
      if(!distancesPrepared||!produced||produced.actor!==orderedInvocation!.actor||produced.fields!==3||produced.consumed)
        fail('55568 requires same-actor completed source760/764 production once');
      produced.consumed=true;return Object.freeze({});
    },
    matrices(selected,id,owner){
      orderedCheck(selected,id);const mass=retain('massPreparation',read(sources,'massPreparation'));
      if(read(mass,'matrices')!==owner)fail('54160 matrix owner differs from canonical mass4a4 owner');
    },
    sampler(selected,id,sampler){
      orderedCheck(selected,id);checkSourceActorOrderedSamplerInvocation(selected,sampler,id);
      if(sampler.getViewGlobals()!==retain('systemGlobals',read(sources,'systemGlobals'))||sampler.getMatchGlobals()!==globals)
        fail('56900 requires same retained view/match owners');
    },
    rng(selected,id,command,callsite,expected){
      orderedCheck(selected,id);checkSourceActorOrderedVoicePosition(selected,command,id,callsite);
      if(command!==spawns.getAdmissionRuntime()||command.getGlobal()!==globals)fail('voice RNG canonical command/global owner differs');
      const mass=retain('massPreparation',read(sources,'massPreparation')),{state,guard}=rngOwner(mass,'voice800055fc');
      guard();if(expected!==undefined&&expected!==state)fail('voice RNG state owner changed');return state;
    },
    reject(){if(busy){poisoned=true;close();}},
  });
  runtimes.add(runtime);pendingClaims.set(runtime,scheduler);
  try {claimSourceObjectSchedulerOuterFrame(scheduler,runtime);} finally {pendingClaims.delete(runtime);}
  claimedGlobals.add(globals);return Object.freeze(runtime);
}
